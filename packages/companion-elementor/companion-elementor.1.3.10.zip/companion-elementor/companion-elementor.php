<?php
/**
 * Plugin Name: Companion Addons for Elementor
 * Plugin URI: https://zakratheme.com/
 * Description: Companion Addons for Elementor contains various amazing Elementor Elements such as Posts, Slider, Filterable Gallery, Service Box, Team, Testimonial Carousel and much more that empowers WordPress sites.
 * Version: 1.3.10
 * Update URI: https://api.freemius.com
 * Author: ThemeGrill
 * Author URI: https://zakratheme.com/
 * Elementor tested up to: 3.20.4
 *
 * Text Domain: companion-elementor
 * Domain Path: /languages/
 *
 * @package Companion_Elementor
 * @since   1.0.0
 */

use CompanionElementor\Classes\Utils;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// Include the required Freemius SDK integration file.
require_once plugin_dir_path( __FILE__ ) . '/includes/class-fs-companion-elementor.php';

define( 'COMPANION_ELEMENTOR_VERSION', '1.3.10' );

define( 'COMPANION_ELEMENTOR_PLUGIN_FILE', __FILE__ );

// Plugin directory paths.
define( 'COMPANION_ELEMENTOR_PLUGIN_BASENAME', plugin_basename( COMPANION_ELEMENTOR_PLUGIN_FILE ) );
define( 'COMPANION_ELEMENTOR_ABSPATH', plugin_dir_path( COMPANION_ELEMENTOR_PLUGIN_FILE ) );
define( 'COMPANION_ELEMENTOR_INCLUDES_DIR', COMPANION_ELEMENTOR_ABSPATH . 'includes' );
define( 'COMPANION_ELEMENTOR_ELEMENTOR_DIR', COMPANION_ELEMENTOR_ABSPATH . 'elementor' );
define( 'COMPANION_ELEMENTOR_ELEMENTOR_WIDGETS_DIR', COMPANION_ELEMENTOR_ELEMENTOR_DIR . '/widgets' );

// Plugin URL's.
define( 'COMPANION_ELEMENTOR_URL', plugin_dir_url( COMPANION_ELEMENTOR_PLUGIN_FILE ) );
define( 'COMPANION_ELEMENTOR_ASSETS_URL', COMPANION_ELEMENTOR_URL . 'assets' );

/**
 * Plugin activation.
 */
function activate_companion_elementor() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-companion-elementor-activator.php';
	Companion_Elementor_Activator::activate();
}

/**
 * Plugin deactivation.
 */
function deactivate_companion_elementor() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-companion-elementor-deactivator.php';
	Companion_Elementor_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_companion_elementor' );
register_deactivation_hook( __FILE__, 'deactivate_companion_elementor' );

/**
 * The core plugin class that is used to define internationalization and hooks.
 */
function companion_elementor_initialize() {
	load_plugin_textdomain(
		'companion-elementor',
		false,
		plugin_dir_path( COMPANION_ELEMENTOR_PLUGIN_BASENAME ) . 'languages'
	);

	if ( ! did_action( 'elementor/loaded' ) ) {
		add_action( 'admin_notices', 'companion_elementor_fail_loading' );

		return;
	}

	require COMPANION_ELEMENTOR_ABSPATH . 'plugin.php';
}
add_action( 'plugins_loaded', 'companion_elementor_initialize' );

function companion_elementor_fail_loading() {
	$msg = '<p>' . sprintf(
		/* Translators: 1: Plugin name 2: Elementor */
		esc_html__( '%1$s requires %2$s plugin to be installed and activated.', 'companion-elementor' ),
		'<strong>' . esc_html__( 'Companion Addons for Elementor', 'companion-elementor' ) . '</strong>',
		'<strong>' . esc_html__( 'Elementor', 'companion-elementor' ) . '</strong>'
	) . '</p>';

	$plugin = 'elementor/elementor.php';

	if ( _companion_elementor_is_elementor_installed() ) {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		$action_url   = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );
		$button_label = esc_html__( 'Activate Elementor', 'companion-elementor' );
	} else {
		if ( ! current_user_can( 'install_plugins' ) ) {
			return;
		}

		$action_url   = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=elementor' ), 'install-plugin_elementor' );
		$button_label = esc_html__( 'Install Elementor', 'companion-elementor' );
	}

	$msg .= '<p>' . sprintf(
		/* Translators: 1: Notice CTA URL 2: Notice CTA text */
		'<a href="%s" class="button-primary">%s</a>',
		$action_url,
		$button_label
	) . '</p>';

	echo '<div class="error">' . $msg . '</div>';
}

if ( ! function_exists( '_companion_elementor_is_elementor_installed' ) ) {
	function _companion_elementor_is_elementor_installed() {
		$installed_plugins = get_plugins();

		return isset( $installed_plugins['elementor/elementor.php'] );
	}
}

require_once COMPANION_ELEMENTOR_ABSPATH . '/admin/admin.php';
