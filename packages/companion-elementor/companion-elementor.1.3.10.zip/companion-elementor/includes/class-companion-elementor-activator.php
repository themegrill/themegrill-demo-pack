<?php

/**
 * Fired during plugin activation
 *
 * @link       https://themegrill.com
 * @since      1.0.0
 *
 * @package    Companion_Elementor
 * @subpackage Companion_Elementor/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Companion_Elementor
 * @subpackage Companion_Elementor/includes
 * @author     ThemeGrill <themegrill@gmail.com>
 */
class Companion_Elementor_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
