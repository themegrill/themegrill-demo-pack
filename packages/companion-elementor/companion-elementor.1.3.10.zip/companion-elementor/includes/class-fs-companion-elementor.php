<?php

/**
 * Integrate Freemius SDK for license management.
 *
 * @link       https://themegrill.com
 * @since      1.0.0
 *
 * @package    Companion_Elementor
 * @subpackage Companion_Elementor/includes
 */
#--------------------------------------------------------------------------------
#region Freemius
#--------------------------------------------------------------------------------
class FS_Companion_Elementor {
    /**
     * @var Freemius
     */
    private static $fs;

    /**
     * @return Freemius
     */
    public static function freemius() {
        return self::$fs;
    }

    private function __construct() {
    }

    /**
     * @param string $id
     * @param string $slug
     * @param string $public_key
     * @param string $name
     *
     * @return \Freemius|void
     */
    public static function init(
        $id,
        $slug,
        $public_key,
        $name = ''
    ) {
        if ( !isset( self::$fs ) ) {
            // Include Freemius SDK.
            if ( !defined( 'WP_FS__SDK_VERSION' ) ) {
                if ( !file_exists( plugin_dir_path( __DIR__ ) . '/freemius/start.php' ) ) {
                    return;
                }
                require_once plugin_dir_path( __DIR__ ) . '/freemius/start.php';
            }
            self::$fs = fs_dynamic_init( array(
                'id'              => $id,
                'slug'            => $slug,
                'premium_slug'    => 'companion-elementor',
                'type'            => 'plugin',
                'public_key'      => $public_key,
                'is_premium'      => true,
                'is_premium_only' => true,
                'has_addons'      => false,
                'has_paid_plans'  => true,
                'menu'            => array(
                    'slug'    => 'companion-elementor',
                    'support' => false,
                    'parent'  => array(
                        'slug' => 'options-general.php',
                    ),
                ),
                'is_live'         => true,
            ) );
            // Signal that SDK was initiated.
            do_action( "{$slug}_fs_loaded" );
            require_once plugin_dir_path( __DIR__ ) . '/includes/class-freemius-admin-menu.php';
            if ( empty( $name ) ) {
                $name = ucwords( str_replace( '-', ' ', $slug ) );
            }
            new FS_Companion_Elementor_License_Menu($name, $slug);
        }
        return self::$fs;
    }

}

FS_Companion_Elementor::init(
    '4561',
    'companion-addons-for-elementor',
    'pk_a78a993061b9cfb24c2c1ec9608c3',
    'Companion Addons for Elementor'
);
#endregion