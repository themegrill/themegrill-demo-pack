<?php
namespace CompanionElementor;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

final class Manager {
	private $modules = array();

	public function __construct() {
		$modules = array(
			'advanced-image',
			'accordion-toggle',
			'button',
			'chart',
			'countdown',
			'counter',
			'divider',
			'dual-heading',
			'everest-forms',
			'feature-list',
			'filterable-gallery',
			'google-maps',
			'instagram-feed',
			'lottie-animation',
			'mailchimp',
			'media-carousel',
			'modal',
			'nav-menu',
			'offcanvas',
			'onepage-nav',
			'pricing-table',
			'progress-bar',
			'service-box',
			'slider',
			'social-share',
			'switcher',
			'tabs',
			'table',
			'team',
			'testimonial-carousel',
			'video-gallery',
			'posts',
			'post-slider',
			'post-timeline',
			'wc-products',
		);

		foreach ( $modules as $module_name ) {
			$class_name = str_replace( '-', ' ', $module_name );
			$class_name = str_replace( ' ', '', ucwords( $class_name ) );
			$class_name = __NAMESPACE__ . '\\Modules\\' . $class_name . '\Module';

			if ( $class_name::is_active() ) {
				$this->modules[ $module_name ] = $class_name::instance();
			}
		}
	}
}
