<?php
/**
 * Setting page for Freemius Integration.
 *
 * @link       https://themegrill.com
 * @since      1.0.0
 *
 * @package    Companion_Elementor
 * @subpackage Companion_Elementor/includes
 */

/**
 * Class FS_Companion_Elementor_License_Menu
 */
class FS_Companion_Elementor_License_Menu {
	/**
	 * @var string
	 */
	private $_name;
	/**
	 * @var string
	 */
	private $_slug;

	function __construct( $name, $slug ) {
		$this->_name = $name;
		$this->_slug = $slug;

		add_action( 'admin_menu', array( &$this, 'add_menu' ) );
	}

	function redirect_to_account_when_registered() {
		$fs = FS_Companion_Elementor::freemius();

		if ( ! $fs->is_activation_mode() ) {
			$pages = array( 'account', 'contact', 'pricing' );

			foreach ( $pages as $page ) {
				if ( $fs->is_page_visible( $page ) ) {
					fs_redirect( $fs->_get_admin_page_url( $page ) );
				}
			}
		}
	}

	function get_empty_html() {
		return '';
	}

	function add_menu() {
		$hook = add_options_page(
			$this->_name . ' ' . __( 'License Manager', $this->_slug ),
			$this->_name . ' ' . __( 'License Manager', $this->_slug ),
			'manage_options',
			'companion-elementor',
			array( &$this, 'get_empty_html' )
		);

		add_action( "load-{$hook}", array( &$this, 'redirect_to_account_when_registered' ) );
	}
}
