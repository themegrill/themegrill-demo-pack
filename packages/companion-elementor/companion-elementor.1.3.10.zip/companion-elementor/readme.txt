=== Companion Addons for Elementor ===
Contributors: themegrill
Tags: elementor, widgets, companion-plugin, elements
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 5.6
Stable tag: 1.3.10
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Addons for Elementor Page Builder.

== Description ==

Companion Addons for Elementor contains various Elementor Elements such as Slider, Filterable Gallery, Service Box, Team, Testimonial Carousel and much more that empowers WordPress sites.

== Installation ==

1. After you have purchased the Companion Addons for Elementor, you can download the zip file via your ZakraTheme account page[https://zakratheme.com/account/].
2. Now, visit `Plugins` menu via your WordPress dashboard.
3. After that, click on `Add New` button.
4. Again, click on `Upload Plugin` button.
5. Now, browse for the downloaded zip file via `Choose File` button.
6. After that, click on the `Install Now` button and activate the plugin.

== Frequently Asked Questions ==

= What is the plugin license? =
* This plugin is released under a GPL license.

= Credits =

Isotope, Copyright © 2015, Metafizzy,
License: GNU GPL, Version 3, https://www.gnu.org/licenses/gpl-3.0.html
Source: http://isotope.metafizzy.co/

Magnific Popup, Copyright © 2016, Dmitry Semenov,
License: MIT, https://github.com/dimsemenov/Magnific-Popup/blob/master/LICENSE
Source: http://dimsemenov.com/plugins/magnific-popup/

== Changelog ==
= Version 1.3.10 - 2025 - 07 - 16 =
* Fix - Freemius Too many redirects issue.

= Version 1.3.9 - 2025 - 04 - 24 =
* Added - Rating layout and rating style options in Testimonial Carousel.

= Version 1.3.8 - 2025 - 02 - 04 =
* Update - Freemius SDK to the latest version.

= Version 1.3.7 - 2025 - 01 - 27 =
* Update        - Compatibility with Elementor v3.26.0.

= Version 1.3.6 - 2025 - 01 - 13 =
* Fix        - Slider widget slide issue.
* Fix        - Accordion widget icon size and content typography issue.
* Fix        - Counter widget icon size issue.
* Fix        - Media Carousel widget slider issue.
* Fix        - Service Box widget normal and hover icon color issue.
* Fix        - Team widget icon size and color issue.
* Fix        - Testimonial Carousel widget slider issue.
* Fix        - Post slider widget slide issue.
* Fix        - Post timeline widget line width issue.
* Fix        - Tabs widget typography issue.
* Fix        - Advanced Image button color issue.
* Fix        - Modal widget background color.
* Fix        - Pricing table widget button icon size issue.

= Version 1.3.5 - 2024 - 12 - 19 =
* Update        - Compatibility with Elementor v3.26.0.

= Version 1.3.4 - 2024 - 10 - 01 =
* fix - override media carousel widget css.

= Version 1.3.3 - 2024 - 07 - 16 =
* Added - Media carousel slider two row option.

= Version 1.3.2 - 2024 - 05 - 29 =
* Added - Tab widget style 4.
* Added - Option to change tabs gap.
* Added - Option to change normal and active color.

= Version 1.3.1 - 2024 - 04 - 15 =
* Enhancement - Added Button widget.
* Enhancement - Added Mailchimp widget.
* Enhancement - Added Social Share widget.
* Enhancement - Added Progress Bar widget.
* Enhancement - Added Off Canvas widget.
* Enhancement - Added Onepage nav widget.
* Enhancement - Added Feature List widget.
* Enhancement - Added Lottie Animation widget.
* Enhancement - Added Instagram Feed widget.
* Enhancement - Added Post Timeline widget.
* Enhancement - Added Nav Menu widget.
* Enhancement - Added Chart widget.
* Enhancement - Added Google Maps widget.
* Enhancement - Added Post Slider/Carousel widget.
* Feature     - Dual heading layout options.
* Feature     - Dual heading description options.
* Feature     - Dual heading icon options.
* Feature     - Team divider options.

= Version 1.3.0 - 2023 - 07 - 24 =
* Update - Freemius SDK.

= Version 1.2.9 - 2023 - 07 - 18 =
* Fix - Posts widget Columns responsive issue.

= Version 1.2.8 - 2023 - 07 - 05 =
* Update - Freemius SDK.

= Version 1.2.7 - 2023 - 03 - 28 =
* Fix    - Media Carousel, Testimonial Carousel, slider style issue.
* Update - Freemius SDK.

= Version 1.2.6 - 2022 - 11 - 04 =
* Fix   - Posts, title alignment issue.
* Tweak - Elementor compatibility version update.

= Version 1.2.5 - 2022 - 05 - 17 =
* Enhancement - Allow HTML markup in Table body text field.

= Version 1.2.4 - 2022 - 03 - 30 =
* Fix - _register_controls is deprecated.
* Fix - _register_skins is deprecated.

= Version 1.2.3 - 2022 - 03 - 02 =
* Update - Freemius SDK.

= Version 1.2.2 - 2021 - 12 - 27 =
* Fix - Testimonial and Media Carousel slider issue.
* Fix - Update Migration code for Font Awesome 4 icon issue.

= Version 1.2.1 - 2021 - 12 - 14 =
* Feature - Tabs, spacing option in style 2 layout.
* Fix     - Tabs, border type issues.
* Fix     - Migration for Font Awesome 4 icons issue.

= Version 1.2.0 - 2021 - 11 - 08 =
* Fix - Font Awesome 4 icon compatability issue.

= Version 1.1.9 - 2021 - 08 - 19 =
* Enhancement - Allow HTML markup in Table text field.

= Version 1.1.8 - 2021 - 08 - 5 =
* Enhancement - Updated Elementor Icon Library.
* Enhancement - Allow SVG icon Upload.
* Enhancement - Allow HTML markup in Service Box description field.
* Feature     - Divider, Before/After border radius option.

= Version 1.1.7 - 2021 -06 - 11 =
* Feature - WC Products, sale badge typography options.
* Feature - WC Products, sale badge color option.
* Feature - WC Products, sale badge background color option.
* Feature - WC Products, product image overlay option.
* Feature - WC Products, product image overlay color option.

= Version 1.1.6 - 2021 - 05 - 24 =
* Fix - Countdown, Column Gap issue.
* Fix - Countdown, Border Type issue.
* Fix - Countdown, Border Radius issue.

= Version 1.1.5 - 2021 - 05 - 04 =
* Fix         - Elementor\Scheme_Typography is deprecated.
* Fix         - Elementor\Scheme_Color is deprecated.
* Added       - New Demo (Counselling) - WordPress Template Site with professional looking design for promoting Psychologist, Therapist, and Counselor services.
* Added       - New Demo (ApplyJob) - WordPress Template Site with beautiful design for job portal, job seekers, online recruitment and all kind of jobs and career opportunities.
* Added       - New Demo (Job Portal) - WordPress template site suitable for all kinds of job portal, online recruitment, job seekers, site with awesome design.
* Enhancement - Allow HTML markup in Team description field.

= Version 1.1.4 - 2021 - 03 - 25 =
* Feature - Post, meta link color option.
* Feature - Post, meta link hover color option.

= Version 1.1.3 - 2021 - 03 - 19 =
* Feature - Service Box, separator border radius option.
* Added   - New Demo (Foodies) - WordPress Template Site for Best Food.

= Version 1.1.2 - 2021 - 03 - 12 =
* Enhancement - Added responsive option for Everest Forms Widget Column Gap option.
* Enhancement - Added responsive option for Countdown Widget Alignment option.
* Added       - New Demo (Zakra Kantipur News) - WordPress Template Site with elegant design for for News portal, Magazine site and Business News.
* Added       - New Demo (Zakra Real Estate) - WordPress Template Site for your Real Estate services with elegant design.

= Version 1.1.1 - 2021 - 01 - 27 =
* Added       - New Demo (Zakra Organic Farm) - WordPress Template Site for Organic Farm and Organic Agriculture Farming.
* Added       - New Demo (Zakra Digital Diary) - WordPress Template Site with elegant design for creative blogger.
* Added       - New Demo (Zakra Music Band) - WordPress Template Site for Music Band.
* Added       - New Demo (Zakra Digital Marketing) - Zakra Digital Marketing– WordPress Template Site for all kind of Digital Marketing.
* Added       - New Demo (Royal Hotel) - WordPress Template Site for Best Hotel Services.
* Feature     - Introducing Video Gallery Widget.
* Fix         - PHP notice offset value of bool while no image is added in the Slider Widget.
* Feature     - Post, image size option.
* Feature     - Post, image border radius option.
* Feature     - Post, image position option.
* Feature     - Placeholder color option on Everest Forms widget.
* Enhancement - Added responsive in image size option of Testimonial Carousel Widget.
* Enhancement - Added responsive in slides alignment option of Testimonial Carousel Widget.

= Version 1.1.0 - 2020 - 10 - 06 =
* Fix         - Syntax error on Everest Forms widget while PHP5.6 or lower.
* Enhancement - Inline editing support for Pricing Table widget.

= Version 1.0.9 - 2020 - 10 - 01 =
* Added       - New Demo (Zakra Online Store) - WordPress Template Site for online shopping, a simple way to manage your online store.
* Added       - New Demo (Zakra Cleaner) - WordPress Template Site for professional cleaning and maid Services.
* Feature     - Introducing Everest Forms Widget.
* Feature     - Added tag as meta option in Post Widget.
* Enhancement - Allow HTML markup in Testimonial Carousel message field.

= Version 1.0.8 - 2020 - 08 - 25 =
* Added       - New Demo (Zakra Portfolio) - WordPress Template Site for creative professional to showcase work experience, skills and services.
* Added       - New Demo (Zakra WebHost) - WordPress Template Site for web hosting and domain name registration business with sleek and professional design.
* Added       - New Demo (Zakra Online Course) - WordPress template site for authors, writers, and bloggers to build the ideal library of books and commercializing their works.
* Added       - New Demo (Zakra Writer) - WordPress template site for authors, writers, and bloggers to build the ideal library of books and commercializing their works.
* Added       - New Demo (Zakra Chapel) - WordPress Template Site for leading people into a growing relationship with God and lending hand for those in need.
* Feature     - Introducing WC Products Widget.
* Feature     - Accordion Toggle icon alignment option.
* Enhancement - Accordion Toggle content inline editing support.
* Fix         - PHP notice undefined index while adding Post Widget first time.
* Fix         - Post Widget title line height issue.
* Fix         - Post Widget avatar and category overlapping.

= Version 1.0.7 - 2020 - 07 - 29 =
* Added   - New Demo (Zakra Care) - Showcase your support, love and care online.
* Added   - New Demo (Zakra Law Firm) - Professional website for special education advocate.
* Fix     - HTML render issue in accordion widget.
* Feature - Modal popup background option.
* Feature - Testimonial Carousel wrapper padding option.
* Fix     - PHP error notices in widgets.

= Version 1.0.6 - 2020 - 06 - 05 =
* Feature     - Tabs, option to activate any tab by default.
* Fix         - Carousels slides per view affected by tablet spv.
* Fix         - Filterable gallery, HTML markup appearing while buttons disabled.
* Enhancement - Update Freemius sdk.

= Version 1.0.5 - 2020 - 04 - 16 =
* Added   - New Demo (Zakra Pro Gym) - Showcase your fitness program online.
* Feature - Post, option to show/hide meta data.
* Feature - Post, CTA options.
* Fix     - Post, Author avatar taking full width.
* Feature - Post, box hover style options.
* Feature - Team, CTA options.
* Feature - Introducing Table Widget.
* Feature - Introducing Accordion Toggle Widget.
* Feature - Tabs widget style 3.
* Feature - Pricing table, CTA width option.
* Feature - Pricing table, alignment option.
* Feature - Pricing table, features list alignment option.
* Feature - Pricing table, original price position option.
* Fix     - Pricing table, space between currency symbol and price.
* Fix     - PHP notice while CTA type set none in Service Box widget.

= Version 1.0.4 - 2020 - 01 - 31 =
* Added   - New Demo (Zakra Pro Startup Business) - Kickstart your site with this professional looking demo.
* Feature - Introducing Advanced Image Widget.
* Feature - Pricing Table Widget, introducing Style 2 layout.
* Feature - Pricing Table Widget currency style options.
* Fix     - Pricing Table Widget border is not removing from option.
* Feature - Service Box Widget icon box shadow option.
* Feature - Tabs Widget, introducing Style 2 layout.
* Feature - Tabs Widget alignment options.
* Feature - Team Widget designation typography options.
* Feature - Posts Widget show hide element options.
* Feature - Posts Widget border radius options.
* Feature - Media Carousel Widget hover effects options.
* Feature - Filterable Gallery Widget hover effects options.
* Feature - Divider Widget added responsive to alignment option.
* Fix     - Divider Widget alignment issue while stacked.
* Fix     - PHP Warning while no terms on Posts Widget.

= Version 1.0.3 - 2020 - 01 - 14 =
* Feature - Introducing Posts Widget.
* Added   - New Demo (Zakra Pro Dentist V2) - Let your website shine bright.
* Fix     - Image size issue on Service Box Widget.
* Fix     - CTA padding issue on Service Box Widget.

= Version 1.0.2 - 2019 - 11 - 14 =
* Feature - Links for dual headings.
* Fix     - Issue while long text on Service Box.
* Fix     - Column margin issue while large image size value on Service Box.
* Fix     - Filterable Gallery image size issue.

= Version 1.0.1 - 2019 - 10 - 24 =
* Added - New Demo (Zakra Pro One Page) - Deliver better user experience with one-page scrolling layout.
* Fix   - Divider widget length and weight not working while vertically stacked.

= Version 1.0.0 =
* Initial Public Release
