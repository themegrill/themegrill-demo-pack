<?php
namespace CompanionElementor;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Plugin {
	private static $instance;

	public $modules_manager;

	public static function instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function autoload( $class ) {
		// Only CAE classes.
		if ( 0 !== strpos( $class, __NAMESPACE__ ) ) {
			return;
		}

		if ( ! class_exists( $class ) ) {
			$filename = strtolower(
				preg_replace(
					array( '/^' . __NAMESPACE__ . '\\\/', '/([a-z])([A-Z])/', '/_/', '/\\\/' ),
					array( '', '$1-$2', '-', DIRECTORY_SEPARATOR ),
					$class
				)
			);

			$filepath = COMPANION_ELEMENTOR_ABSPATH . $filename . '.php';

			if ( is_readable( $filepath ) ) {
				include $filepath;
			}
		}
	}

	private function __construct() {
		spl_autoload_register( array( $this, 'autoload' ) );

		$this->includes();

		$this->setup_hooks();
	}

	private function includes() {
		require COMPANION_ELEMENTOR_ABSPATH . 'includes/module-manager.php';
	}

	private function setup_hooks() {
		add_action( 'elementor/init', array( $this, 'elementor_init' ) );
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_categories' ) );
		add_action( 'elementor/frontend/after_enqueue_styles', array( $this, 'enqueue_styles' ) );
		add_action( 'elementor/frontend/before_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'enqueue_editor_styles' ] );

		add_action( 'wp_ajax_nopriv_ec_mailchimp_subscribe', array( $this, 'mailchimp_subscribe' ) );
		add_action( 'wp_ajax_ec_mailchimp_subscribe', array( $this, 'mailchimp_subscribe' ) );
	}

	public function elementor_init() {
		$this->modules_manager = new Manager();
		$this->regenerate_css();
	}

	public function mailchimp_subscribe() {

		check_ajax_referer( 'ec_mailchimp_form_nonce', 'security' );
		$api_key = ! empty( get_option( 'ec_mailchimp_api_key' ) ) && false != get_option( 'ec_mailchimp_api_key' ) ? get_option( 'ec_mailchimp_api_key' ) : '';

		if ( empty( $api_key ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Mailchimp API Key is not set.', 'companion-elementor' ),
				)
			);
		}

		$api_key_suffix = explode( '-', $api_key )[1];

		$audience = isset( $_POST['audience'] ) ? sanitize_text_field( wp_unslash( $_POST['audience'] ) ) : '';

		if ( empty( $audience ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Mailchimp audience is not set.', 'companion-elementor' ),
				)
			);
		}

		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';

		if ( empty( $email ) || ! is_email( $email ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Mailchimp email is not valid.', 'companion-elementor' ),
				)
			);
		}

		// API URL
		$api_url = 'https://' . $api_key_suffix . '.api.mailchimp.com/3.0/lists/' . $audience . '/members/' . md5( strtolower( $email ) );

		// API Args
		$api_args = array(
			'method'  => 'PUT',
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Basic ' . base64_encode( 'user:' . $api_key ),
			),
			'body'    => json_encode(
				array(
					'email_address' => $email,
					'status'        => 'subscribed',
					'merge_fields'  => array(
						'FNAME'  => '',
						'FPHONE' => '',
						'FMSG'   => '',
					),
					'apikey'        => $api_key,
				)
			),
		);

		// Send Request
		$request = wp_remote_post( $api_url, $api_args );

		if ( ! is_wp_error( $request ) ) {
			$response = json_decode( wp_remote_retrieve_body( $request ) );

			// Set Status
			if ( ! empty( $response ) ) {
				if ( $response->status == 'subscribed' ) {
					wp_send_json_success( array( 'status' => 'subscribed' ) );
				} else {
					wp_send_json_success( array( 'status' => $response->title ) );
				}
			}
		} else {
			wp_send_json_error(
				array(
					'status'  => 'error',
					'message' => $request->get_error_message(),
				)
			);
		}
	}

	private function regenerate_css() {
		if ( '1.3.0' === COMPANION_ELEMENTOR_VERSION && ! get_option( '_companion_elementor_regenerate_css' ) ) {
			\Elementor\Plugin::instance()->files_manager->clear_cache();
			update_option( '_companion_elementor_regenerate_css', 1 );
		}
	}

	public function register_categories( $elements_manager ) {
		$elements_manager->add_category(
			'elementor-companion-category',
			array(
				'title' => __( 'Companion Addons for Elementor', 'companion-elementor' ),
				'icon'  => 'fa fa-plug',
			)
		);
	}

	public function enqueue_styles() {
		$suffix     = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$dir_suffix = is_rtl() ? '-rtl' : '';

		wp_register_style( 'magnific-popup', COMPANION_ELEMENTOR_ASSETS_URL . '/css/magnific-popup/magnific-popup' . $suffix . '.css', array(), COMPANION_ELEMENTOR_VERSION );
		wp_enqueue_style( 'companion-elementor-frontend', COMPANION_ELEMENTOR_ASSETS_URL . '/css/frontend' . $dir_suffix . $suffix . '.css' );
	}

	public function enqueue_editor_styles() {
		$suffix     = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$dir_suffix = is_rtl() ? '-rtl' : '';
		wp_enqueue_style( 'companion-elementor-editor', COMPANION_ELEMENTOR_ASSETS_URL . '/css/editor' . $dir_suffix . $suffix . '.css' );
	}

	public function enqueue_scripts() {
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_register_script( 'isotope', COMPANION_ELEMENTOR_ASSETS_URL . '/js/isotope/isotope.pkgd' . $suffix . '.js', array( 'jquery', 'elementor-frontend' ), COMPANION_ELEMENTOR_VERSION, true );

		wp_register_script( 'magnific-popup', COMPANION_ELEMENTOR_ASSETS_URL . '/js/magnific-popup/jquery.magnific-popup' . $suffix . '.js', array( 'jquery', 'elementor-frontend' ), COMPANION_ELEMENTOR_VERSION, true );

		wp_register_script( 'lottie', COMPANION_ELEMENTOR_ASSETS_URL . '/js/lottie/lottie.min.js', array(), COMPANION_ELEMENTOR_VERSION, true );

		wp_register_script( 'chart.js', COMPANION_ELEMENTOR_ASSETS_URL . '/js/chart.js/chart.js', array(), COMPANION_ELEMENTOR_VERSION, true );

		wp_enqueue_script( 'companion-elementor-frontend', COMPANION_ELEMENTOR_ASSETS_URL . '/js/frontend' . $suffix . '.js', array( 'jquery', 'elementor-frontend', 'magnific-popup', 'isotope' ), COMPANION_ELEMENTOR_VERSION, true );

		wp_localize_script(
			'companion-elementor-frontend',
			'companion_elementor',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
			)
		);
	}

	public static function elementor() {
		return \Elementor\Plugin::$instance;
	}
}

// Run the instance.
Plugin::instance();
