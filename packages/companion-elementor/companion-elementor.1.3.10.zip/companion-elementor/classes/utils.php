<?php
namespace CompanionElementor\Classes;

defined( 'ABSPATH' ) || exit;

class Utils {
	/**
	 * Render the Elementor template library for use within the Element options.
	 *
	 * @return array The elementor template id with its title.
	 */
	public static function get_templates() {
		$args = array(
			'post_type'      => 'elementor_library',
			'posts_per_page' => - 1,
		);

		$elementor_templates = get_posts( $args );

		$output = array(
			esc_html__( '-- Select --', 'companion-elementor' ),
		);

		if ( ! empty( $elementor_templates ) && ! is_wp_error( $elementor_templates ) ) :
			foreach ( $elementor_templates as $elementor_template ) {
				$output[ $elementor_template->ID ] = $elementor_template->post_title;
			}
		endif;

		return $output;
	}

	/**
	 * Get pages.
	 */
	public static function get_pages() {
		$pages = get_posts(
			[
				'post_type'     => 'page',
				'numberofposts' => -1,
				'post_status'   => 'publish',
			]
		);

		return array_reduce(
			$pages,
			function ( $acc, $curr ) {
				$acc[ $curr->ID ] = $curr->post_title;
				return $acc;
			},
			[
				esc_html__( '-- Select --', 'companion-elementor' ),
			]
		);
	}

	public static function get_post_types() {
		$post_types = get_post_types( array( 'public' => true ), 'objects' );
		$post_list  = array();

		foreach ( $post_types as $post_type ) {
			$post_list[ $post_type->name ] = $post_type->label;
		}

		return $post_list;
	}

	public static function get_taxonomies( $post ) {
		$taxonomies = get_object_taxonomies( $post, 'objects' );
		$tax_list   = array();

		foreach ( $taxonomies as $slug => $tax ) {

			if ( ! $tax->public || ! $tax->show_ui ) {
				continue;
			}

			$tax_list[ $slug ] = $tax;
		}

		return $tax_list;
	}

	public static function get_users() {
		$users     = get_users();
		$user_list = array();

		foreach ( $users as $user ) {
			$user_list[ $user->ID ] = $user->data->user_login;
		}

		return $user_list;
	}

	public static function get_everest_forms() {
		$options = array();

		if ( function_exists( 'evf' ) ) {
			$evf_forms = get_posts(
				array(
					'post_type'   => 'everest_form',
					'numberposts' => -1,
				)
			);

			$options[0] = esc_html__( 'Select a Form', 'companion-elementor' );

			if ( ! empty( $evf_forms ) && ! is_wp_error( $evf_forms ) ) {
				foreach ( $evf_forms as $evf_form ) {
					$options[ $evf_form->ID ] = $evf_form->post_title;
				}
			} else {
				$options[0] = esc_html__( 'Create a Form First', 'companion-elementor' );
			}
		}

		return $options;
	}

	/**
	** Mailchimp - Get Lists
	*/
	public static function get_mailchimp_lists() {
		$api_key        = get_option( 'ec_mailchimp_api_key', '' );
		$mailchimp_list = array( 'def' => esc_html__( 'Select List', 'companion-elementor' ) );

		if ( '' === $api_key ) {
			return $mailchimp_list;
		} else {
			$url      = 'https://' . substr( $api_key, strpos( $api_key, '-' ) + 1 ) . '.api.mailchimp.com/3.0/lists/';
			$args     = array( 'headers' => array( 'Authorization' => 'Basic ' . base64_encode( 'user:' . $api_key ) ) );
			$response = wp_remote_get( $url, $args );

			if ( is_wp_error( $response ) ) {
				$error_message = $response->get_error_message();
				error_log( 'MailChimp API request failed: ' . $error_message );
				return $mailchimp_list;
			} else {
				$body = json_decode( $response['body'] );

				if ( ! empty( $body->lists ) ) {
					foreach ( $body->lists as $list ) {
						$mailchimp_list[ $list->id ] = $list->name . ' (' . $list->stats->member_count . ')';
					}
				}

				return $mailchimp_list;
			}
		}
	}

	// Needs further logic
	public static function get_mailchimp_groups() {
		$groups_array = array( 'def' => 'Select Group' );
		foreach ( self::get_mailchimp_lists() as $key => $value ) {
			if ( 'def' === $key ) {
				continue;
			}
			$audience = $key;
			$api_key  = get_option( 'ec_mailchimp_api_key' );
			$url      = 'https://' . substr( $api_key, strpos( $api_key, '-' ) + 1 ) . '.api.mailchimp.com/3.0/lists/' . $audience . '/interest-categories';
			$args     = array( 'headers' => array( 'Authorization' => 'Basic ' . base64_encode( 'user:' . $api_key ) ) );

			$response = wp_remote_get( $url, $args );

			foreach ( json_decode( $response['body'] )->categories as $key => $value ) {
				$url  = 'https://' . substr( $api_key, strpos( $api_key, '-' ) + 1 ) . '.api.mailchimp.com/3.0/lists/' . $audience . '/interest-categories/' . $value->id . '/interests';
				$args = array( 'headers' => array( 'Authorization' => 'Basic ' . base64_encode( 'user:' . $api_key ) ) );

				$response = wp_remote_get( $url, $args );

				foreach ( json_decode( $response['body'] )->interests as $key => $value ) {
					$groups_array[ $value->id ] = $value->name;
				}
			}
		}

		return $groups_array;
	}
}
