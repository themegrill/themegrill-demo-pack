<?php
/**
 * Base class for WC Products widget.
 *
 * @since 1.0.7
 */

namespace CompanionElementor\Modules\WcProducts\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit;

abstract class Wc_Products_Base extends Base_Widget {

	protected $_has_template_content = false;

	public function get_icon() {
		return 'ce-widget-icon eicon-products';
	}

	protected function register_controls() {
		// Content controls.
		$this->start_controls_section(
			'section_general',
			[
				'label' => __( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->end_controls_section();

		$this->register_query_controls();
		$this->register_helpful_information();
	}

	private function register_query_controls() {
		$this->start_controls_section(
			'section_query',
			[
				'label' => __( 'Query', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'source',
			array(
				'label'   => __( 'Source', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'recent-products',
				'options' => array(
					'recent-products' => __( 'Recent Products', 'companion-elementor' ),
					'sales'           => __( 'Sales', 'companion-elementor' ),
					'featured'        => __( 'Featured', 'companion-elementor' ),
					'top-rated'       => __( 'Top Rated', 'companion-elementor' ),
				),
			)
		);

		$this->add_control(
			'product_category_filter',
			[
				'label'       => __( 'Categories Filter', 'companion-elementor' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'IN',
				'label_block' => true,
				'options'     => [
					'IN'     => __( 'Include', 'companion-elementor' ),
					'NOT IN' => __( 'Exclude', 'companion-elementor' ),
				],
			]
		);

		$r_terms = [];

		$related_terms = get_terms(
			array(
				'taxonomy' => 'product_cat',
			)
		);

		if ( ! is_wp_error( $related_terms ) ) {
			foreach ( $related_terms as $term ) {
				$r_terms[ $term->slug ] = $term->name;
			}
		}

		$this->add_control(
			'terms_product_category_choices',
			[
				/* translators: %s label */
				'label'       => __( 'Categories', 'companion-elementor' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'default'     => '',
				'label_block' => true,
				'options'     => $r_terms,
				'separator'   => 'after',
			]
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/wc-products/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}
}
