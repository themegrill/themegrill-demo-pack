<?php
/**
 * Main class for WC Products widget.
 *
 * @since 1.0.7
 */

namespace CompanionElementor\Modules\WcProducts\Widgets;

use CompanionElementor\Modules\WcProducts\Skins;

defined( 'ABSPATH' ) || exit;

class Wc_Products extends Wc_Products_Base {
	public function get_name() {
		return 'elementor-companion-wc-products';
	}

	public function get_title() {
		return __( 'WC Products', 'companion-elementor' );
	}

	public function get_keywords() {
		return [ 'companion', 'products', 'woocommerce', 'store', 'ecommerce' ];
	}

	protected function register_skins() {
		$this->add_skin( new Skins\Skin_Classic( $this ) );
		$this->add_skin( new Skins\Skin_Modern( $this ) );
	}

	protected function register_controls() {
		parent::register_controls();
	}
}
