<?php

namespace CompanionElementor\Modules\WcProducts\Skins;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Skin_Base as Elementor_Skin_Base;
use Elementor\Widget_Base;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

defined( 'ABSPATH' ) || exit;

abstract class Skin_Base extends Elementor_Skin_Base {

	protected function _register_controls_actions() {
		add_action(
			'elementor/element/elementor-companion-wc-products/section_general/before_section_end',
			[
				$this,
				'register_sections_before',
			]
		);

		add_action(
			'elementor/element/elementor-companion-wc-products/section_query/after_section_end',
			[
				$this,
				'register_sections',
			]
		);
	}

	public function register_sections_before( Widget_Base $widget ) {
		$this->parent = $widget;

		$this->add_control(
			'products_per_page',
			[
				'label'   => __( 'Products Per Page', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '6',
			]
		);

		$this->add_responsive_control(
			'columns',
			array(
				'label'                => __( 'Columns', 'companion-elementor' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 3,
				'tablet_default'       => 2,
				'mobile_default'       => 1,
				'options'              => [
					1 => esc_html__( '1', 'companion-elementor' ),
					2 => esc_html__( '2', 'companion-elementor' ),
					3 => esc_html__( '3', 'companion-elementor' ),
					4 => esc_html__( '4', 'companion-elementor' ),
					5 => esc_html__( '5', 'companion-elementor' ),
					6 => esc_html__( '6', 'companion-elementor' ),
				],
				'selectors_dictionary' => [
					1 => 'grid-template-columns: repeat(1, 1fr);',
					2 => 'grid-template-columns: repeat(2, 1fr);',
					3 => 'grid-template-columns: repeat(3, 1fr);',
					4 => 'grid-template-columns: repeat(4, 1fr);',
					5 => 'grid-template-columns: repeat(5, 1fr);',
					6 => 'grid-template-columns: repeat(6, 1fr);',
				],
				'selectors'            => [
					'{{WRAPPER}} .ec-grid' => '{{VALUE}};',
				],
			)
		);

		$this->add_control(
			'show_title',
			[
				'label'        => esc_html__( 'Title', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'companion-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_sale',
			[
				'label'        => esc_html__( 'Sale Badge', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'companion-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_rating',
			[
				'label'        => esc_html__( 'Rating', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'companion-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$this->add_control(
			'show_price',
			[
				'label'        => esc_html__( 'Price', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'companion-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_add_to_cart',
			[
				'label'        => esc_html__( 'Add to Cart', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'companion-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_product_description',
			[
				'label'        => esc_html__( 'Product Description', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'companion-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_divider',
			[
				'label'        => esc_html__( 'Divider', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'companion-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
	}

	public function register_sections( Widget_Base $widget ) {
		$this->parent = $widget;

		// Style controls.
		$this->register_style_layout_controls();
		$this->register_style_product_controls();
	}

	private function register_style_layout_controls() {
		$this->start_controls_section(
			'section_style_layout',
			[
				'label' => __( 'Layout', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'column_gap',
			[
				'label'     => __( 'Columns Gap', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-grid' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'row_gap',
			[
				'label'     => __( 'Rows Gap', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-grid' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'align',
			[
				'label'        => __( 'Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'left'   => [
						'title' => __( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'selectors'    => [
					'{{WRAPPER}} .ec-products-wrapper' => 'text-align: {{VALUE}};',
				],
				'prefix_class' => 'ec-product__align-',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_product_controls() {
		$this->start_controls_section(
			'section_style_product',
			[
				'label' => __( 'Product', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'summary_heading',
			[
				'label' => esc_html__( 'Summary', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'summary_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} li.product .ec-product__summary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_heading',
			[
				'label' => esc_html__( 'Image', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'image_position',
			[
				'label'              => esc_html__( 'Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'options'            => [
					'left'  => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'top'   => [
						'title' => esc_html__( 'Top', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'prefix_class'       => 'ec-product--',
				'frontend_available' => true,
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'      => esc_html__( 'Max Width', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'%',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 600,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-product__thumbnail' => 'flex: 0 1 {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-product__thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_overlay',
			[
				'label'        => esc_html__( 'Overlay', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);

		$this->add_control(
			'image_overlay_color',
			[
				'label'     => esc_html__( 'Overlay Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-overlay' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					$this->get_control_id( 'image_overlay' ) => 'yes',
				],
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label' => esc_html__( 'Title', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'title_color',
			array_merge(
				[
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} li.product .woocommerce-loop-product__title' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_2,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_SECONDARY,
					],
				]
			)
		);

		$this->add_control(
			'title_hover_color',
			array_merge(
				[
					'label'     => esc_html__( 'Hover Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} li.product .woocommerce-loop-product__title:hover' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_2,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_SECONDARY,
					],
				]
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array_merge(
				[
					'name'     => 'title_typography',
					'label'    => __( 'Typography', 'companion-elementor' ),
					'selector' => '{{WRAPPER}} li.product .woocommerce-loop-product__title',
				],
				class_exists( Typography::class ) ? [
					'scheme' => Typography::TYPOGRAPHY_1,
				] : [
					'global' => [
						'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
					],
				]
			)
		);

		$this->add_control(
			'title_spacing',
			[
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} li.product .woocommerce-loop-product__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'price_heading',
			[
				'label' => esc_html__( 'Price', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'price_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} li.product .price' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'price_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} li.product .price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array_merge(
				[
					'name'     => 'price_typography',
					'label'    => __( 'Typography', 'companion-elementor' ),
					'selector' => '{{WRAPPER}} li.product .price',
				],
				class_exists( Typography::class ) ? [
					'scheme' => Typography::TYPOGRAPHY_1,
				] : [
					'global' => [
						'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
					],
				]
			)
		);

		$this->add_control(
			'price_spacing',
			[
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} li.product .price' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'sale_badge',
			[
				'label' => esc_html__( 'Sale Badge', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'sale_badge_typography',
				'label'    => esc_html__( 'Typography', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .woocommerce span.onsale',
			]
		);

		$this->add_control(
			'sale_badge_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce span.onsale' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'sale_badge_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .woocommerce span.onsale' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'product_description',
			[
				'label' => esc_html__( 'Product Description', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'title_color',
			array_merge(
				[
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} li.product .woocommerce-loop-product__title' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_2,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_SECONDARY,
					],
				]
			)
		);

		$this->add_control(
			'title_hover_color',
			array_merge(
				[
					'label'     => esc_html__( 'Hover Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} li.product .woocommerce-loop-product__title:hover' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_2,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_SECONDARY,
					],
				]
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array_merge(
				[
					'name'     => 'title_typography',
					'label'    => __( 'Typography', 'companion-elementor' ),
					'selector' => '{{WRAPPER}} li.product .woocommerce-loop-product__title',
				],
				class_exists( Typography::class ) ? [
					'scheme' => Typography::TYPOGRAPHY_1,
				] : [
					'global' => [
						'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
					],
				]
			)
		);

		$this->add_responsive_control(
			'product_description_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} li.product .ec-product__summary .woocommerce-product-details__short-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array_merge(
				[
					'name'     => 'product_description_typography',
					'label'    => __( 'Typography', 'companion-elementor' ),
					'selector' => '{{WRAPPER}} li.product .ec-product__summary .woocommerce-product-details__short-description',
				],
				class_exists( Typography::class ) ? [
					'scheme' => Typography::TYPOGRAPHY_1,
				] : [
					'global' => [
						'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
					],
				]
			)
		);

		$this->add_control(
			'price_tag_heading',
			[
				'label' => esc_html__( 'Price Tag', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'title_color',
			array_merge(
				[
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} li.product .woocommerce-loop-product__title' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_2,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_SECONDARY,
					],
				]
			)
		);

		$this->add_control(
			'title_hover_color',
			array_merge(
				[
					'label'     => esc_html__( 'Hover Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} li.product .woocommerce-loop-product__title:hover' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_2,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_SECONDARY,
					],
				]
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array_merge(
				[
					'name'     => 'title_typography',
					'label'    => __( 'Typography', 'companion-elementor' ),
					'selector' => '{{WRAPPER}} li.product .woocommerce-loop-product__title',
				],
				class_exists( Typography::class ) ? [
					'scheme' => Typography::TYPOGRAPHY_1,
				] : [
					'global' => [
						'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
					],
				]
			)
		);

		$this->add_responsive_control(
			'price_tag_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} li.product .ec-product__summary' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'divider_heading',
			[
				'label' => esc_html__( 'Divider', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'title_color',
			array_merge(
				[
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} li.product .woocommerce-loop-product__title' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_2,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_SECONDARY,
					],
				]
			)
		);

		$this->add_control(
			'title_hover_color',
			array_merge(
				[
					'label'     => esc_html__( 'Hover Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} li.product .woocommerce-loop-product__title:hover' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_2,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_SECONDARY,
					],
				]
			)
		);

		$this->add_responsive_control(
			'divider_size',
			[
				'label'     => esc_html__( 'Size', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 1,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-grid .ec-divider' => 'border: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'divider_width',
			[
				'label'      => esc_html__( 'Width', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'%',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 600,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-grid .ec-divider' => 'flex: 0 1 {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'divider_style',
			[
				'label'     => esc_html__( 'Style', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'solid'  => esc_html__( 'Solid', 'companion-elementor' ),
					'dashed' => esc_html__( 'Dashed', 'companion-elementor' ),
					'dotted' => esc_html__( 'Dotted', 'companion-elementor' ),
				],
				'default'   => 'solid',
				'selectors' => [
					'{{WRAPPER}} .ec-grid .ec-divider' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'divider_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#444',
				'selectors' => [
					'{{WRAPPER}} .ec-grid .ec-divider' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'divider_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-grid .ec-divider' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}
}
