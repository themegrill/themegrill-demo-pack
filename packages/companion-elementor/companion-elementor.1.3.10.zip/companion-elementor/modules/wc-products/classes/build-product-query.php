<?php
/**
 * Build queries for rendering products via the loop.
 *
 * @since 1.0.7
 */

namespace CompanionElementor\Modules\WcProducts\Classes;

defined( 'ABSPATH' ) || exit;

class Build_Product_Query {
	public $settings = '';

	public $skin = '';

	public function __construct( $skin, $settings, $filter ) {
		$this->settings = $settings;
		$this->skin     = $skin;
	}

	public function query_products() {
		$query_args = $this->query_products_args();

		return new \WP_Query( $query_args );
	}

	public function query_products_args() {
		$skin_id    = $this->skin;
		$control_id = str_replace( '-', '_', $skin_id );
		$settings   = $this->settings;

		if ( '' !== $control_id ) {
			$control_id = $control_id . '_';
		}

		$ppp                         = ( '' === $settings[ $control_id . 'products_per_page' ] ) ? - 1 : $settings[ $control_id . 'products_per_page' ];
		$source                      = ! empty( $settings['source'] ) ? $settings['source'] : '';
		$product_visibility_term_ids = wc_get_product_visibility_term_ids();

		$query_args = [
			'post_type'      => 'product',
			'posts_per_page' => $ppp,
			'post_status'    => 'publish',
		];

		$filter = $settings['product_category_filter'] ? $settings['product_category_filter'] : 'IN';
		$terms  = $settings['terms_product_category_choices'] ? $settings['terms_product_category_choices'] : array();

		if ( $terms ) {
			$query_args['tax_query'][] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => $terms,
				'operator' => $filter,
			);
		}

		switch ( $source ) {
			case 'sales':
				$product_ids_on_sale    = wc_get_product_ids_on_sale();
				$product_ids_on_sale[]  = 0;
				$query_args['post__in'] = $product_ids_on_sale;

				break;

			case 'featured':
				$query_args['tax_query'][] = array(
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => $product_visibility_term_ids['featured'],
				);

				break;

			case 'top-rated':
				$query_args['meta_key'] = '_wc_average_rating';
				$query_args['orderby']  = 'meta_value_num';
				$query_args['order']    = 'DESC';

				break;
		}

		return $query_args;
	}
}
