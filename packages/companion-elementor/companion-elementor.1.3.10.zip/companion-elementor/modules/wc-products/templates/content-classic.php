<?php
/**
 * Classic skin single product content.
 *
 * @since 1.0.7
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

$product_id = $product->get_id();
?>
<li <?php wc_product_class( '', $product ); ?>>
	<div class="ec-product__thumbnail">
		<?php
		woocommerce_template_loop_product_link_open();
		$this->render_sale();
		$this->render_thumbnail();
		woocommerce_template_loop_product_link_close();
		$this->render_image_overlay();
		?>
	</div> <!-- /.ec-product__thumbnail -->

	<div class="ec-product__summary">
		<?php
		woocommerce_template_loop_product_link_open();
		$this->render_title();
		$this->render_divider();
		woocommerce_template_loop_product_link_close();
		$this->render_rating();
		$this->render_price();
		$this->render_cart_button();
		$this->render_product_description();
		?>
	</div> <!-- /.ec-product-summary -->
</li>
