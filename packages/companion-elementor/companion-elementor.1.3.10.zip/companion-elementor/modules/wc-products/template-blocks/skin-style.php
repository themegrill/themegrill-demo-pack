<?php
/**
 * Main template file.
 *
 * @since 1.0.7
 */

namespace CompanionElementor\Modules\WcProducts\TemplateBlocks;

use CompanionElementor\Modules\WcProducts\Classes\Build_Product_Query;

defined( 'ABSPATH' ) || exit;

abstract class Skin_Style {
	public static $settings;
	public static $skin;
	public static $query_obj;
	public static $query;

	public function render( $style, $settings, $id ) {
		self::$settings  = $settings;
		self::$skin      = $style;
		self::$query_obj = new Build_Product_Query( $style, $settings, '' );
		self::$query     = self::$query_obj->query_products();
		$wrapper_class   = 'ec-grid__' . $this->get_control_value( 'columns' ) . ' ec-grid__tablet-' . $this->get_control_value( 'columns_tablet' ) . ' ec-grid__mobile-' . $this->get_control_value( 'columns_mobile' ) . ' ' . $this->get_wrapper_class();
		?>
		<div class="woocommerce ec-products-wrapper <?php echo esc_attr( $wrapper_class ); ?>">
			<ul class="ec-grid products">
				<?php $this->get_content(); ?>
			</ul> <!-- /.ec-grid -->
		</div> <!-- /.ec-products-wrapper -->
		<?php
	}

	public function get_control_value( $control_id ) {
		if ( isset( self::$settings[ self::$skin . '_' . $control_id ] ) ) {
			return self::$settings[ self::$skin . '_' . $control_id ];
		} else {
			return null;
		}
	}

	public function get_wrapper_class() {
		return 'ec-product__skin-' . self::$skin;
	}

	public function get_content() {
		$products_query = self::$query;

		if ( $products_query->have_posts() ) {
			while ( $products_query->have_posts() ) {
				$products_query->the_post();

				include COMPANION_ELEMENTOR_ABSPATH . '/modules/wc-products/templates/content-' . self::$skin . '.php';
			}

			wp_reset_postdata();
		}
	}

	public function render_title() {
		if ( 'yes' === $this->get_control_value( 'show_title' ) ) {
			woocommerce_template_loop_product_title();
		}
	}

	public function render_sale() {
		if ( 'yes' === $this->get_control_value( 'show_sale' ) ) {
			woocommerce_show_product_loop_sale_flash();
		}
	}

	public function render_thumbnail() {
		woocommerce_template_loop_product_thumbnail();
	}

	public function render_rating() {
		if ( 'yes' === $this->get_control_value( 'show_rating' ) ) {
			woocommerce_template_loop_rating();
		}
	}

	public function render_price() {
		if ( 'yes' === $this->get_control_value( 'show_price' ) ) {
			woocommerce_template_loop_price();
		}
	}

	public function render_cart_button() {
		if ( 'yes' === $this->get_control_value( 'show_add_to_cart' ) ) {
			woocommerce_template_loop_add_to_cart();
		}
	}
	
	public function render_product_description() {
		if ( 'yes' === $this->get_control_value( 'show_product_description' ) ) {
			woocommerce_template_single_excerpt();
		}
	}

	public function render_divider() {
		if ( 'yes' === $this->get_control_value( 'show_divider' ) ) {
			echo '<hr class="ec-divider" />';
		}
	}

	public function render_image_overlay() {
		if ( 'yes' === $this->get_control_value( 'image_overlay' ) ) {
			?>
				<div class="ec-overlay"></div>
			<?php
		}
	}
}
