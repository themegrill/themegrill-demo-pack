<?php
/**
 * Instantiate classic skin.
 *
 * @since 1.0.7
 */

namespace CompanionElementor\Modules\WcProducts\TemplateBlocks;

defined( 'ABSPATH' ) || exit;

class Skin_Classic extends Skin_Style {
	private static $instance;

	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}
