<?php
/**
 * Module class for WC Products widget.
 *
 * @since 1.0.7
 */

namespace CompanionElementor\Modules\WcProducts;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public static function is_active() {
		return class_exists( 'woocommerce' );
	}

	public function get_widgets() {
		return [
			'Wc_Products',
		];
	}

	public function get_name() {
		return 'wc-products';
	}

}
