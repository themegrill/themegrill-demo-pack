<?php

namespace CompanionElementor\Modules\Counter\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

defined( 'ABSPATH' ) || exit;

class Counter extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-counter';
	}

	public function get_title() {
		return __( 'Counter', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-counter';
	}

	public function get_keywords() {
		return [ 'companion', 'counter', 'timer' ];
	}

	public function get_script_depends() {
		return [ 'jquery-numerator' ];
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_style_number_controls();
		$this->register_style_title_controls();
		$this->register_style_icon_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'ec_counter_section',
			[
				'label' => esc_html__( 'Counter', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'duration',
			[
				'label'   => esc_html__( 'Animation Duration', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4000,
				'min'     => 100,
				'step'    => 500,
			]
		);

		$this->add_responsive_control(
			'content_alignment',
			[
				'label'       => esc_html__( 'Content Alignment', 'companion-elementor' ),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'     => 'center',
				'selectors'   => [
					'{{WRAPPER}} .ec-counter' => 'text-align: {{VALUE}};',
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'icon_v5',
			[
				'label'            => esc_html__( 'Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => [
					'value'   => 'fa fa-child',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'number_heading',
			[
				'label'     => esc_html__( 'Number', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'starting_number',
			[
				'label'   => esc_html__( 'Starting Number', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 0,
			]
		);

		$this->add_control(
			'ending_number',
			[
				'label'   => esc_html__( 'Ending Number', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 500,
			]
		);

		$this->add_control(
			'prefix',
			[
				'label' => esc_html__( 'Prefix', 'companion-elementor' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'postfix',
			[
				'label' => esc_html__( 'Postfix', 'companion-elementor' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label'     => esc_html__( 'Title', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title',
			[
				'label'   => esc_html__( 'Title', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Happy Clients', 'companion-elementor' ),
			]
		);

		$this->end_controls_section();
	}

	private function register_style_number_controls() {
		$this->start_controls_section(
			'ec_counter_number_style_section',
			[
				'label' => esc_html__( 'Number', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'number_color',
			array_merge(
				[
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ec-counter-number-wrap' => 'color: {{VALUE}};',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_1,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_PRIMARY,
					],
				]
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'number_typography',
				'selector' => '{{WRAPPER}} .ec-counter-number-wrap',
			]
		);

		$this->add_responsive_control(
			'number_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-counter-number-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_title_controls() {
		$this->start_controls_section(
			'ec_counter_title_style_section',
			[
				'label' => esc_html__( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .ec-title',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_icon_controls() {
		$this->start_controls_section(
			'ec_counter_icon_style_section',
			[
				'label' => esc_html__( 'Icon', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_font_size',
			[
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-icon i'   => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-icon svg' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-icon svg' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'icon_tabs' );

		$this->start_controls_tab(
			'icon_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'icon_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#269bd1',
				'selectors' => [
					'{{WRAPPER}} .ec-icon i'   => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-icon svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'icon_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-icon:hover i'   => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-icon:hover svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/counter-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		?>

		<div class="ec-counter-wrapper">
			<div class="ec-counter">

				<div class="ec-icon">
					<?php
					$migrated = isset( $settings['__fa4_migrated']['icon_v5'] );
					$is_new   = ! array_key_exists( 'icon', $settings );

					if ( $is_new || $migrated ) :
						Icons_Manager::render_icon( $settings['icon_v5'], [ 'aria-hidden' => 'true' ] );
					else :
						?>
						<i class="<?php echo ( is_array( $settings['icon'] ) ? $settings['icon']['value'] : $settings['icon'] ); ?>" aria-hidden="true"></i>
					<?php endif; ?>
				</div> <!-- /.ec-icon -->

				<div class="ec-counter-number-wrap">
					<span class="ec-number-prefix"><?php echo $settings['prefix']; ?></span>
					<span class="ec-number" data-duration="<?php echo esc_attr( $settings['duration'] ); ?>"
						data-to-value="<?php echo esc_attr( $settings['ending_number'] ); ?>"
						data-delimiter=","><?php echo $settings['starting_number']; ?></span>
					<span class="ec-number-postfix"><?php echo $settings['postfix']; ?></span>
				</div> <!-- /.ec-counter-items-wrap -->

				<h3 class="ec-title"><?php echo $settings['title']; ?></h3> <!-- /.ec-title -->

			</div> <!-- /.ec-counter -->
		</div> <!-- /.ec-counter-wrapper -->

		<?php
	}
}
