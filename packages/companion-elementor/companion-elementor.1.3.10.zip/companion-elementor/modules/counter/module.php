<?php

namespace CompanionElementor\Modules\Counter;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Counter',
		];
	}

	public function get_name() {
		return 'counter';
	}

}
