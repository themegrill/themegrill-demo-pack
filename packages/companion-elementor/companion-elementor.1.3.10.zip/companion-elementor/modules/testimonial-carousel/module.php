<?php

namespace CompanionElementor\Modules\TestimonialCarousel;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Testimonial_Carousel',
		];
	}

	public function get_name() {
		return 'testimonial-carousel';
	}

}
