<?php

namespace CompanionElementor\Modules\TestimonialCarousel\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Utils;
use Elementor\Plugin;

defined( 'ABSPATH' ) || exit;

class Testimonial_Carousel extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-testimonial-carousel';
	}

	public function get_title() {
		return __( 'Testimonial Carousel', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-testimonial-carousel';
	}

	public function get_keywords() {
		return [ 'companion', 'testimonials carousel', 'slider' ];
	}

	/**
	 * Get style dependencies.
	 *
	 * Retrieve the list of style dependencies the widget requires.
	 *
	 * @since 3.24.0
	 * @access public
	 *
	 * @return array Widget style dependencies.
	 */
	public function get_style_depends(): array {
		return [ 'e-swiper', 'widget-image-carousel' ];
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_settings_controls();
		$this->register_style_general_controls();
		$this->register_style_slides_controls();
		$this->register_style_image_controls();
		$this->register_style_name_controls();
		$this->register_style_message_controls();
        $this->register_style_rating_controls();
		$this->register_style_navigation_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'ec_testimonial_carousel_slides_section',
			[
				'label' => esc_html__( 'Slides', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$slides_repeater = new Repeater();

		$slides_repeater->start_controls_tabs( 'slide_content_repeater_tab' );

		$slides_repeater->start_controls_tab(
			'slide_content_tab',
			[
				'label' => esc_html__( 'Content', 'companion-elementor' ),
			]
		);

		$slides_repeater->add_control(
			'author_name',
			[
				'label'       => esc_html__( 'Name', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Add Author Name Here', 'companion-elementor' ),
				'label_block' => true,
			]
		);

		$slides_repeater->add_control(
			'author_caption',
			[
				'label'       => esc_html__( 'Caption', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Add Author Info( Designation ) Here', 'companion-elementor' ),
				'label_block' => true,
			]
		);

		$slides_repeater->add_control(
			'author_message',
			[
				'label'   => esc_html__( 'Message', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'companion-elementor' ),
			]
		);

		$slides_repeater->add_control(
			'author_image',
			[
				'label'   => esc_html__( 'Image', 'companion-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

        $slides_repeater->add_control(
			'rating_value',
			array(
				'label'   => esc_html__( 'Rating Value', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 5,
				'min'     => 0,
				'max'     => 5,
			)
		);

		$slides_repeater->end_controls_tab();

		$slides_repeater->start_controls_tab(
			'slide_style_tab',
			[
				'label' => esc_html__( 'Style', 'companion-elementor' ),
			]
		);

		$slides_repeater->add_control(
			'custom_style',
			[
				'label'       => esc_html__( 'Custom', 'companion-elementor' ),
				'type'        => Controls_Manager::SWITCHER,
				'description' => esc_html__( 'Overwrites the global styles.', 'companion-elementor' ),
			]
		);

		$slides_repeater->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'current_slide_bg',
				'label'     => esc_html__( 'Background', 'companion-elementor' ),
				'types'     => [
					'classic',
					'gradient',
				],
				'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}}.swiper-slide',
				'condition' => [
					'custom_style' => 'yes',
				],
			]
		);

		$slides_repeater->add_control(
			'current_author_name_color',
			[
				'label'     => esc_html__( 'Name Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .ec-author-name' => 'color: {{VALUE}}',
				],
				'condition' => [
					'custom_style' => 'yes',
				],
			]
		);

		$slides_repeater->add_control(
			'current_author_caption_color',
			[
				'label'     => esc_html__( 'Caption Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .ec-author-caption' => 'color: {{VALUE}}',
				],
				'condition' => [
					'custom_style' => 'yes',
				],
			]
		);

		$slides_repeater->add_control(
			'current_author_message_color',
			[
				'label'     => esc_html__( 'Message Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .ec-message' => 'color: {{VALUE}}',
				],
				'condition' => [
					'custom_style' => 'yes',
				],
			]
		);

		$slides_repeater->end_controls_tab();

		$slides_repeater->end_controls_tabs();

		$this->add_control(
			'slides',
			[
				'label'       => esc_html__( 'Slides', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $slides_repeater->get_controls(),
				'default'     => [
					[
						'author_name'    => esc_html__( 'John Doe', 'companion-elementor' ),
						'author_caption' => esc_html__( 'CEO', 'companion-elementor' ),
					],
					[
						'author_name'    => esc_html__( 'John Doe', 'companion-elementor' ),
						'author_caption' => esc_html__( 'CEO', 'companion-elementor' ),
					],
				],
				'title_field' => '{{{ author_name }}}',
			]
		);

		$this->end_controls_section();
	}

	private function register_settings_controls() {
		$this->start_controls_section(
			'ec_testimonial_carousel_settings_section',
			[
				'label' => esc_html__( 'Settings', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$spv = range( 1, 5 );
		$spv = array_combine( $spv, $spv );

		$this->add_responsive_control(
			'spv',
			[
				'type'               => Controls_Manager::SELECT,
				'label'              => esc_html__( 'Slides Per View', 'companion-elementor' ),
				'options'            => $spv,
				'frontend_available' => true,
				'desktop_default'    => 3,
				'tablet_default'     => 2,
				'mobile_default'     => 1,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'        => esc_html__( 'Autoplay', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'delay',
			[
				'label'     => esc_html__( 'Delay', 'companion-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 9999999999,
				'step'      => 1,
				'default'   => 4000,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'loop',
			[
				'label'        => esc_html__( 'Loop', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'speed',
			[
				'label'   => esc_html__( 'Speed', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 9999999999,
				'step'    => 1,
				'default' => 500,
			]
		);

		$this->add_control(
			'navigation',
			[
				'label'   => esc_html__( 'Navigation', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'both',
				'options' => [
					'both'   => esc_html__( 'Arrows &amp; Dots', 'companion-elementor' ),
					'arrows' => esc_html__( 'Arrows', 'companion-elementor' ),
					'dots'   => esc_html__( 'Dots', 'companion-elementor' ),
					'none'   => esc_html__( 'None', 'companion-elementor' ),
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_general_controls() {
		$this->start_controls_section(
			'ec_testimonial_carousel_general_section',
			[
				'label' => esc_html__( 'General', 'companion_elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'slide_wrapper_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion_elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-testimonial-carousel' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_slides_controls() {
		$this->start_controls_section(
			'ec_testimonial_carousel_slides_style_section',
			[
				'label' => esc_html__( 'Slides', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'slide_alignment',
			[
				'label'        => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'      => 'center',
				'prefix_class' => 'ec-testimonial-carousel--',
				'selectors'    => [
					'{{WRAPPER}} .ec-testimonial' => 'text-align: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'slide_layout',
			[
				'label'       => esc_html__( 'Layout', 'companion-elementor' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'imageinfo',
				'options'     => [
					'imageinfo'  => esc_html__( 'Image & Info | Message', 'companion-elementor' ),
					'image-info' => esc_html__( 'Image | Info | Message', 'companion-elementor' ),
                    'rating-info' => esc_html__( 'Rating | Message |  Info', 'companion-elementor' ),
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'imageinfo_infobox_position',
			[
				'label'              => esc_html__( 'Info Box Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'up',
				'options'            => [
					'left'  => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					],
					'up'    => [
						'title' => esc_html__( 'Up', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					],
					'down'  => [
						'title' => esc_html__( 'Down', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'frontend_available' => true,
				'condition'          => [
					'slide_layout' => 'imageinfo',
				],
			]
		);

		$this->add_control(
			'imageinfo_image_position',
			[
				'label'              => esc_html__( 'Image Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'up',
				'options'            => [
					'left'  => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					],
					'up'    => [
						'title' => esc_html__( 'Up', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					],
					'down'  => [
						'title' => esc_html__( 'Down', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'frontend_available' => true,
				'condition'          => [
					'slide_layout' => 'imageinfo',
				],
			]
		);

		$this->add_control(
			'image_info_image_position',
			[
				'label'              => esc_html__( 'Image Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'up',
				'options'            => [
					'left'  => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					],
					'up'    => [
						'title' => esc_html__( 'Up', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					],
					'down'  => [
						'title' => esc_html__( 'Down', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'frontend_available' => true,
				'condition'          => [
					'slide_layout' => 'image-info',
				],
			]
		);

		$this->add_control(
			'image_info_infobox_position',
			[
				'label'              => esc_html__( 'Info Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'up',
				'options'            => [
					'left'  => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					],
					'up'    => [
						'title' => esc_html__( 'Up', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					],
					'down'  => [
						'title' => esc_html__( 'Down', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'frontend_available' => true,
				'condition'          => [
					'slide_layout' => 'image-info',
				],
			]
		);

        $this->add_control(
			'rating_info_infobox_position',
			array(
				'label'              => esc_html__( 'Info Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'down',
				'options'            => array(
					'left'  => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					),
					'up'    => array(
						'title' => esc_html__( 'Up', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					),
					'down'  => array(
						'title' => esc_html__( 'Down', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'frontend_available' => true,
				'condition'          => array(
					'slide_layout' => 'rating-info',
				),
			)
		);

		$this->add_control(
			'rating_info_image_position',
			array(
				'label'              => esc_html__( 'Image Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'up',
				'options'            => array(
					'left'  => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					),
					'up'    => array(
						'title' => esc_html__( 'Up', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					),
					'down'  => array(
						'title' => esc_html__( 'Down', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'frontend_available' => true,
				'condition'          => array(
					'slide_layout' => 'rating-info',
				),
			)
		);

		$this->add_control(
			'rating_info_rating_position',
			array(
				'label'              => esc_html__( 'Rating Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'up',
				'options'            => array(
					'left'  => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					),
					'up'    => array(
						'title' => esc_html__( 'Up', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					),
					'down'  => array(
						'title' => esc_html__( 'Down', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'frontend_available' => true,
				'condition'          => array(
					'slide_layout' => 'rating-info',
				),
			)
            );

		$this->add_responsive_control(
			'slide_spacing',
			[
				'label'           => esc_html__( 'Space Between', 'companion-elementor' ),
				'type'            => Controls_Manager::SLIDER,
				'default'         => [
					'size' => 30,
				],
				'size_units'      => [
					'px',
				],
				'range'           => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 10,
					'unit' => 'px',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'slide_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .swiper-slide',
			]
		);

		$this->add_responsive_control(
			'slide_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-slide' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'           => 'slide_border',
				'selector'       => '{{WRAPPER}} .swiper-slide',
				'fields_options' => [
					'border' => [
						'default' => 'solid',
					],
					'width'  => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color'  => [
						'default' => '#e9ecef',
					],
				],
			]
		);

		$this->add_responsive_control(
			'slide_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-slide' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'slide_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .swiper-slide',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_image_controls() {
		$this->start_controls_section(
			'ec_testimonial_carousel_image_style_section',
			[
				'label' => esc_html__( 'Image', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-author-image img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'author_image_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-author-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'author_image_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-author-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'author_image_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-author-image img',
			]
		);

		$this->add_responsive_control(
			'author_image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-author-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'author_image_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-author-image img',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_name_controls() {
		$this->start_controls_section(
			'ec_testimonial_carousel_name_style_section',
			[
				'label' => esc_html__( 'Name', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'author_name_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-author-name' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'author_name_typography',
				'selector' => '{{WRAPPER}} .ec-author-name',
			]
		);

		$this->add_responsive_control(
			'author_name_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-author-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'ec_testimonial_carousel_caption_style_section',
			[
				'label' => esc_html__( 'Caption', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'author_caption_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-author-caption' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'author_caption_typography',
				'selector' => '{{WRAPPER}} .ec-author-caption',
			]
		);

		$this->add_responsive_control(
			'author_caption_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-author-caption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_message_controls() {
		$this->start_controls_section(
			'ec_testimonial_carousel_message_style_section',
			[
				'label' => esc_html__( 'Message', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'author_message_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-message' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'author_message_typography',
				'selector' => '{{WRAPPER}} .ec-message',
			]
		);

		$this->add_responsive_control(
			'author_message_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-message' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

    private function register_style_rating_controls() {
		$this->start_controls_section(
			'ec_testimonial_carousel_rating_style_section',
			array(
				'label' => esc_html__( 'Rating', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'rating_size',
			array(
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
				),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-rating svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'rating_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-rating svg' => 'fill: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'rating_margin',
			array(
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-rating' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_navigation_controls() {
		$this->start_controls_section(
			'ec_testimonial_carousel_navigation_style_section',
			[
				'label' => esc_html__( 'Navigation', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'arrows_heading',
			[
				'label'     => esc_html__( 'Arrows', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'arrow_left_icon_v5',
			[
				'label'            => esc_html__( 'Left Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'arrow_left_icon',
				'default'          => [
					'value'   => 'fa fa-chevron-left',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'arrow_right_icon_v5',
			[
				'label'            => esc_html__( 'Right Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'arrow_right_icon',
				'default'          => [
					'value'   => 'fa fa-chevron-right',
					'library' => 'solid',
				],
			]
		);

		$this->add_responsive_control(
			'arrow_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'em',
					'size' => 2.4,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-nav .ec-nav-next' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'arrow_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-nav .ec-nav-next i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'arrow_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'arrow_border',
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			]
		);

		$this->add_control(
			'arrow_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'arrow_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-nav .ec-nav-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'arrow_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			]
		);

		$this->start_controls_tabs(
			'arrow_tabs'
		);

		$this->start_controls_tab(
			'arrow_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'arrow_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-nav .ec-nav-next i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'arrow_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'arrow_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'arrow_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-nav .ec-nav-next:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev:hover i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'arrow_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next:hover, {{WRAPPER}} .ec-nav .ec-nav-prev:hover',
			]
		);

		$this->add_control(
			'arrow_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-nav .ec-nav-next:hover' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'dots_heading',
			[
				'label'     => esc_html__( 'Dots', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'dot_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'dot_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 32,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 2,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 2,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 18,
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/testimonial-carousel-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$contents         = $this->get_settings_for_display();
		$testimonials     = $contents['slides'];
		$arrow_left_icon  = ! empty( $contents['arrow_left_icon_v5'] ) ? $contents['arrow_left_icon_v5'] : 'fa fa-chevron-left';
		$arrow_right_icon = ! empty( $contents['arrow_right_icon_v5'] ) ? $contents['arrow_right_icon_v5'] : 'fa fa-chevron-right';

		$slide_layout               = $contents['slide_layout'];
		$imageinfo_image_position   = $contents['imageinfo_image_position'];
		$imageinfo_infobox_position = $contents['imageinfo_infobox_position'];

		$image_info_image_position   = $contents['image_info_image_position'];
		$image_info_infobox_position = $contents['image_info_infobox_position'];

		$image_position   = ( 'imageinfo' === $slide_layout ) ? 'ec-imageinfo-image--' . $imageinfo_image_position : 'ec-image-info-image--' . $image_info_image_position;
		$infobox_position = ( 'imageinfo' === $slide_layout ) ? 'ec-imageinfo-box--' . $imageinfo_infobox_position : 'ec-image-info-box--' . $image_info_infobox_position;

		/**
		 * Image | Info
		 */
		$layout_class         = '';
		$layout_individual    = false;
		$layout_message_info  = false;
		$layout_message_image = false;
		// Message with Info.

		if ( 'image-info' == $slide_layout ) {
			// Individual.
			if ( ( $image_info_image_position === $image_info_infobox_position ) ||
				( 'left' === $image_info_image_position && 'right' === $image_info_infobox_position ) ||
				( 'right' === $image_info_image_position && 'left' === $image_info_infobox_position ) ||
				( 'up' === $image_info_image_position && 'down' === $image_info_infobox_position ) ||
				( 'down' === $image_info_image_position && 'up' === $image_info_infobox_position )
			) {
				$layout_individual = true;

				$layout_class = 'ec-layout-individual';
			} else {
				if ( ( 'left' === $image_info_image_position ) || ( 'right' === $image_info_image_position ) || ( 'down' === $image_info_infobox_position ) ) {
					$layout_message_info = true;

					if ( 'left' === $image_info_infobox_position ) {
						$layout_message_info = false;
					}
					$layout_class = 'ec-layout-message-info';
				}

				// Message with Image.
				if ( ( 'left' === $image_info_infobox_position ) || ( 'right' === $image_info_infobox_position ) || ( 'down' === $image_info_image_position ) ) {
					$layout_message_image = true;

					$layout_class = 'ec-layout-message-image';
				}
			}
		}

		// Testimonial carousel custom JS options.
		$options                       = array();
		$options['spv']                = $contents['spv'];
		$options['spvTablet']          = $contents['spv_tablet'];
		$options['spvMobile']          = $contents['spv_mobile'];
		$options['autoplay']           = $contents['autoplay'];
		$options['delay']              = $contents['delay'];
		$options['loop']               = $contents['loop'];
		$options['speed']              = $contents['speed'];
		$options['spaceBetween']       = ! array_key_exists( 'slide_spacing', $contents ) ? 30 : $contents['slide_spacing']['size'];
		$options['spaceBetweenTablet'] = ! array_key_exists( 'slide_spacing_tablet', $contents ) ? 20 : $contents['slide_spacing_tablet']['size'];
		$options['spaceBetweenMobile'] = ! array_key_exists( 'slide_spacing_mobile', $contents ) ? 10 : $contents['slide_spacing_mobile']['size'];

		$options['arrows'] = in_array(
			$contents['navigation'],
			array(
				'arrows',
				'both',
			),
			true
		);

		$options['dots'] = in_array(
			$contents['navigation'],
			array(
				'dots',
				'both',
			),
			true
		);

		$dots         = $options['dots'] ? 'ec-has-dots' : '';
		$swiper_class = Plugin::$instance->experiments->is_feature_active( 'e_swiper_latest' ) ? 'swiper' : 'swiper-container';
		?>

		<div class="ec-testimonial-carousel-wrapper">
			<div class="ec-testimonial-carousel swiper-container <?php echo esc_attr( $swiper_class ); ?> <?php echo esc_attr( $dots ); ?> <?php echo esc_attr( $layout_class ); ?> <?php echo esc_attr( $image_position ); ?> <?php echo esc_attr( $infobox_position ); ?>"
				data-carousel_options=<?php echo wp_json_encode( $options ); ?>
			>
				<div class="swiper-wrapper">

					<?php foreach ( $testimonials as $testimonial ) : ?>
						<div class="swiper-slide elementor-repeater-item-<?php echo esc_attr( $testimonial['_id'] ); ?>">
							<?php
							if ( ( 'image-info' === $slide_layout ) && $layout_message_info ) {
								$this->layout_message_info( $testimonial );
							} elseif ( ( 'image-info' === $slide_layout ) && $layout_message_image ) {
								$this->layout_message_image( $testimonial );
							} elseif ( ( 'image-info' === $slide_layout ) && $layout_individual ) {
								$this->layout_individual( $testimonial );
							} elseif ('rating-info' === $slide_layout) {
								$this->layout_rating( $testimonial );
							} else {
								$this->layout( $testimonial );
							}
							?>
						</div> <!-- /.swiper-slide -->
					<?php endforeach; ?>

				</div> <!-- /.swiper-wrapper -->

				<?php if ( 'both' === $contents['navigation'] || 'dots' === $contents['navigation'] ) : ?>
					<div class="ec-pagination"></div>
				<?php endif; ?>

				<?php if ( 'both' === $contents['navigation'] || 'arrows' === $contents['navigation'] ) : ?>
					<div class="ec-nav">
						<span class="ec-nav-prev">
							<?php
							$migrated = isset( $contents['__fa4_migrated']['arrow_left_icon_v5'] );
							$is_new   = ! array_key_exists( 'arrow_left_icon', $contents );

							if ( $is_new || $migrated ) :
								Icons_Manager::render_icon( $arrow_left_icon, [ 'aria-hidden' => 'true' ] );
							else :
								?>
								<i class="<?php echo ( is_array( $contents['arrow_left_icon'] ) ? $contents['arrow_left_icon']['value'] : $contents['arrow_left_icon'] ); ?>" aria-hidden="true"></i>
							<?php endif; ?>
						</span>
						<span class="ec-nav-next">
							<?php
							$migrated = isset( $contents['__fa4_migrated']['arrow_right_icon_v5'] );
							$is_new   = ! array_key_exists( 'arrow_right_icon', $contents );

							if ( $is_new || $migrated ) :
								Icons_Manager::render_icon( $arrow_right_icon, [ 'aria-hidden' => 'true' ] );
							else :
								?>
								<i class="<?php echo ( is_array( $contents['arrow_right_icon'] ) ? $contents['arrow_right_icon']['value'] : $contents['arrow_right_icon'] ); ?>" aria-hidden="true"></i>
							<?php endif; ?>
						</span>
					</div>
				<?php endif; ?>
			</div> <!-- /.ec-testimonial-carousel -->
		</div> <!-- /.ec-testimonial-carousel-wrapper -->

		<?php
	}

	protected function layout_individual( $testimonial ) {
		$image_id  = $testimonial['author_image']['id'];
		$image_src = wp_get_attachment_image_src( $image_id, 'full' );
		$image_src = $image_src[0];

		if ( ! $image_id ) {
			$image_src = $testimonial['author_image']['url'];
		}

		?>
		<div class="ec-testimonial">

			<?php if ( $image_src ) : ?>
				<div class="ec-author-image">
					<img src="<?php echo esc_url( $image_src ); ?>" alt="<?php echo esc_html( $testimonial['author_name'] ); ?>">
				</div> <!-- /.ec-author-image -->
			<?php endif; ?>

			<div class="ec-author">

				<div class="ec-author-info">
					<?php if ( $testimonial['author_name'] ) : ?>
						<span class="ec-author-name">
										<?php echo esc_html( $testimonial['author_name'] ); ?>
									</span> <!-- /.ec-author-name -->
					<?php endif; ?>

					<?php if ( $testimonial['author_caption'] ) : ?>
						<span class="ec-author-caption">
										<?php echo esc_html( $testimonial['author_caption'] ); ?>
									</span> <!-- /.ec-author-caption -->
					<?php endif; ?>
				</div> <!-- /.ec-author-info -->
			</div> <!-- /.ec-author -->

			<?php if ( $testimonial['author_message'] ) : ?>
				<div class="ec-message">
					<?php echo esc_html( $testimonial['author_message'] ); ?>
				</div> <!-- /.ec-message -->
			<?php endif; ?>

		</div> <!-- /.ec-testimonial -->
		<?php
	}

	protected function layout_message_info( $testimonial ) {
		$image_id  = $testimonial['author_image']['id'];
		$image_src = wp_get_attachment_image_src( $image_id, 'full' );
		$image_src = $image_src[0];

		if ( ! $image_id ) {
			$image_src = $testimonial['author_image']['url'];
		}
		?>
		<div class="ec-testimonial">

			<?php if ( $image_src ) : ?>
				<div class="ec-author-image">
					<img src="<?php echo esc_url( $image_src ); ?>" alt="<?php echo esc_html( $testimonial['author_name'] ); ?>">
				</div> <!-- /.ec-author-image -->
			<?php endif; ?>

			<div class="ec-message-info">

				<div class="ec-author">
					<div class="ec-author-info">
						<?php if ( $testimonial['author_name'] ) : ?>
							<span class="ec-author-name">
										<?php echo esc_html( $testimonial['author_name'] ); ?>
									</span> <!-- /.ec-author-name -->
						<?php endif; ?>

						<?php if ( $testimonial['author_caption'] ) : ?>
							<span class="ec-author-caption">
										<?php echo esc_html( $testimonial['author_caption'] ); ?>
									</span> <!-- /.ec-author-caption -->
						<?php endif; ?>
					</div> <!-- /.ec-author-info -->
				</div> <!-- /.ec-author -->

				<?php if ( $testimonial['author_message'] ) : ?>
					<div class="ec-message">
						<?php echo esc_html( $testimonial['author_message'] ); ?>
					</div> <!-- /.ec-message -->
				<?php endif; ?>

			</div> <!-- /.ec-message-info -->


		</div> <!-- /.ec-testimonial -->
		<?php
	}

	protected function layout_message_image( $testimonial ) {
		$image_id  = $testimonial['author_image']['id'];
		$image_src = wp_get_attachment_image_src( $image_id, 'full' );
		$image_src = $image_src[0];

		if ( ! $image_id ) {
			$image_src = $testimonial['author_image']['url'];
		}
		?>
		<div class="ec-testimonial">

			<div class="ec-author">

				<div class="ec-author-info">
					<?php if ( $testimonial['author_name'] ) : ?>
						<span class="ec-author-name">
										<?php echo esc_html( $testimonial['author_name'] ); ?>
									</span> <!-- /.ec-author-name -->
					<?php endif; ?>

					<?php if ( $testimonial['author_caption'] ) : ?>
						<span class="ec-author-caption">
										<?php echo esc_html( $testimonial['author_caption'] ); ?>
									</span> <!-- /.ec-author-caption -->
					<?php endif; ?>
				</div> <!-- /.ec-author-info -->
			</div> <!-- /.ec-author -->

			<div class="ec-message-image">

				<?php if ( $image_src ) : ?>
					<div class="ec-author-image">
						<img src="<?php echo esc_url( $image_src ); ?>" alt="<?php echo esc_html( $testimonial['author_name'] ); ?>">
					</div> <!-- /.ec-author-image -->
				<?php endif; ?>

				<?php if ( $testimonial['author_message'] ) : ?>
					<div class="ec-message">
						<?php echo esc_html( $testimonial['author_message'] ); ?>
					</div> <!-- /.ec-message -->
				<?php endif; ?>

			</div> <!-- /.ec-message-image -->


		</div> <!-- /.ec-testimonial -->
		<?php
	}

	protected function layout( $testimonial ) {
		$image_id  = $testimonial['author_image']['id'];
		$image_src = wp_get_attachment_image_src( $image_id, 'full' );
		$image_src = ! empty( $image_src ) ? $image_src[0] : '';

		if ( ! $image_id ) {
			$image_src = $testimonial['author_image']['url'];
		}

		?>
		<div class="ec-testimonial">

			<div class="ec-author">
				<?php if ( $image_src ) : ?>
					<div class="ec-author-image">
						<img src="<?php echo esc_url( $image_src ); ?>" alt="<?php echo esc_html( $testimonial['author_name'] ); ?>">
					</div> <!-- /.ec-author-image -->
				<?php endif; ?>

				<div class="ec-author-info">
					<?php if ( $testimonial['author_name'] ) : ?>
						<span class="ec-author-name">
										<?php echo esc_html( $testimonial['author_name'] ); ?>
									</span> <!-- /.ec-author-name -->
					<?php endif; ?>

					<?php if ( $testimonial['author_caption'] ) : ?>
						<span class="ec-author-caption">
										<?php echo esc_html( $testimonial['author_caption'] ); ?>
									</span> <!-- /.ec-author-caption -->
					<?php endif; ?>
				</div> <!-- /.ec-author-info -->
			</div> <!-- /.ec-author -->

			<?php if ( $testimonial['author_message'] ) : ?>
				<div class="ec-message">
					<?php echo wp_kses_post( $testimonial['author_message'] ); ?>
				</div> <!-- /.ec-message -->
			<?php endif; ?>

		</div> <!-- /.ec-testimonial -->
		<?php
	}

    protected function layout_rating( $testimonial ) {
		$full_stars = intval( $testimonial['rating_value'] );
		$half_star  = ( $testimonial['rating_value'] - $full_stars ) >= 0.5 ? 1 : 0;
		?>
		<div class="ec-testimonial">
			<div class="ec-rating">
				<?php for ( $i = 1; $i <= $full_stars; $i++ ) : ?>
				<span>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
						<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2Z"/>
						<path fill-rule="evenodd" d="M12 1a1 1 0 0 1 .897.557l2.857 5.79 6.39.933a1 1 0 0 1 .554 1.706l-4.623 4.503 1.09 6.362a1 1 0 0 1-1.45 1.054L12 18.9l-5.715 3.005a1 1 0 0 1-1.45-1.054l1.09-6.362-4.623-4.503a1 1 0 0 1 .553-1.706l6.39-.934 2.858-5.789A1 1 0 0 1 12 1Zm0 3.259L9.807 8.702a1 1 0 0 1-.752.547l-4.907.717 3.55 3.457a1 1 0 0 1 .288.886l-.838 4.882 4.386-2.306a1 1 0 0 1 .931 0l4.387 2.306-.838-4.882a1 1 0 0 1 .288-.886l3.55-3.457-4.907-.717a1 1 0 0 1-.752-.547L12 4.26Z" clip-rule="evenodd"/>
					</svg>
				</span>
				<?php endfor; ?>
				<?php if ( $half_star ) : ?>
					<span>
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
							<path d="m20.976 8.865-5.462-.791-2.44-4.913a1.189 1.189 0 0 0-1.076-.661c-.425 0-.85.219-1.07.66L8.486 8.074l-5.462.79c-.98.142-1.372 1.34-.662 2.026l3.952 3.823-.936 5.398c-.132.771.487 1.39 1.18 1.39.184 0 .373-.043.555-.14l4.886-2.548 4.886 2.55c.181.094.37.137.553.137.694 0 1.314-.616 1.181-1.388l-.934-5.399 3.952-3.821c.71-.687.318-1.885-.661-2.026Zm-4.543 4.572-.676.653.16.924.728 4.21-3.81-1.989-.836-.436L12 5.03l1.905 3.833.417.84.933.135 4.262.617-3.084 2.982Z"/>
						</svg>
					</span>
				<?php endif; ?>
			</div>

			<?php if ( $testimonial['author_message'] ) : ?>
				<div class="ec-message">
					<?php echo esc_html( $testimonial['author_message'] ); ?>
				</div> <!-- /.ec-message -->
			<?php endif; ?>

			<div class="ec-author">

				<div class="ec-author-info">
					<?php if ( $testimonial['author_name'] ) : ?>
						<span class="ec-author-name">
										<?php echo esc_html( $testimonial['author_name'] ); ?>
									</span> <!-- /.ec-author-name -->
					<?php endif; ?>

					<?php if ( $testimonial['author_caption'] ) : ?>
						<span class="ec-author-caption">
										<?php echo esc_html( $testimonial['author_caption'] ); ?>
									</span> <!-- /.ec-author-caption -->
					<?php endif; ?>
				</div> <!-- /.ec-author-info -->
			</div> <!-- /.ec-author -->

		</div> <!-- /.ec-testimonial -->
		<?php
	}
}

