<?php

namespace CompanionElementor\Modules\Chart;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Chart',
		];
	}

	public function get_name() {
		return 'chart';
	}
}
