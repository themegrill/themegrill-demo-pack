<?php

namespace CompanionElementor\Modules\Chart\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || exit;

class Chart extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-chart';
	}

	public function get_title() {
		return __( 'Chart', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-align-end-v';
	}

	public function get_keywords() {
		return array( 'companion', 'Chart' );
	}

	protected function register_controls() {
		$this->register_bar_chart_controls();
		$this->register_bar_chart_settings_controls();
		$this->register_bar_chart_legends_controls();
		$this->register_bar_chart_tooltip_controls();
	}

	public function get_script_depends() {
		return array(
			'chart.js',
		);
	}

	private function register_bar_chart_controls() {
		$this->start_controls_section(
			'ec_bar_chart_section',
			array(
				'label' => __( 'Bar Chart', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'bar_chart_custom_styles',
			array(
				'label'        => esc_html__( 'Custom Styles', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$repeater->add_control(
			'bar_chart_custom_style_background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => array(
					'bar_chart_custom_styles' => 'yes',
				),
			)
		);

		$repeater->add_control(
			'bar_chart_custom_style_background_hover_color',
			array(
				'label'     => esc_html__( 'Background Hover Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => array(
					'bar_chart_custom_styles' => 'yes',
				),
			)
		);

		$repeater->add_control(
			'bar_chart_custom_style_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => array(
					'bar_chart_custom_styles' => 'yes',
				),
			)
		);

		$repeater->add_control(
			'bar_chart_custom_style_border_hover_color',
			array(
				'label'     => esc_html__( 'Border Hover Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => array(
					'bar_chart_custom_styles' => 'yes',
				),
			)
		);

		$repeater->add_control(
			'bar_chart_title',
			array(
				'label'       => __( 'Title', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Title', 'companion-elementor' ),
				'dynamic'     => array(
					'active' => true,
				),
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'bar_chart_data',
			[
				'label'       => __( 'Data', 'companion-elementor' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'bar_chart_list',
			array(
				'label'       => __( 'List Items', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						/* Translators: %s number. */
						'bar_chart_title' => sprintf( esc_html__( 'Laptops', 'companion-elementor' ), 1 ),
						'bar_chart_data'  => __( '24, 34, 45', 'companion-elementor' ),
						'bar_chart_custom_style_background_color' => '#F94144',
					),
					array(
						/* Translators: %s number. */
						'bar_chart_title' => sprintf( esc_html__( 'Phones', 'companion-elementor' ), 2 ),
						'bar_chart_data'  => __( '36, 56, 65', 'companion-elementor' ),
						'bar_chart_custom_style_background_color' => '#90BE6D',
					),
					array(
						/* Translators: %s number. */
						'bar_chart_title' => sprintf( esc_html__( 'Other', 'companion-elementor' ), 2 ),
						'bar_chart_data'  => __( '42, 54, 72', 'companion-elementor' ),
						'bar_chart_custom_style_background_color' => '#2D9CDB',
					),
				),
				'title_field' => '{{{ bar_chart_title }}}',
			)
		);

		$this->add_control(
			'bar_chart_labels',
			[
				'label'       => __( 'Labels', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'January, February, March', 'companion-elementor' ),
				'description' => __( 'Write multiple label with comma ( , ) separator. Example: January, February, March etc', 'companion-elementor' ),
			]
		);

		$this->end_controls_section();
	}

	private function register_bar_chart_settings_controls() {
		$this->start_controls_section(
			'ec_bar_chart_settings_section',
			array(
				'label' => __( 'Settings', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_responsive_control(
			'bar_chart_height',
			[
				'label'   => __( 'Chart Height', 'companion-elementor' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					'px' => [
						'min' => 50,
						'max' => 1500,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 150,
				],
			]
		);

		$this->add_control(
			'bar_chart_xaxes_grid_display',
			[
				'label'        => __( 'X Axes Grid Lines', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'bar_chart_yaxes_grid_display',
			[
				'label'        => __( 'Y Axes Grid Lines', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'bar_chart_xaxes_labels_display',
			[
				'label'        => __( 'Show X Axes Labels', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'bar_chart_yaxes_labels_display',
			[
				'label'        => __( 'Show Y Axes Labels', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'bar_char_axis_range',
			[
				'label'       => __( 'Scale Axis Range', 'companion-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 10,
				'description' => __( 'Maximum number for the scale.', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'bar_char_step_size',
			[
				'label'       => __( 'Step Size', 'companion-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 1,
				'step'        => 1,
				'description' => __( 'Step size for the scale.', 'companion-elementor' ),
			]
		);

		$this->end_controls_section();
	}

	private function register_bar_chart_legends_controls() {
		$this->start_controls_section(
			'ec_bar_chart_legends_section',
			array(
				'label' => __( 'Legends', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bar_chart_legends_show',
			array(
				'label'        => esc_html__( 'Show Legends', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'bar_chart_legends_shape',
			array(
				'label'   => esc_html__( 'Shape', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'rectangle',
				'options' => array(
					'rectangle' => esc_html__( 'Rectangle', 'companion-elementor' ),
					'point'     => esc_html__( 'Point', 'companion-elementor' ),
				),
			)
		);

		$this->add_control(
			'bar_chart_legends_position',
			array(
				'label'   => esc_html__( 'Position', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'top',
				'options' => array(
					'top'    => esc_html__( 'Top', 'companion-elementor' ),
					'bottom' => esc_html__( 'Bottom', 'companion-elementor' ),
					'left'   => esc_html__( 'Left', 'companion-elementor' ),
					'right'  => esc_html__( 'Right', 'companion-elementor' ),
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_bar_chart_tooltip_controls() {
		$this->start_controls_section(
			'ec_bar_chart_tooltip_section',
			array(
				'label' => __( 'Tooltip', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bar_chart_tooltip_show',
			array(
				'label'        => esc_html__( 'Tooltip', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings     = $this->get_settings_for_display();
		$chart_data   = $settings['bar_chart_list'];
		$labels_input = $settings['bar_chart_labels'];
		$chart_height = $settings['bar_chart_height']['size'];

		$labels   = explode( ', ', $labels_input );
		$datasets = [];

		foreach ( $chart_data as $index => $data ) {
			$datasets[] = [
				'label'                => $data['bar_chart_title'],
				'data'                 => $data['bar_chart_data'],
				'backgroundColor'      => $data['bar_chart_custom_style_background_color'] ?? '',
				'hoverBackgroundColor' => $data['bar_chart_custom_style_background_hover_color'] ?? '',
				'borderColor'          => $data['bar_chart_custom_style_border_color'] ?? '',
				'hoverBorderColor'     => $data['bar_chart_custom_style_border_hover_color'] ?? '',
			];
		}

		$data_settings = [
			'type' => 'bar',
			'data' => [
				'labels'                         => $labels,
				'datasets'                       => $datasets,
				'show_chart_tooltip'             => $settings['bar_chart_tooltip_show'] ?? true,
				'bar_chart_legends_show'         => $settings['bar_chart_legends_show'] ?? true,
				'bar_chart_legends_position'     => $settings['bar_chart_legends_position'] ?? 'top',
				'bar_chart_legends_shape'        => $settings['bar_chart_legends_shape'] ?? 'rectangle',
				'bar_chart_height'               => $settings['bar_chart_height'],
				'bar_chart_xaxes_grid_display'   => $settings['bar_chart_xaxes_grid_display'] ?? true,
				'bar_chart_yaxes_grid_display'   => $settings['bar_chart_yaxes_grid_display'] ?? true,
				'bar_chart_xaxes_labels_display' => $settings['bar_chart_xaxes_labels_display'] ?? true,
				'bar_chart_yaxes_labels_display' => $settings['bar_chart_yaxes_labels_display'] ?? true,
				'bar_char_axis_range'            => $settings['bar_char_axis_axis'] ?? 10,
				'bar_char_step_size'             => $settings['bar_char_step_size'] ?? 1,
			],
		];

		$this->add_render_attribute( 'chart', 'data-chart-settings', wp_json_encode( $data_settings ) );
		?>
			<div class="ec-chart-wrapper" <?php echo $this->get_render_attribute_string( 'chart' ); ?>>
				<canvas class="ec-chart" style="height: <?php echo esc_attr( $chart_height ); ?>px;"></canvas> <!-- Apply dynamic height -->
			</div>
		<?php
	}
}
