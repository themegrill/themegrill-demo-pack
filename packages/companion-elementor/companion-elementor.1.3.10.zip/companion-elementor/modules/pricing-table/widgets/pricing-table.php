<?php

namespace CompanionElementor\Modules\PricingTable\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

defined( 'ABSPATH' ) || exit;

class Pricing_Table extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-pricing-table';
	}

	public function get_title() {
		return __( 'Pricing Table', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-price-table';
	}

	public function get_keywords() {
		return [ 'companion', 'pricing table', 'price', 'table' ];
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_heading_controls();
		$this->register_pricing_controls();
		$this->register_features_controls();
		$this->register_cta_controls();
		$this->register_ribbon_controls();
		$this->register_style_pricing_table_controls();
		$this->register_style_header_controls();
		$this->register_style_pricing_controls();
		$this->register_style_features_controls();
		$this->register_style_cta_controls();
		$this->register_style_ribbon_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'section_general',
			[
				'label' => esc_html__( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'   => esc_html__( 'Layout', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1' => esc_html__( 'Style 1', 'companion-elementor' ),
					'2' => esc_html__( 'Style 2', 'companion-elementor' ),
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_heading_controls() {
		$this->start_controls_section(
			'section_heading',
			[
				'label' => esc_html__( 'Heading', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label' => esc_html__( 'Title', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'title',
			[
				'label'   => esc_html__( 'Text', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Unlimited', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'   => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h3',
				'options' => [
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'subtitle_heading',
			[
				'label'     => esc_html__( 'Subtitle', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'layout!' => '2',
				],
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Free 30 days trial', 'companion-elementor' ),
				'condition' => [
					'layout!' => '2',
				],
			]
		);

		$this->add_control(
			'subtitle_tag',
			[
				'label'     => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'p',
				'options'   => [
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				],
				'condition' => [
					'cta_type' => [ 'text', 'button' ],
					'layout!'  => '2',
				],
			]
		);

		$this->add_control(
			'description_heading',
			[
				'label'     => esc_html__( 'Description', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'companion-elementor' ),
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_control(
			'description_tag',
			[
				'label'     => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'p',
				'options'   => [
					'div' => esc_html__( 'div', 'companion-elementor' ),
					'p'   => esc_html__( 'p', 'companion-elementor' ),
				],
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_pricing_controls() {
		$this->start_controls_section(
			'section_pricing',
			[
				'label' => esc_html__( 'Pricing', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'pricing_position',
			[
				'label'     => esc_html__( 'Position', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'above-footer',
				'options'   => [
					'below-titles' => esc_html__( 'Below Titles', 'companion-elementor' ),
					'above-footer' => esc_html__( 'Above Footer', 'companion-elementor' ),
				],
				'condition' => [
					'layout' => '1',
				],
			]
		);

		$this->add_control(
			'currency',
			[
				'label'   => esc_html__( 'Currency', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( '$', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'price',
			[
				'label'   => esc_html__( 'Price', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( '8.99', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'discount_available',
			[
				'label'        => esc_html__( 'Discount', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);

		$this->add_control(
			'original_price',
			[
				'label'     => esc_html__( 'Original Price', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( '9.99', 'companion-elementor' ),
				'condition' => [
					'discount_available' => 'yes',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'original_price_position',
			[
				'label'     => esc_html__( 'Position', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'before',
				'options'   => [
					'before' => esc_html__( 'Before Price', 'companion-elementor' ),
					'above'  => esc_html__( 'Above Price', 'companion-elementor' ),
				],
				'separator' => 'after',
			]
		);

		$this->add_control(
			'duration',
			[
				'label'   => esc_html__( 'Duration', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( '/ Month', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'duration_position',
			[
				'label'   => esc_html__( 'Position', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'beside',
				'options' => [
					'below'  => esc_html__( 'Below', 'companion-elementor' ),
					'beside' => esc_html__( 'Beside', 'companion-elementor' ),
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_features_controls() {
		$this->start_controls_section(
			'section_features',
			[
				'label' => esc_html__( 'Features', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'text',
			[
				'label'   => esc_html__( 'Text', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Feature', 'companion-elementor' ),
			]
		);

		$repeater->add_control(
			'icon_v5',
			[
				'label'            => esc_html__( 'Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => [
					'value'   => 'fa fa-check-circle-o',
					'library' => 'solid',
				],
			]
		);

		$repeater->add_control(
			'overwrite_global',
			[
				'label'        => esc_html__( 'Overwrite Global Style', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);

		$repeater->add_control(
			'single_feature_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-pricing-table .ec-features {{CURRENT_ITEM}}.ec-feature .feature-text' => 'color: {{VALUE}}',
				],
				'condition' => [
					'overwrite_global' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'single_feature_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-pricing-table .ec-features {{CURRENT_ITEM}}.ec-feature i' => 'color: {{VALUE}}',
				],
				'condition' => [
					'overwrite_global' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'single_feature_bg',
				'label'     => esc_html__( 'Background', 'companion-elementor' ),
				'types'     => [
					'classic',
					'gradient',
				],
				'selector'  => '{{WRAPPER}} .ec-pricing-table .ec-features {{CURRENT_ITEM}}.ec-feature',
				'condition' => [
					'overwrite_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'features',
			[
				'label'       => esc_html__( 'Features', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						/* Translators: %s number. */
						'text' => sprintf( esc_html__( 'Feature %s', 'companion-elementor' ), 1 ),
					],
					[
						/* Translators: %s number. */
						'text' => sprintf( esc_html__( 'Feature %s', 'companion-elementor' ), 2 ),
					],
					[
						/* Translators: %s number. */
						'text' => sprintf( esc_html__( 'Feature %s', 'companion-elementor' ), 3 ),
					],
				],
				'title_field' => '{{{ text }}}',
			]
		);

		$this->end_controls_section();
	}

	private function register_cta_controls() {
		$this->start_controls_section(
			'section_cta',
			[
				'label' => esc_html__( 'Call To Action', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'cta_type',
			[
				'label'   => esc_html__( 'Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'button',
				'options' => [
					'none'   => esc_html__( 'None', 'companion-elementor' ),
					'text'   => esc_html__( 'Text', 'companion-elementor' ),
					'button' => esc_html__( 'Button', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'cta_text',
			[
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Select Plan', 'companion-elementor' ),
				'condition' => [
					'cta_type' => [ 'text', 'button' ],
				],
			]
		);

		$this->add_control(
			'cta_icon_v5',
			[
				'label'            => esc_html__( 'Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'cta_icon',
				'default'          => [
					'value'   => '',
					'library' => 'solid',
				],
				'condition'        => [
					'cta_type' => [ 'text', 'button' ],
				],
			]
		);

		$this->add_control(
			'cta_icon_position',
			[
				'label'     => esc_html__( 'Icon Position', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'before',
				'options'   => [
					'before' => esc_html__( 'Before', 'companion-elementor' ),
					'after'  => esc_html__( 'After', 'companion-elementor' ),
				],
				'condition' => [
					'cta_type' => [ 'text', 'button' ],
				],
			]
		);

		$this->add_control(
			'cta_link',
			[
				'label'         => esc_html__( 'Link', 'companion-elementor' ),
				'type'          => Controls_Manager::URL,
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
				'condition'     => [
					'cta_type' => [ 'text', 'button' ],
				],
			]
		);

		$this->add_control(
			'disclaimer_text',
			[
				'label'     => esc_html__( 'Disclaimer Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXTAREA,
				'default'   => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'companion-elementor' ),
				'condition' => [
					'cta_type' => [ 'text', 'button' ],
					'layout!'  => '2',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_ribbon_controls() {
		$this->start_controls_section(
			'section_ribbon',
			[
				'label'     => esc_html__( 'Ribbon', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'layout!' => '2',
				],
			]
		);

		$this->add_control(
			'ribbon_style',
			[
				'label'   => esc_html__( 'Style', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'none'     => esc_html__( 'None', 'companion-elementor' ),
					'corner'   => esc_html__( 'Corner', 'companion-elementor' ),
					'circular' => esc_html__( 'Circular', 'companion-elementor' ),
					'flag'     => esc_html__( 'Flag', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'ribbon_text',
			[
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Popular', 'companion-elementor' ),
				'condition' => [
					'ribbon_style!' => 'none',
				],
			]
		);

		$this->add_control(
			'ribbon_position',
			[
				'label'     => esc_html__( 'Position', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'right',
				'options'   => [
					'left'  => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'toggle'    => false,
				'condition' => [
					'ribbon_style!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'ribbon_corner_distance',
			[
				'label'      => esc_html__( 'Distance', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-ribbon .ec-ribbon-title' => 'margin-top: {{SIZE}}{{UNIT}}; transform: translateY(-50%) translateX(-50%) translateX({{SIZE}}{{UNIT}}) rotate(-45deg);',
				],
				'condition'  => [
					'ribbon_style' => 'corner',
				],
			]
		);

		$this->add_responsive_control(
			'ribbon_circular_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 60,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-ribbon-title' => 'min-height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'ribbon_style' => 'circular',
				],
			]
		);

		$this->add_responsive_control(
			'ribbon_flag_distance',
			[
				'label'      => esc_html__( 'Distance', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'%',
				],
				'range'      => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-ribbon--flag' => 'top: {{SIZE}}{{UNIT}}; transform: translateY(-{{SIZE}}{{UNIT}});',
				],
				'condition'  => [
					'ribbon_style!' => [
						'none',
						'corner',
						'circular',
					],
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_pricing_table_controls() {
		$this->start_controls_section(
			'section_style_general',
			[
				'label' => esc_html__( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'alignment',
			[
				'label'        => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'default'      => 'center',
				'options'      => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'prefix_class' => 'ec-pricing-table--',
			]
		);

		$this->add_responsive_control(
			'pricing_table_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-pricing-table-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pricing_table_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-pricing-table-wrapper',
			]
		);

		$this->add_responsive_control(
			'pricing_table_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-pricing-table-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing_table_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-pricing-table-wrapper',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_header_controls() {
		$this->start_controls_section(
			'section_style_header',
			[
				'label' => esc_html__( 'Header', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'header_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-titles',
			]
		);

		$this->add_responsive_control(
			'header_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-titles' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'header_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-titles' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'style_title_heading',
			[
				'label'     => esc_html__( 'Title', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-title .ec-title-text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .ec-title .ec-title-text',
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'subtitle_style_heading',
			[
				'label'     => esc_html__( 'Subtitle', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'layout!' => '2',
				],
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-subtitle .ec-subtitle-text' => 'color: {{VALUE}}',
				],
				'condition' => [
					'layout!' => '2',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'subtitle_typography',
				'selector'  => '{{WRAPPER}} .ec-subtitle .ec-subtitle-text',
				'condition' => [
					'layout!' => '2',
				],
			]
		);

		$this->add_responsive_control(
			'subtitle_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout!' => '2',
				],
			]
		);

		$this->add_control(
			'description_style_heading',
			[
				'label'     => esc_html__( 'Description', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-description-text' => 'color: {{VALUE}}',
				],
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'description_typography',
				'selector'  => '{{WRAPPER}} .ec-description-text',
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_responsive_control(
			'description_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => '2',
				],
			]
		);

		$this->add_control(
			'description_divider_border_style',
			[
				'label'     => esc_html__( 'Style', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'solid'  => esc_html__( 'Solid', 'companion-elementor' ),
					'double' => esc_html__( 'Double', 'companion-elementor' ),
					'dotted' => esc_html__( 'Dotted', 'companion-elementor' ),
					'dashed' => esc_html__( 'Dashed', 'companion-elementor' ),
				],
				'selectors' => [
					'{{WRAPPER}} .ec-description' => 'border-top-type: {{VALUE}}; border-bottom-type: {{VALUE}};',
				],
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_control(
			'description_divider_border_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-description' => 'border-top-color: {{VALUE}}; border-bottom-color: {{VALUE}};',
				],
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_control(
			'description_divider_border_height',
			[
				'label'      => esc_html__( 'Height', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 1,
						'max'  => 50,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0.1,
						'max'  => 3,
						'step' => 0.1,
					],
					'rem' => [
						'min'  => 0.1,
						'max'  => 3,
						'step' => 0.1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 1,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-description' => 'border-top-width: {{SIZE}}{{UNIT}}; border-bottom-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => '2',
				],
				'separator'  => 'after',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_pricing_controls() {
		$this->start_controls_section(
			'section_style_pricing',
			[
				'label' => esc_html__( 'Pricing', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'pricing_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-price',
			]
		);

		$this->add_responsive_control(
			'pricing_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'pricing_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'spacing_original_discount_price',
			[
				'label'      => esc_html__( 'Original/Discount Price Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-price-original-value' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'discount_available' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'spacing_price_duration',
			[
				'label'      => esc_html__( 'Price/Duration Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-price--postfix-beside .ec-price-inner' => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-price--postfix-below .ec-price-inner' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'price_style_heading',
			[
				'label'     => esc_html__( 'Price', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'price_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-price-value' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'price_typography',
				'selector' => '{{WRAPPER}} .ec-price-value',
			]
		);

		$this->add_control(
			'currency_style_heading',
			[
				'label'     => esc_html__( 'Currency', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'currency_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-price-currency' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'currency_typography',
				'selector' => '{{WRAPPER}} .ec-price-currency',
			]
		);

		$this->add_control(
			'pricing_table_original_pricing',
			[
				'label'     => esc_html__( 'Original Price', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'discount_available' => 'yes',
				],
			]
		);

		$this->add_control(
			'original_price_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-price-original-value' => 'color: {{VALUE}}',
				],
				'condition' => [
					'discount_available' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'original_price_typography',
				'selector'  => '{{WRAPPER}} .ec-price-original-value',
				'condition' => [
					'discount_available' => 'yes',
				],
			]
		);

		$this->add_control(
			'original_price_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'flex-end',
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Top', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					],
					'center'     => [
						'title' => esc_html__( 'Middle', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'flex-end'   => [
						'title' => esc_html__( 'Bottom', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'toggle'    => false,
				'selectors' => [
					'{{WRAPPER}} .ec-price-inner' => 'align-items: {{VALUE}}',
				],
				'condition' => [
					'discount_available' => 'yes',
				],
			]
		);

		$this->add_control(
			'pricing_table_duration',
			[
				'label'     => esc_html__( 'Duration', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'duration_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-price-postfix' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'duration_typography',
				'selector' => '{{WRAPPER}} .ec-price-postfix',
			]
		);

		$this->add_control(
			'duration_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'flex-end',
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Top', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					],
					'center'     => [
						'title' => esc_html__( 'Middle', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'flex-end'   => [
						'title' => esc_html__( 'Bottom', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'toggle'    => false,
				'selectors' => [
					'{{WRAPPER}} .ec-price' => 'align-items: {{VALUE}}',
				],
				'condition' => [
					'duration_position' => 'beside',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_features_controls() {
		$this->start_controls_section(
			'section_style_features',
			[
				'label' => esc_html__( 'Features', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'features_alignment',
			[
				'label'     => esc_html__( 'Content Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'center',
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-features' => 'text-align: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'features_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-features',
			]
		);

		$this->add_responsive_control(
			'features_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-features' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'features_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-features' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'features_style',
			[
				'label'   => esc_html__( 'Style', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'simple',
				'options' => [
					'simple'  => esc_html__( 'Simple', 'companion-elementor' ),
					'divider' => esc_html__( 'Divider', 'companion-elementor' ),
					'strips'  => esc_html__( 'Strips', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'feature_simple_heading',
			[
				'label'     => esc_html__( 'Simple', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'features_style' => 'simple',
				],
			]
		);

		$this->add_control(
			'feature_divider_heading',
			[
				'label'     => esc_html__( 'Divider', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'features_style' => 'divider',
				],
			]
		);

		$this->add_control(
			'feature_strips_heading',
			[
				'label'     => esc_html__( 'Strips', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'features_style' => 'strips',
				],
			]
		);

		$this->add_control(
			'feature_divider_border_style',
			[
				'label'     => esc_html__( 'Style', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'solid'  => esc_html__( 'Solid', 'companion-elementor' ),
					'double' => esc_html__( 'Double', 'companion-elementor' ),
					'dotted' => esc_html__( 'Dotted', 'companion-elementor' ),
					'dashed' => esc_html__( 'Dashed', 'companion-elementor' ),
				],
				'selectors' => [
					'{{WRAPPER}} .ec-features .ec-feature:not(:last-child)' => 'border-bottom-style: {{VALUE}}',
				],
				'condition' => [
					'features_style' => 'divider',
				],
			]
		);

		$this->add_control(
			'feature_divider_border_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-features .ec-feature:not(:last-child)' => 'border-bottom-color: {{VALUE}}',
				],
				'condition' => [
					'features_style' => 'divider',
				],
			]
		);

		$this->add_responsive_control(
			'feature_divider_border_height',
			[
				'label'      => esc_html__( 'Height', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 1,
						'max'  => 50,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0.1,
						'max'  => 3,
						'step' => 0.1,
					],
					'rem' => [
						'min'  => 0.1,
						'max'  => 3,
						'step' => 0.1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 1,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-features .ec-feature:not(:last-child)' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'features_style' => 'divider',
				],
				'separator'  => 'after',
			]
		);

		$this->start_controls_tabs(
			'pricing_table_feature_tabs',
			[
				'condition' => [
					'features_style' => 'strips',
				],
			]
		);

		$this->start_controls_tab(
			'feature_strips_even',
			[
				'label'     => esc_html__( 'Even', 'companion-elementor' ),
				'condition' => [
					'features_style' => 'strips',
				],
			]
		);

		$this->add_control(
			'feature_strips_even_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-features .ec-feature:nth-child(2n) .feature-text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'feature_strips_even_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-features .ec-feature:nth-child(2n) i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'feature_strips_even_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-features .ec-feature:nth-child(2n)',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'feature_strips_odd',
			[
				'label'     => esc_html__( 'Odd', 'companion-elementor' ),
				'condition' => [
					'features_style' => 'strips',
				],
			]
		);

		$this->add_control(
			'feature_strips_odd_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-features .ec-feature:nth-child(2n+1) .feature-text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'feature_strips_odd_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-features .ec-feature:nth-child(2n+1) i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'feature_strips_odd_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-features .ec-feature:nth-child(2n+1)',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'features_heading_strips',
			[
				'label'     => esc_html__( 'Features', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'features_style!' => 'simple',
				],
			]
		);

		$this->add_control(
			'feature_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-features .ec-feature .feature-text' => 'color: {{VALUE}}',
				],
				'condition' => [
					'features_style!' => 'strips',
				],
			]
		);

		$this->add_control(
			'feature_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-features .ec-feature  i' => 'color: {{VALUE}}',
				],
				'condition' => [
					'features_style!' => 'strips',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'feature_typography',
				'selector' => '{{WRAPPER}} .ec-features .ec-feature .feature-text, {{WRAPPER}} .ec-features .ec-feature',
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label'      => esc_html__( 'Icon Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 30,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 2,
						'step' => 0.01,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 2,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-features i' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'feature_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-features .ec-feature' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_cta_controls() {
		$this->start_controls_section(
			'section_style_cta',
			[
				'label' => esc_html__( 'Call To Action', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cta_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-cta',
			]
		);

		$this->add_responsive_control(
			'cta_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-cta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cta_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-cta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'cta_text_heading',
			[
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'cta_type' => 'text',
				],
			]
		);

		$this->add_control(
			'cta_button_heading',
			[
				'label'     => esc_html__( 'Button', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'cta_type' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'cta_text_typography',
				'selector' => '{{WRAPPER}} .ec-cta .ec-cta-text',
			]
		);

		$this->start_controls_tabs(
			'cta_text_tabs',
			[
				'condition' => [
					'cta_type' => 'text',
				],
			]
		);

		$this->start_controls_tab(
			'cta_text_normal',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_text_normal_color',
			array_merge(
				[
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ec-cta .ec-cta-text' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_4,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_ACCENT,
					],
				]
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cta_text_hover',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_text_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-cta .ec-cta-text:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'cta_button_width',
			[
				'label'      => esc_html__( 'Width', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'%',
					'px',
				],
				'range'      => [
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .cta-btn' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cta_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-cta .ec-cta-text.cta-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'cta_button_border',
				'label'     => esc_html__( 'Border', 'companion-elementor' ),
				'selector'  => '{{WRAPPER}} .ec-cta .ec-cta-text.cta-btn',
				'condition' => [
					'cta_type' => 'button',
				],
			]
		);

		$this->add_responsive_control(
			'cta_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-cta .ec-cta-text.cta-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'cta_button_box_shadow',
				'label'     => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector'  => '{{WRAPPER}} .ec-cta .ec-cta-text.cta-btn',
				'condition' => [
					'cta_type' => 'button',
				],
			]
		);

		$this->add_control(
			'cta_button_divider',
			[
				'type'      => Controls_Manager::DIVIDER,
				'condition' => [
					'cta_type' => 'button',
				],
			]
		);

		$this->start_controls_tabs(
			'cta_button_tabs',
			[
				'condition' => [
					'cta_type' => 'button',
				],
			]
		);

		$this->start_controls_tab(
			'cta_button_normal',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_button_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-cta .ec-cta-text.cta-btn' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cta_button_normal_bg_color',
			array_merge(
				[
					'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .ec-cta .ec-cta-text.cta-btn' => 'background-color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_4,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_ACCENT,
					],
				]
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cta_button_hover',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_button_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-cta .ec-cta-text.cta-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cta_button_hover_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-cta .ec-cta-text.cta-btn:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cta_button_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-cta .ec-cta-text.cta-btn:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'disclaimer_text_heading',
			[
				'label'     => esc_html__( 'Disclaimer Text', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'cta_type' => [ 'text', 'button' ],
					'layout!'  => '2',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'disclaimer_text_typography',
				'selector'  => '{{WRAPPER}} .ec-cta .cta-caption',
				'condition' => [
					'cta_type' => [ 'text', 'button' ],
					'layout!'  => '2',
				],
			]
		);

		$this->add_control(
			'disclaimer_text_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-cta .cta-caption' => 'color: {{VALUE}}',
					'condition'                        => [
						'cta_type' => [ 'text', 'button' ],
						'layout!'  => '2',
					],
				],
			]
		);

		$this->add_responsive_control(
			'disclaimer_text_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-cta .cta-caption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => [ 'text', 'button' ],
					'layout!'  => '2',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_ribbon_controls() {
		$this->start_controls_section(
			'section_style_ribbon',
			[
				'label'     => esc_html__( 'Ribbon', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'ribbon_style!' => 'none',
					'layout!'       => '2',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'ribbon_typography',
				'selector' => '{{WRAPPER}} .ec-ribbon-title',
			]
		);

		$this->add_control(
			'ribbon_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-ribbon-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'ribbon_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-ribbon-title',
			]
		);

		$this->add_responsive_control(
			'ribbon_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-ribbon-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ribbon_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-ribbon-title',
			]
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/pricing-table-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings         = $this->get_settings_for_display();
		$pricing_position = $settings['pricing_position'];
		$cta_type         = $settings['cta_type'];
		$ribbon_style     = $settings['ribbon_style'];
		$layout           = $settings['layout'];
		?>
		<div class="ec-pricing-table-wrapper <?php echo esc_attr( 'ec-pricing-table__style-' . $layout ); ?>">
			<div class="ec-pricing-table">
				<?php $this->render_heading( $settings ); ?>

				<?php if ( '2' === $layout || 'below-titles' === $pricing_position ) : ?>
					<?php $this->render_pricing( $settings ); ?>
				<?php endif; ?>

				<?php if ( '2' === $settings['layout'] && $settings['description'] ) : ?>
					<?php $this->render_description( $settings ); ?>
				<?php endif; ?>

				<?php $this->render_features( $settings ); ?>

				<?php if ( 'above-footer' === $pricing_position ) : ?>
					<?php $this->render_pricing( $settings ); ?>
				<?php endif; ?>

				<?php if ( 'none' !== $cta_type ) : ?>
					<?php $this->render_cta( $settings ); ?>
				<?php endif; ?>
			</div> <!-- /.ec-pricing-table -->

			<?php if ( 'none' !== $ribbon_style ) : ?>
				<?php $this->render_ribbon( $settings ); ?>
			<?php endif; ?>

		</div> <!-- /.ec-pricing-table-wrapper -->

		<?php
	}

	private function render_heading( $settings ) {
		$title        = $settings['title'];
		$title_tag    = $settings['title_tag'];
		$subtitle     = $settings['subtitle'];
		$subtitle_tag = $settings['subtitle_tag'];

		$this->add_inline_editing_attributes( 'title', 'none' );
		$this->add_render_attribute( 'title', 'class', 'ec-title-text' );

		$this->add_inline_editing_attributes( 'subtitle', 'none' );
		$this->add_render_attribute( 'subtitle', 'class', 'ec-subtitle-text' );
		?>
		<div class="ec-titles">
			<div class="ec-title">
				<?php if ( $title ) : ?>
					<<?php echo esc_attr( $title_tag ) . ' ' . $this->get_render_attribute_string( 'title' ); ?>>
						<?php echo esc_html( $title ); ?>
					</<?php echo esc_attr( $title_tag ); ?>>
				<?php endif; ?>
			</div> <!-- /.ec-title -->

			<div class="ec-subtitle">
				<?php if ( $subtitle ) : ?>
					<<?php echo esc_attr( $subtitle_tag ) . ' ' . $this->get_render_attribute_string( 'subtitle' ); ?>>
						<?php echo esc_html( $subtitle ); ?>
					</<?php echo esc_attr( $subtitle_tag ); ?>>
				<?php endif; ?>
			</div> <!-- /.ec-subtitle -->
		</div> <!-- /.ec-titles -->
		<?php
	}

	private function render_description( $settings ) {

		$this->add_inline_editing_attributes( 'description', 'none' );
		$this->add_render_attribute( 'description', 'class', 'ec-description-text' );
		?>
			<div class="ec-description">
				<<?php echo esc_attr( $settings['description_tag'] ) . ' ' . $this->get_render_attribute_string( 'description' ); ?>>
					<?php echo esc_html( $settings['description'] ); ?>
				</<?php echo esc_attr( $settings['description_tag'] ); ?>>
			</div> <!-- /.ec-description -->
		<?php
	}

	private function render_pricing( $settings ) {
		$price                   = $settings['price'];
		$duration_position       = $settings['duration_position'];
		$original_price_position = $settings['original_price_position'];
		$discount_available      = $settings['discount_available'];
		$original_price          = $settings['original_price'];
		$duration                = $settings['duration'];
		$currency                = $settings['currency'];

		$this->add_inline_editing_attributes( 'duration', 'none' );
		$this->add_render_attribute( 'duration', 'class', 'ec-price-postfix-value' )
		?>
		<div class="ec-price ec-price--postfix-<?php echo esc_attr( $duration_position ); ?>">
			<div class="ec-price-inner ec-price--original-<?php echo esc_attr( $original_price_position ); ?>">
				<?php if ( $price ) : ?>
					<?php if ( $discount_available && $original_price ) : ?>
						<div class="ec-price-original-value">
							<del><?php echo esc_html( $currency ); ?><?php echo esc_html( $original_price ); ?></del>
						</div>
					<?php endif; ?>

					<div class="ec-price-value">
						<span class="ec-price-currency"><?php echo esc_html( $currency ); ?></span><?php echo esc_html( $price ); ?>
					</div>
				<?php endif; ?>
			</div>

			<div class="ec-price-postfix">
				<span <?php echo $this->get_render_attribute_string( 'duration' ); ?>><?php echo esc_html( $duration ); ?></span>
			</div>
		</div> <!-- /.ec-price -->
		<?php
	}

	private function render_features( $settings ) {
		$features       = $settings['features'];
		$features_style = $settings['features_style'];
		?>
		<ul class="ec-features ec-features--<?php echo esc_attr( $features_style ); ?>">
			<?php
			foreach ( $features as $index => $feature ) :
				$repeater_setting_key = $this->get_repeater_setting_key( 'text', 'features', $index );
				$this->add_inline_editing_attributes( $repeater_setting_key );
				$this->add_render_attribute( $repeater_setting_key, 'class', 'feature-text' );
				?>

				<li class="ec-feature elementor-repeater-item-<?php echo esc_attr( $feature['_id'] ); ?>">
					<div class="ec-feature-inner">
						<?php if ( ! empty( $feature['icon_v5'] ) || array_key_exists( 'icon', $feature ) ) : ?>
							<?php
							$migrated = isset( $feature['__fa4_migrated']['icon_v5'] );
							$is_new   = ! array_key_exists( 'icon', $feature );
							if ( $is_new || $migrated ) :
								Icons_Manager::render_icon( $feature['icon_v5'], [ 'aria-hidden' => 'true' ] );
							else :
								?>
								<i class="<?php echo ( is_array( $feature['icon'] ) ? $feature['icon']['value'] : $feature['icon'] ); ?>" aria-hidden="true"></i>
							<?php endif; ?>
						<?php endif; ?>

						<?php if ( ! empty( $feature['text'] ) ) : ?>
							<span <?php echo $this->get_render_attribute_string( $repeater_setting_key ); ?>>
								<?php echo esc_html( $feature['text'] ); ?>
							</span>
						<?php endif; ?>
					</div>
				</li> <!-- /.ec-feature -->

			<?php endforeach; ?>
		</ul> <!-- /.ec-features -->
		<?php
	}

	private function render_cta( $settings ) {
		$cta_type          = $settings['cta_type'];
		$cta_class         = ( 'button' === $cta_type ) ? 'cta-btn' : '';
		$cta_text          = $settings['cta_text'];
		$cta_icon          = $settings['cta_icon_v5'];
		$cta_icon_position = $settings['cta_icon_position'];
		$cta_link          = $settings['cta_link'];
		$disclaimer_text   = $settings['disclaimer_text'];

		$this->add_inline_editing_attributes( 'cta_text', 'none' );
		$this->add_render_attribute( 'cta_text' );

		$this->add_inline_editing_attributes( 'disclaimer_text', 'none' );
		$this->add_render_attribute( 'disclaimer_text', 'class', 'cta-caption' );
		?>
		<div class="ec-cta">
			<?php if ( $cta_link['url'] && $cta_text ) : ?>
			<a class="ec-cta-text <?php echo esc_attr( $cta_class ); ?> icon-position--<?php echo esc_attr( $cta_icon_position ); ?>"
				href="<?php echo esc_url( $cta_link['url'] ); ?>"
				<?php echo $cta_link['is_external'] ? 'target="_blank"' : ''; ?>
				<?php echo $cta_link['nofollow'] ? 'rel="nofollow"' : ''; ?>
			>
				<?php endif; ?>

				<span <?php echo $this->get_render_attribute_string( 'cta_text' ); ?>>
					<?php echo esc_html( $cta_text ); ?>
				</span>

				<?php if ( $cta_icon || array_key_exists( 'cta_icon', $settings ) ) : ?>
					<?php
					$migrated = isset( $settings['__fa4_migrated']['cta_icon_v5'] );
					$is_new   = ! array_key_exists( 'cta_icon', $settings );
					if ( $is_new || $migrated ) :
						Icons_Manager::render_icon( $cta_icon, [ 'aria-hidden' => 'true' ] );
					else :
						?>
						<i class="<?php echo ( is_array( $settings['cta_icon'] ) ? $settings['cta_icon']['value'] : $settings['cta_icon'] ); ?>" aria-hidden="true"></i>
					<?php endif; ?>
				<?php endif; ?>

				<?php if ( $cta_link['url'] ) : ?>
			</a>
		<?php endif; ?>

			<?php if ( $disclaimer_text ) : ?>
				<footer <?php echo $this->get_render_attribute_string( 'disclaimer_text' ); ?>>
					<?php echo esc_html( $disclaimer_text ); ?>
				</footer> <!-- /.cta-caption -->
			<?php endif; ?>
		</div> <!-- /.ec-cta -->
		<?php
	}

	private function render_ribbon( $settings ) {
		$ribbon_style    = $settings['ribbon_style'];
		$ribbon_text     = $settings['ribbon_text'];
		$ribbon_position = $settings['ribbon_position'];

		$this->add_inline_editing_attributes( 'ribbon_text', 'none' );
		$this->add_render_attribute( 'ribbon_text', 'class', 'ec-ribbon-title' );
		?>
		<div class="ec-ribbon ec-ribbon--<?php echo esc_attr( $ribbon_style ); ?> position--<?php echo esc_attr( $ribbon_position ); ?>">
			<?php if ( $ribbon_text ) : ?>
				<div <?php echo $this->get_render_attribute_string( 'ribbon_text' ); ?>>
					<?php echo esc_html( $ribbon_text ); ?>
				</div>
			<?php endif; ?>
		</div> <!-- /.ec-ribbon -->
		<?php
	}
}
