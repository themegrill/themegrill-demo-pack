<?php

namespace CompanionElementor\Modules\PricingTable;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Pricing_Table',
		];
	}

	public function get_name() {
		return 'pricing-table';
	}

}
