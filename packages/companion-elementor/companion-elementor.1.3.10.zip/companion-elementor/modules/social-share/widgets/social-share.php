<?php
/**
 * Social share class.
 */
namespace CompanionElementor\Modules\SocialShare\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Border;

defined( 'ABSPATH' ) || exit;

class Social_Share extends Base_Widget {


	public function get_name() {
		return 'elementor-companion-social-share';
	}

	public function get_title() {
		return __( 'Social Share', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-share';
	}

	public function get_keywords() {
		return array( 'companion', 'socail share', 'social', 'share' );
	}


	protected function register_controls() {
		$this->register_general_controls();
		$this->register_style_general_controls();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'section_general',
			array(
				'label' => esc_html__( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'social_share_network',
			array(
				'label'   => esc_html__( 'Network', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'facebook'   => 'Facebook',
					'twitter'    => 'Twitter',
					'linkedin'   => 'Linkedin',
					'pinterest'  => 'Pinterest',
					'reddit'     => 'Reddit',
					'wordpress'  => 'WordPress',
					'blogger'    => 'Blogger',
					'tumblr'     => 'Tumblr',
					'mail'       => 'Email',
					'skype'      => 'Skype',
					'telegram'   => 'Telegram',
					'whatsapp'   => 'WhatsApp',
					'get-pocket' => 'Pocket',
					'buffer'     => 'Buffer',
				),
				'default' => 'facebook',
			)
		);

		$repeater->add_control(
			'icon_list_title',
			array(
				'label'       => __( 'Title', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Facebook', 'companion-elementor' ),
				'dynamic'     => array(
					'active' => true,
				),
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'icon_primary_color',
			array(
				'label'     => esc_html__( 'Primary Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-social-share-wrapper.ec-shape-none {{CURRENT_ITEM}} .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-rounded {{CURRENT_ITEM}} .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-square {{CURRENT_ITEM}} .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-circle {{CURRENT_ITEM}} .ec-social-icon' => 'background-color: {{VALUE}}',
				),
			)
		);

		$repeater->add_control(
			'icon_secondary_color',
			array(
				'label'     => esc_html__( 'Secondary Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-social-share-wrapper.ec-shape-none {{CURRENT_ITEM}} i, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-rounded {{CURRENT_ITEM}} i, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-square {{CURRENT_ITEM}} i, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-circle {{CURRENT_ITEM}} i' => 'color: {{VALUE}} !important',
				),
			)
		);

		$this->add_control(
			'socials',
			array(
				'label'       => esc_html__( 'Social Links', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'icon_list_title'      => esc_html__( 'Facebook', 'companion-elementor' ),
						'social_share_network' => 'facebook',
					),
					array(
						'icon_list_title'      => esc_html__( 'Twitter', 'companion-elementor' ),
						'social_share_network' => 'twitter',
					),
					array(
						'icon_list_title'      => esc_html__( 'Linkedin', 'companion-elementor' ),
						'social_share_network' => 'linkedin',
					),
				),
				'title_field' => '{{{ icon_list_title }}}',
			)
		);

		$this->add_control(
			'social_share_shape',
			array(
				'label'   => esc_html__( 'Shape', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'none'    => 'None',
					'rounded' => 'Rounded',
					'square'  => 'Square',
					'circle'  => 'Circle',
				),
				'default' => 'circle',
			)
		);

		$this->add_control(
			'social_share_columns',
			array(
				'label'   => esc_html__( 'Columns', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'auto' => 'Auto',
					'1'    => '1',
					'2'    => '2',
					'3'    => '3',
				),
				'default' => 'auto',
			)
		);

		$this->add_responsive_control(
			'social_share_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					),
				),
				'default'   => 'left',
				'selectors' => array(
					'{{WRAPPER}} .ec-social-share-wrapper' => 'text-align: {{VALUE}}; justify-content: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_general_controls() {
		$this->start_controls_section(
			'icon_style_section',
			array(
				'label' => esc_html__( 'Icon', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'icon_primary_color',
			array(
				'label'     => esc_html__( 'Primary Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-social-share-wrapper.ec-shape-rounded .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-square .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-circle .ec-social-icon' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'icon_secondary_color',
			array(
				'label'     => esc_html__( 'Secondary Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-social-share-wrapper.ec-shape-rounded i, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-square i, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-circle i' => 'color: {{VALUE}} !important',
				),
			)
		);

		$this->add_responsive_control(
			'icon_gap',
			array(
				'label'      => esc_html__( 'Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
				),
				'range'      => array(
					'px' => array(
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => '',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-social-share-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'icon_size',
			array(
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
				),
				'range'      => array(
					'px' => array(
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => '',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-social-share-wrapper.ec-shape-none, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-rounded .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-square .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-circle .ec-social-icon' => '--icon-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'icon_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
				),
				'range'      => array(
					'px' => array(
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => '',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-social-share-wrapper.ec-shape-rounded .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-square .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-circle .ec-social-icon' => '--icon-padding: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'icon_border',
				'selector' => '{{WRAPPER}} .ec-social-share-wrapper.ec-shape-rounded .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-square .ec-social-icon, {{WRAPPER}} .ec-social-share-wrapper.ec-shape-circle .ec-social-icon',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings             = $this->get_settings_for_display();
		$socials              = $settings['socials'];
		$social_share_shape   = $settings['social_share_shape'];
		$social_share_columns = $settings['social_share_columns'];
		?>

		<div class="ec-social-share-wrapper <?php echo esc_attr( 'ec-column-' . $social_share_columns ) . ' ' . esc_attr( 'ec-shape-' . $social_share_shape ); ?>">
			<?php foreach ( $socials as $social ) : ?>
				<div class="elementor-repeater-item-<?php echo esc_attr( $social['_id'] ); ?>">
					<?php
					$network    = $social['social_share_network'] ?? 'facebook';
					$icon       = $this->networks[ $network ]['icon'] ?? 'fab fa-facebook-f';
					$icon_color = $this->networks[ $network ]['icon_color'] ?? '#269BD1';
					?>
					<a class="ec-social-icon" href="<?php echo esc_url( $this->get_social_link( $network ) ); ?>" target="_blank" rel="noopener noreferrer">
						<i class="<?php echo esc_attr( $icon ); ?>" aria-hidden="true" style="color: <?php echo esc_attr( $icon_color ); ?>"></i>
					</a>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	private $networks = array(
		'facebook'   => array(
			'icon_color' => '#3b5998',
			'icon'       => 'fab fa-facebook-f',
		), // Facebook
		'twitter'    => array(
			'icon_color' => '#1da1f2',
			'icon'       => 'fab fa-twitter',
		), // Twitter
		'linkedin'   => array(
			'icon_color' => '#0077b5',
			'icon'       => 'fab fa-linkedin-in',
		), // LinkedIn
		'pinterest'  => array(
			'icon_color' => '#bd081c',
			'icon'       => 'fab fa-pinterest-p',
		), // Pinterest
		'reddit'     => array(
			'icon_color' => '#ff4500',
			'icon'       => 'fab fa-reddit',
		), // Reddit
		'wordpress'  => array(
			'icon_color' => '#21759b',
			'icon'       => 'fab fa-wordpress',
		), // WordPress
		'blogger'    => array(
			'icon_color' => '#f88109',
			'icon'       => 'fab fa-blogger',
		), // Blogger
		'tumblr'     => array(
			'icon_color' => '#35465c',
			'icon'       => 'fab fa-tumblr',
		), // Tumblr
		'mail'       => array(
			'icon_color' => '#666',
			'icon'       => 'fas fa-envelope',
		), // Email
		'skype'      => array(
			'icon_color' => '#00aff0',
			'icon'       => 'fab fa-skype',
		), // Skype
		'telegram'   => array(
			'icon_color' => '#0088cc',
			'icon'       => 'fab fa-telegram',
		), // Telegram
		'whatsapp'   => array(
			'icon_color' => '#25D366',
			'icon'       => 'fab fa-whatsapp',
		), // WhatsApp
		'get-pocket' => array(
			'icon_color' => '#ef4056',
			'icon'       => 'fab fa-get-pocket',
		), // Pocket
		'buffer'     => array(
			'icon_color' => '#168eea',
			'icon'       => 'fab fa-buffer',
		), // Buffer,
	);

	private function get_social_link( $social_icon ) {
		global $post;
		$post_permalink = get_permalink( $post );

		switch ( $social_icon ) {
			case 'facebook':
				return 'https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( $post_permalink );
			case 'twitter':
				return 'https://twitter.com/intent/tweet?url=' . rawurlencode( $post_permalink );
			case 'linkedin':
				return 'https://www.linkedin.com/shareArticle?url=' . rawurlencode( $post_permalink );
			case 'pinterest':
				return 'https://pinterest.com/pin/create/button/?url=' . rawurlencode( $post_permalink );
			case 'reddit':
				return 'https://www.reddit.com/submit?url=' . rawurlencode( $post_permalink );
			case 'WordPress':
				return 'https://wordpress.com/wp-admin/press-this.php?u=' . rawurlencode( $post_permalink );
			case 'blogger':
				return 'https://www.blogger.com/blog-this.g?u=' . rawurlencode( $post_permalink );
			case 'tumblr':
				return 'https://www.tumblr.com/widgets/share/tool?canonicalUrl=' . rawurlencode( $post_permalink );
			case 'main':
				return 'mailto:?body=' . rawurlencode( $post_permalink );
			case 'skype':
				return 'https://web.skype.com/share?url=' . rawurlencode( $post_permalink );
			case 'telegram':
				return 'https://t.me/share/url?url=' . rawurlencode( $post_permalink );
			case 'whatsapp':
				return 'https://api.whatsapp.com/send?text=' . rawurlencode( $post_permalink );
			case 'get-pocket':
				return 'https://getpocket.com/edit?url=' . rawurlencode( $post_permalink );
			case 'buffer':
				return 'https://buffer.com/add?url=' . rawurlencode( $post_permalink );
			default:
				return '#'; // Default link
		}
	}
}
