<?php

namespace CompanionElementor\Modules\SocialShare;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Social_Share',
		];
	}

	public function get_name() {
		return 'social-share';
	}

}
