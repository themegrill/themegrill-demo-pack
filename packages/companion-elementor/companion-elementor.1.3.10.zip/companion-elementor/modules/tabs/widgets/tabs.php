<?php

namespace CompanionElementor\Modules\Tabs\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Plugin;
use CompanionElementor\Classes\Utils as CompanionElementorUtils;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;

defined( 'ABSPATH' ) || exit;

class Tabs extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-tabs';
	}

	public function get_title() {
		return __( 'Tabs', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-tabs';
	}

	public function get_keywords() {
		return array( 'companion', 'tabs' );
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_settings_controls();
		$this->register_style_tabs_controls();
		$this->register_style_title_controls();
		$this->register_style_content_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'section_general',
			array(
				'label' => esc_html__( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => esc_html__( 'Layout', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style 1', 'companion-elementor' ),
					'2' => esc_html__( 'Style 2', 'companion-elementor' ),
					'3' => esc_html__( 'Style 3', 'companion-elementor' ),
					'4' => esc_html__( 'Style 4', 'companion-elementor' ),
				),
			)
		);

		$repeater_tabs = new Repeater();

		$repeater_tabs->add_control(
			'tab_title',
			array(
				'label'   => esc_html__( 'Title', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Tab Title', 'companion-elementor' ),
			)
		);

		$repeater_tabs->add_control(
			'tab_content_type',
			array(
				'label'   => esc_html__( 'Content Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'content',
				'options' => array(
					'content'  => esc_html__( 'Content', 'companion-elementor' ),
					'template' => esc_html__( 'Template', 'companion-elementor' ),
				),
			)
		);

		$repeater_tabs->add_control(
			'tab_content',
			array(
				'label'     => esc_html__( 'Content', 'companion-elementor' ),
				'type'      => Controls_Manager::WYSIWYG,
				'default'   => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'companion-elementor' ),
				'condition' => array(
					'tab_content_type' => 'content',
				),
			)
		);

		$repeater_tabs->add_control(
			'tab_template',
			array(
				'label'     => esc_html__( 'Template', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '0',
				'options'   => CompanionElementorUtils::get_templates(),
				'condition' => array(
					'tab_content_type' => 'template',
				),
			)
		);

		$this->add_control(
			'tabs',
			array(
				'label'       => esc_html__( 'Tabs', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater_tabs->get_controls(),
				'default'     => array(
					array(
						'tab_title' => esc_html__( 'Tab 1', 'companion-elementor' ),
					),
					array(
						'tab_title' => esc_html__( 'Tab 2', 'companion-elementor' ),
					),
					array(
						'tab_title' => esc_html__( 'Tab 3', 'companion-elementor' ),
					),
				),
				'title_field' => '{{{ tab_title }}}',
			)
		);

		$this->end_controls_section();
	}

	private function register_settings_controls() {
		$this->start_controls_section(
			'section_settings',
			array(
				'label' => esc_html__( 'Settings', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'active_tab',
			array(
				'label'   => esc_html__( 'Active Tab', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 1,
			)
		);

		$this->end_controls_section();
	}

	private function register_style_tabs_controls() {
		$this->start_controls_section(
			'section_style_general',
			array(
				'label'     => esc_html__( 'General', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'layout' => array( '1', '3', '4' ),
				),
			)
		);

		$this->add_control(
			'tabs_gap',
			array(
				'label'     => esc_html__( 'Gap', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'size' => 16,
				),
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 200,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs__style-4 .ec-tabs-controls' => 'gap: {{SIZE}}{{UNIT}};',
				),
				'condition' => array(
					'layout' => array( '4' ),
				),
			)
		);

		$this->add_control(
			'tabs_border_width',
			array(
				'label'     => esc_html__( 'Border Width', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'size' => 1,
				),
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 10,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs__style-1 .ec-tab-title'            => 'border-width: {{SIZE}}{{UNIT}} 0 0 {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-tabs__style-1 .ec-tab-title:last-child' => 'border-right-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-tabs__style-1 .ec-tab-title.ec-active::after, {{WRAPPER}} .ec-tabs__style-1 .ec-tab-title.ec-active::before' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-tabs__style-1 .ec-tabs-content'         => 'border-width: {{SIZE}}{{UNIT}}; border-top-width: 0;',
					'{{WRAPPER}} .ec-tabs__style-4 .ec-tabs-controls .ec-tab-title'            => 'border-width: {{SIZE}}{{UNIT}} 0 {{SIZE}}{{UNIT}} 0;',
				),
				'condition' => array(
					'layout' => array( '1', '4' ),
				),
			)
		);

		$this->start_controls_tabs(
			'tabs_border'
		);

		$this->start_controls_tab(
			'tabs_border_color_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'tabs_border_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-tab-title, {{WRAPPER}} .ec-tab-title.ec-active::after, {{WRAPPER}} .ec-tab-title.ec-active::before, {{WRAPPER}} .ec-tabs-content, .ec-tabs__style-4 .ec-tabs-controls, .ec-tabs__style-4 .ec-tabs-controls .ec-tab-title' => 'border-color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => array( '1', '4' ),
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tabs_border_color_active_tab',
			array(
				'label' => esc_html__( 'Active', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'tabs_border_active_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs-controls .ec-tab-title.ec-active' => 'border-color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => array( '1', '4' ),
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'           => 'tabs_border_style_3',
				'fields_options' => array(
					'border' => array(
						'default' => 'solid',
					),
					'width'  => array(
						'default' => array(
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => true,
						),
					),
					'color'  => array(
						'default' => '#269bd1',
					),
				),
				'selector'       => '{{WRAPPER}} .ec-tabs-controls',
				'condition'      => array(
					'layout' => '3',
				),
			)
		);

		$this->add_responsive_control(
			'title_border_radius_style3',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-tabs-controls' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'layout' => '3',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_title_controls() {
		$this->start_controls_section(
			'section_style_title',
			array(
				'label' => esc_html__( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'title_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs-wrapper' => 'text-align: {{VALUE}}',
					'{{WRAPPER}} .ec-tabs__style-4 .ec-tabs-controls' => 'justify-content: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'title_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-tab-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'title_spacing',
			array(
				'label'      => esc_html__( 'Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => array(
					'size' => '',
				),
				'range'      => array(
					'px' => array(
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					),
				),
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .ec-tab-title'            => 'margin-right: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .ec-tab-title:last-child' => 'margin-right: 0',
				),
				'condition'  => array(
					'layout' => array( '2' ),
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .ec-tab-title',
			)
		);

		$this->add_control(
			'title_border_type_style_3',
			array(
				'label'     => esc_html__( 'Border Type', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					'none'   => esc_html__( 'None', 'companion-elementor' ),
					'solid'  => esc_html__( 'Solid', 'companion-elementor' ),
					'double' => esc_html__( 'Double', 'companion-elementor' ),
					'dotted' => esc_html__( 'Dotted', 'companion-elementor' ),
					'dashed' => esc_html__( 'Dashed', 'companion-elementor' ),
					'groove' => esc_html__( 'Groove', 'companion-elementor' ),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-tab-title:not(:last-child)' => 'border-right-style: {{VALUE}};',
				),
				'condition' => array(
					'layout' => '3',
				),
			)
		);

		$this->add_control(
			'title_border_width_style_3',
			array(
				'label'     => esc_html__( 'Border Width', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 6,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-tab-title:not(:last-child)' => 'border-right-width: {{SIZE}}{{UNIT}};',
				),
				'condition' => array(
					'layout'                     => '3',
					'title_border_type_style_3!' => 'none',
				),
			)
		);

		$this->add_control(
			'title_border_color_style_3',
			array(
				'label'     => __( 'Border Color', 'elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tab-title:not(:last-child)' => 'border-right-color: {{VALUE}};',
				),
				'condition' => array(
					'layout'                     => '3',
					'title_border_type_style_3!' => 'none',
				),
			)
		);

		$this->start_controls_tabs(
			'title_tabs'
		);

		$this->start_controls_tab(
			'title_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-tab-title' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => array( '1', '4' ),
				),
			)
		);

		$this->add_control(
			'title_color_style_2',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs__style-2 .ec-tab-title:not(.ec-active)' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => '2',
				),
			)
		);

		$this->add_control(
			'title_bg_color_style_2',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs__style-2 .ec-tab-title:not(.ec-active)' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => '2',
				),
			)
		);

		$this->add_control(
			'title_color_style_3',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs__style-3 .ec-tab-title:not(.ec-active)' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => '3',
				),
			)
		);

		$this->add_control(
			'title_bg_color_style_3',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs__style-3 .ec-tab-title:not(.ec-active)' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => '3',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'title_active_tab',
			array(
				'label' => esc_html__( 'Active', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'title_active_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tab-title.ec-active' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => array( '1', '4' ),
				),
			)
		);

		$this->add_control(
			'title_active_color_style_2',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs__style-2 .ec-tab-title.ec-active' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => '2',
				),
			)
		);

		$this->add_control(
			'title_active_bg_color_style_2',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs__style-2 .ec-tab-title.ec-active' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => '2',
				),
			)
		);

		$this->add_control(
			'title_active_color_style_3',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs__style-3 .ec-tab-title.ec-active' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => '3',
				),
			)
		);

		$this->add_control(
			'title_active_bg_color_style_3',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs__style-3 .ec-tab-title.ec-active' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => '3',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'      => 'title_active_box_shadow_style_3',
				'label'     => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector'  => '{{WRAPPER}} .ec-tabs__style-3 .ec-tab-title.ec-active',
				'exclude'   => array(
					'box_shadow_position',
				),
				'condition' => array(
					'layout' => '3',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'title_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-tabs-controls' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'layout' => '2',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_content_controls() {
		$this->start_controls_section(
			'section_style_content',
			array(
				'label' => esc_html__( 'Content', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-tabs-content' => 'text-align: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'content_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tab-content' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'content_spacing',
			array(
				'label'     => esc_html__( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-tab-content' => 'margin-top: {{SIZE}}{{UNIT}};',
				),
				'condition' => array(
					'layout' => '3',
				),
			)
		);

		$this->add_responsive_control(
			'content_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-tab-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_typography',
				'selector' => '{{WRAPPER}} .ec-tab-content',
				'selector' => '{{WRAPPER}} .ec-tab-content p',
			)
		);

		$this->add_control(
			'content_background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-tab-content' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					'layout' => '2',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/tabs-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			array(
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'help_doc',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$tabs     = $settings['tabs'];
		$id_int   = substr( $this->get_id_int(), 0, 3 );
		$layout   = $settings['layout'];
		?>
		<div class="ec-tabs-wrapper <?php echo esc_attr( 'ec-tabs__style-' . $layout ); ?>">
			<div class="ec-tabs-controls">
				<?php
				foreach ( $tabs as $index => $item ) :
					$tab_count    = $index + 1;
					$active_class = ( ( $settings['active_tab'] - 1 ) === $index ) ? 'ec-active' : '';
					?>
					<div id="ec-tab-title-<?php echo $id_int . $tab_count; ?>"
						class="ec-tab-title <?php echo esc_attr( $active_class ); ?>"
						aria-controls="ec-tab-content-<?php echo $id_int . $tab_count; ?>"><?php echo $item['tab_title']; ?></div> <!-- /.ec-tab-title -->
				<?php endforeach; ?>
			</div> <!-- /.ec-tabs-controls -->

			<div class="ec-tabs-content">
				<?php
				foreach ( $tabs as $index => $item ) :
					$tab_count    = $index + 1;
					$active_class = ( ( $settings['active_tab'] - 1 ) === $index ) ? 'ec-active' : '';
					?>
					<div id="ec-tab-content-<?php echo $id_int . $tab_count; ?>"
						class="ec-tab-content <?php echo esc_attr( $active_class ); ?>">
						<?php
						if ( 'content' === $item['tab_content_type'] ) :

							echo $this->parse_text_editor( $item['tab_content'] ); // phpcs:ignore WordPress.Security.EscapeOutput

						elseif ( 'template' === $item['tab_content_type'] ) :

							if ( '0' !== $item['tab_template'] && ! empty( $item['tab_template'] ) ) {
								echo Plugin::instance()->frontend->get_builder_content_for_display( $item['tab_template'] ); // phpcs:ignore WordPress.Security.EscapeOutput
							}

						endif;
						?>
					</div>
				<?php endforeach; ?>
			</div> <!-- /.ec-tabs-content -->
		</div> <!-- /.ec-tabs-wrapper -->
		<?php
	}
}
