<?php

namespace CompanionElementor\Modules\Team\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Utils;

defined( 'ABSPATH' ) || exit;

class Team extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-team';
	}

	public function get_title() {
		return __( 'Team', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-person';
	}

	public function get_keywords() {
		return [ 'companion', 'team', 'member' ];
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_cta_controls();
		$this->register_style_general_controls();
		$this->register_style_image_controls();
		$this->register_style_name_controls();
		$this->register_style_designation_controls();
		$this->register_style_divider_controls();
		$this->register_style_description_controls();
		$this->register_style_social_controls();
		$this->register_style_cta_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'section_general',
			[
				'label' => esc_html__( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'companion-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'name',
			[
				'label'       => esc_html__( 'Name', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'John Doe', 'companion-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'designation',
			[
				'label'       => esc_html__( 'Designation', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'WordPress Developer', 'companion-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'description',
			[
				'label'   => esc_html__( 'Description', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'companion-elementor' ),
				'rows'    => 10,
			]
		);

		// Content > Divider
		$this->add_control(
			'show_divider',
			[
				'label'        => esc_html__( 'Divider', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'separator'    => 'before',
				'default'      => 'no',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			]
		);

		// Content > Position.
		$this->add_control(
			'divider_position',
			array(
				'label'     => esc_html__( 'Position', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'after_designation',
				'options'   => array(
					'after_designation'  => esc_html__( 'After Designation', 'companion-elementor' ),
					'before_designation' => esc_html__( 'Before Designation', 'companion-elementor' ),
				),
				'condition' => [
					'show_divider' => 'yes',
				],
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'   => esc_html__( 'Title', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Facebook', 'companion-elementor' ),
			]
		);

		$repeater->add_control(
			'link',
			[
				'label'   => esc_html__( 'Link', 'companion-elementor' ),
				'type'    => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => 'https://www.facebook.com/',
				],
			]
		);

		$repeater->add_control(
			'icon_v5',
			[
				'label'            => esc_html__( 'Social Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => [
					'value'   => 'fab fa-facebook-f',
					'library' => 'fa-brands',
				],
			]
		);

		$this->add_control(
			'socials',
			[
				'label'       => esc_html__( 'Social Links', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'   => esc_html__( 'Facebook', 'companion-elementor' ),
						'link'    => esc_url( 'https://www.facebook.com/' ),
						'icon_v5' => [
							'value'   => 'fab fa-facebook-f',
							'library' => 'fa-brands',
						],
					],
					[
						'title'   => esc_html__( 'Twitter', 'companion-elementor' ),
						'link'    => esc_url( 'https://www.twitter.com/' ),
						'icon_v5' => [
							'value'   => 'fab fa-twitter',
							'library' => 'fa-brands',
						],
					],
					[
						'title'   => esc_html__( 'Linkedin', 'companion-elementor' ),
						'link'    => esc_url( 'https://www.linkedin.com/' ),
						'icon_v5' => [
							'value'   => 'fab fa-linkedin-in',
							'library' => 'fa-brands',
						],
					],
				],
				'title_field' => '{{{title}}}',
			]
		);

		$this->end_controls_section();
	}

	private function register_cta_controls() {
		$this->start_controls_section(
			'section_cta',
			[
				'label' => esc_html__( 'Call To Action', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'cta_type',
			[
				'label'   => esc_html__( 'Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'none'    => esc_html__( 'None', 'companion-elementor' ),
					'element' => esc_html__( 'Element', 'companion-elementor' ),
					'text'    => esc_html__( 'Text', 'companion-elementor' ),
					'button'  => esc_html__( 'Button', 'companion-elementor' ),
					'box'     => esc_html__( 'Box', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'cta_text',
			[
				'label'       => esc_html__( 'Text', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Learn More', 'companion-elementor' ),
				'label_block' => true,
				'condition'   => [
					'cta_type' => [ 'text', 'button' ],
				],
			]
		);

		$this->add_control(
			'cta_link',
			[
				'label'       => esc_html__( 'Link', 'companion-elementor' ),
				'type'        => Controls_Manager::URL,
				'default'     => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
				'placeholder' => esc_html__( 'https://your-link.com', 'companion-elementor' ),
				'condition'   => [
					'cta_type!' => 'none',
				],
			]
		);

		$this->add_control(
			'cta_link_to',
			[
				'label'     => esc_html__( 'Link To', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT2,
				'multiple'  => true,
				'options'   => [
					'title' => esc_html__( 'Title', 'companion-elementor' ),
					'icon'  => esc_html__( 'Icon', 'companion-elementor' ),
				],
				'default'   => [ 'title' ],
				'condition' => [
					'cta_type' => 'element',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_general_controls() {
		$this->start_controls_section(
			'section_style_general',
			[
				'label' => esc_html__( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_alignment',
			[
				'label'       => esc_html__( 'Content Alignment', 'companion-elementor' ),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'     => 'center',
				'selectors'   => [
					'{{WRAPPER}} .ec-team' => 'text-align: {{VALUE}};',
				],
				'label_block' => true,
			]
		);

		$this->end_controls_section();
	}

	private function register_style_image_controls() {
		$this->start_controls_section(
			'section_style_image',
			[
				'label' => esc_html__( 'Image', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_position',
			[
				'label'              => esc_html__( 'Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'top',
				'options'            => [
					'left'  => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'top'   => [
						'title' => esc_html__( 'Top', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'prefix_class'       => 'ec-team-image%s--',
				'frontend_available' => true,
			]
		);

		$this->add_responsive_control(
			'image_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
					'%',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 600,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 37.5,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 37.5,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 120,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-team .ec-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'image_border',
				'selector' => '{{WRAPPER}} .ec-team .ec-image-inner',
			]
		);

		$this->add_control(
			'image_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-team .ec-image-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ec-team .ec-image-inner img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-team .ec-image-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-team .ec-image-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_name_controls() {
		$this->start_controls_section(
			'section_style_name',
			[
				'label' => esc_html__( 'Name', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'name_tag',
			[
				'label'   => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h3',
				'options' => [
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-name' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'selector' => '{{WRAPPER}} .ec-name',
			]
		);

		$this->add_responsive_control(
			'name_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_designation_controls() {
		$this->start_controls_section(
			'section_style_designation',
			[
				'label' => esc_html__( 'Designation', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'designation_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-designation' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'designation_typography',
				'selector' => '{{WRAPPER}} .ec-designation',
			]
		);

		$this->add_responsive_control(
			'designation_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-designation' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_divider_controls() {
		$this->start_controls_section(
			'section_style_divider',
			[
				'label' => esc_html__( 'Divider', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'divider_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-divider::after' => 'border-bottom-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'divider_width',
			[
				'label'     => __( 'Width', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-divider::after' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'divider_spacing',
			[
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-divider::after' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_description_controls() {
		$this->start_controls_section(
			'section_style_description',
			[
				'label' => esc_html__( 'Description', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .ec-description',
			]
		);

		$this->add_responsive_control(
			'description_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_social_controls() {
		$this->start_controls_section(
			'section_style_social',
			[
				'label' => esc_html__( 'Social Links', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'social_width',
			[
				'label'      => esc_html__( 'Width', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-social a' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'social_height',
			[
				'label'      => esc_html__( 'Height', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-social a'   => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-social a i' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'social_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-social a i'   => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-social a svg' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-social a svg' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'social_icon_spacing',
			[
				'label'      => esc_html__( 'Icon Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-social a:not(:first-child)' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'social_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-social' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'           => 'social_border',
				'fields_options' => [
					'border' => [
						'default' => 'solid',
					],
					'width'  => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color'  => [
						'default' => '#e9ecef',
					],
				],
				'selector'       => '{{WRAPPER}} .ec-social a',
			]
		);

		$this->add_control(
			'social_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'social_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-social a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'social_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-social a',
			]
		);

		$this->start_controls_tabs(
			'social_tabs'
		);

		$this->start_controls_tab(
			'social_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'social_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-social a i'   => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-social a svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'social_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-social a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'social_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'social_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-social a:hover i'   => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-social a:hover svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'social_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-social a:hover',
			]
		);

		$this->add_control(
			'social_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-social a:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_cta_controls() {
		$this->start_controls_section(
			'section_style_cta',
			[
				'label'     => esc_html__( 'Call To Action', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'cta_type!' => [ 'none', 'element', 'box' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'cta_typography',
				'selector' => '{{WRAPPER}} .ec-team-cta',
			]
		);

		$this->add_responsive_control(
			'cta_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-team-cta.ec-cta-btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => [ 'button' ],
				],
			]
		);

		$this->add_responsive_control(
			'cta_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-team-cta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'cta_border',
				'selector'  => '{{WRAPPER}} .ec-team-cta.ec-cta-btn a, {{WRAPPER}} .ec-team-cta.ec-cta-icon a',
				'condition' => [
					'cta_type' => [ 'button' ],
				],
			]
		);

		$this->add_responsive_control(
			'cta_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-team-cta.ec-cta-btn a, {{WRAPPER}} .ec-team-cta.ec-cta-icon a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => [ 'button' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'cta_box_shadow',
				'label'     => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector'  => '{{WRAPPER}} .ec-team-cta.ec-cta-btn a, {{WRAPPER}} .ec-team-cta.ec-cta-icon a',
				'condition' => [
					'cta_type' => [ 'button' ],
				],
			]
		);

		$this->start_controls_tabs(
			'cta_tabs'
		);

		$this->start_controls_tab(
			'cta_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-team-cta a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cta_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-team-cta.ec-cta-btn a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cta_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-team-cta a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cta_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-team-cta.ec-cta-btn a:hover',
			]
		);

		$this->add_control(
			'cta_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-team-cta.ec-cta-btn a:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/team-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				/* Translators: 1: Opening anchor tag, 2: Closing anchor tag */
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings         = $this->get_settings_for_display();
		$image            = $settings['image'] ? $settings['image']['url'] : '';
		$designation      = $settings['designation'];
		$divider_position = $settings['divider_position'];
		$name             = $settings['name'];
		$description      = $settings['description'];
		$name_tag         = $settings['name_tag'];
		$cta_type         = $settings['cta_type'];
		$link             = $settings['cta_link'];
		$link_to          = $settings['cta_link_to'];
		$cta_text         = $settings['cta_text'];

		$link_to_icon   = ( $link_to && $link['url'] && in_array( 'icon', $link_to, true ) );
		$link_to_title  = ( $link_to && $link['url'] && in_array( 'title', $link_to, true ) );
		$show_cta       = ( 'icon' === $cta_type ) || ( 'text' === $cta_type ) || ( 'button' === $cta_type );
		$is_link_to_cta = ( $show_cta && isset( $link['url'] ) );
		$is_link_to_box = ( 'box' === $cta_type ) && isset( $link['url'] );
		?>

		<div class="ec-team-wrapper">
			<div class="ec-team">

				<?php if ( $is_link_to_box ) : ?>
					<a class="ec-team__link" href="<?php echo esc_url( $link['url'] ); ?>" <?php echo $link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $link['nofollow'] ? 'rel="nofollow"' : ''; ?>></a>
				<?php endif; ?>

				<div class="ec-image">

					<?php if ( $image ) : ?>
						<div class="ec-image-inner">
							<?php if ( $link_to_icon ) : ?>
								<a href="<?php echo esc_url( $link['url'] ); ?>" <?php echo $link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $link['nofollow'] ? 'rel="nofollow"' : ''; ?>>
							<?php endif; ?>
								<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $name ); ?>">
							<?php if ( $link_to_icon ) : ?>
								</a>
							<?php endif; ?>
						</div> <!-- /.ec-image-inner -->
					<?php endif; ?>
				</div> <!-- /.ec-image -->

				<?php if ( 'top' != $settings['image_position'] ) : ?>
				<div class="ec-team-content-social">
				<?php endif; ?>

					<div class="ec-team-content">
						<!-- Name -->
						<?php if ( $name ) : ?>
							<<?php echo esc_attr( $name_tag ); ?> class="ec-name">
								<?php if ( $link_to_title ) : ?>
									<a href="<?php echo esc_url( $link['url'] ); ?>" <?php echo $link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $link['nofollow'] ? 'rel="nofollow"' : ''; ?>>
								<?php endif; ?>
									<?php echo esc_html( $name ); ?>
								<?php if ( $link_to_title ) : ?>
									</a>
								<?php endif; ?>
							</<?php echo esc_attr( $name_tag ); ?>>
						<?php endif; ?>

						<!-- Designation -->
						<?php if ( $divider_position === 'before_designation' ) : ?>
							<div class="ec-divider">
						</div>
						<?php endif; ?>

						<!-- Designation -->
						<?php if ( $designation ) : ?>
							<span class="ec-designation">
									<?php echo esc_html( $designation ); ?>
								</span>
						<?php endif; ?>

						<!-- Designation -->
						<?php if ( $divider_position === 'after_designation' ) : ?>
							<div class="ec-divider">
						</div>
						<?php endif; ?>

						<?php if ( $description ) : ?>
							<div class="ec-description">
								<?php echo wp_kses_post( $description ); ?>
							</div>
						<?php endif; ?>
					</div> <!-- /.ec-team-content -->

					<?php if ( $settings['socials'] ) : ?>
						<div class="ec-social">
							<?php foreach ( $settings['socials'] as $social ) : ?>
								<?php if ( ! empty( $social['icon_v5'] ) || array_key_exists( 'icon', $social ) ) : ?>
									<a href="<?php echo esc_url( $social['link']['url'] ); ?>"
										<?php echo( ! empty( $social['link']['is_external'] ) ? 'target="_blank"' : '' ); ?>
										<?php echo( ! empty( $social['link']['nofollow'] ) ? 'rel="nofollow"' : '' ); ?> >
										<?php
										$migrated = isset( $social['__fa4_migrated']['icon_v5'] );
										$is_new   = ! array_key_exists( 'icon', $social );
										if ( $is_new || $migrated ) :
											Icons_Manager::render_icon( $social['icon_v5'], [ 'aria-hidden' => 'true' ] );
										else :
											?>
											<i class="<?php echo ( is_array( $social['icon'] ) ? $social['icon']['value'] : $social['icon'] ); ?>" aria-hidden="true"></i>
										<?php endif; ?>
									</a>
								<?php endif; ?>
							<?php endforeach; ?>
						</div> <!-- /.ec-social -->
					<?php endif; ?>

					<?php if ( $show_cta && $cta_text ) : ?>
						<div class="ec-team-cta <?php echo ( 'button' === $cta_type ) ? esc_attr( 'ec-cta-btn' ) : ''; ?> <?php echo ( 'icon' === $cta_type ) ? esc_attr( 'ec-cta-icon' ) : ''; ?>">
							<?php if ( $is_link_to_cta ) : ?>
								<a href="<?php echo esc_url( $link['url'] ); ?>" <?php echo $link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $link['nofollow'] ? 'rel="nofollow"' : ''; ?>>
							<?php endif; ?>

								<span class="ec-cta-text"><?php echo esc_html( $cta_text ); ?></span>

							<?php if ( $is_link_to_cta ) : ?>
								</a>
							<?php endif; ?>

						</div> <!-- /.ec-team-cta -->
					<?php endif; ?>

				<?php if ( 'top' != $settings['image_position'] ) : ?>
				</div> <!-- /.ec-team-content-social -->
				<?php endif; ?>

			</div> <!-- /.ec-team -->
		</div> <!-- /.ec-team-wrapper -->
		<?php
	}
}
