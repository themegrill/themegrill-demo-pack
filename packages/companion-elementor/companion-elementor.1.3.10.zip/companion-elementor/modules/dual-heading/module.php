<?php

namespace CompanionElementor\Modules\DualHeading;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Dual_Heading',
		];
	}

	public function get_name() {
		return 'dual-heading';
	}

}
