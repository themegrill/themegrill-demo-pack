<?php

namespace CompanionElementor\Modules\DualHeading\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;

defined( 'ABSPATH' ) || exit;

class Dual_Heading extends Base_Widget {


	public function get_name() {
		return 'elementor-companion-dual-heading';
	}

	public function get_title() {
		return __( 'Dual Heading', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-editor-h1';
	}

	public function get_keywords() {
		return array( 'companion', 'dual heading', 'headings' );
	}


	protected function register_controls() {
		$this->register_general_controls();
		$this->register_style_headings_controls();
		$this->register_style_description_controls();
		$this->register_style_icon_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		/**
		 * Section : Content > Dual Heading.
		 */
		$this->start_controls_section(
			'ec_dual_heading_section',
			array(
				'label' => esc_html__( 'Dual Heading', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		// Content > Dual Heading > Layout.
		$this->add_control(
			'layout',
			array(
				'label'   => esc_html__( 'Layout', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'default'        => esc_html__( 'Default', 'companion-elementor' ),
					'iconTop'        => esc_html__( 'Icon Top', 'companion-elementor' ),
					'descriptionTop' => esc_html__( 'Description Top', 'companion-elementor' ),
					'headingBottom'  => esc_html__( 'Heading Bottom', 'companion-elementor' ),
				),
			)
		);

		// Content > Dual Heading > First Text.
		$this->add_control(
			'first_text',
			array(
				'label'   => esc_html__( 'First Text', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Headings are', 'companion-elementor' ),
			)
		);

		// Content > Dual Heading > First > Link.
		$this->add_control(
			'first_link',
			array(
				'label'       => esc_html__( 'Link', 'companion-elementor' ),
				'type'        => Controls_Manager::URL,
				'default'     => array(
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				),
				'placeholder' => esc_html__( 'https://your-link.com', 'companion-elementor' ),
			)
		);

		// Content > Dual Heading > Second Text.
		$this->add_control(
			'second_text',
			array(
				'label'   => esc_html__( 'Second Text', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Amazing', 'companion-elementor' ),
			)
		);

		// Content > Dual Heading > Second > Link.
		$this->add_control(
			'second_link',
			array(
				'label'       => esc_html__( 'Link', 'companion-elementor' ),
				'type'        => Controls_Manager::URL,
				'default'     => array(
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				),
				'placeholder' => esc_html__( 'https://your-link.com', 'companion-elementor' ),
			)
		);

		// Content > Dual Heading > HTML TAG.
		$this->add_control(
			'html_tag',
			array(
				'label'   => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => array(
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				),
			)
		);

		// Content > Dual Heading > Show Description.
		$this->add_control(
			'show_description',
			[
				'label'        => esc_html__( 'Show Description', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			]
		);

		// Content > Dual Heading > Description.
		$this->add_control(
			'description',
			[
				'type'      => Controls_Manager::TEXTAREA,
				'default'   => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'companion-elementor' ),
				'condition' => [
					'show_description' => 'yes',
				],
			],
		);

		// Content > Dual Heading > Show Description.
		$this->add_control(
			'show_icon',
			[
				'label'        => esc_html__( 'Show Icon', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'icon',
			[
				'label'       => __( 'Icon', 'companion-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => [
					'value'   => 'fas fa-book-open',
					'library' => 'fa-solid',
				],
				'skin'        => 'inline',
				'label_block' => false,
				'condition'   => [
					'show_icon' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_headings_controls() {
		/**
		 * Section : Style > Headings.
		 */
		$this->start_controls_section(
			'ec_dual_heading_headings_style_section',
			array(
				'label' => esc_html__( 'Headings', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		// Style > Headings > Alignment.
		$this->add_responsive_control(
			'headings_alignment',
			array(
				'label'        => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					),
				),
				'default'      => 'left',
				'prefix_class' => 'ec-dual-heading--',
				'selectors'    => array(
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				),
			)
		);

		// Style > Headings > Stacked.
		$this->add_control(
			'headings_stacked',
			array(
				'label'        => esc_html__( 'Stacked', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			)
		);

		// Style > Headings > Stacked > Desktop > Gap.
		$this->add_responsive_control(
			'headings_gap',
			array(
				'label'      => esc_html__( 'Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
				),
				'range'      => array(
					'px' => array(
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-first-text' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: 0;',
					'{{WRAPPER}} .ec-stacked .ec-first-text' => 'margin-right: 0; margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		// Style > Headings > Margin.
		$this->add_responsive_control(
			'headings_margin',
			array(
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-dual-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		/**
*
	* ========== Tabs : Style > Headings. ==========
*/
		$this->start_controls_tabs(
			'headings_tabs'
		);

		// Tab : Style > Headings > First.
		$this->start_controls_tab(
			'first_heading',
			array(
				'label' => esc_html__( 'First', 'companion-elementor' ),
			)
		);

		// Style > Headings > First > Color.
		$this->add_control(
			'first_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-first-text' => 'color: {{VALUE}}',
				),
			)
		);

		// Content > Dual Heading > HTML TAG.
		$this->add_control(
			'first_bg_style',
			array(
				'label'   => esc_html__( 'Background Style', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'normal',
				'options' => array(
					'normal'  => esc_html__( 'Normal', 'companion-elementor' ),
					'clipped' => esc_html__( 'Clipped', 'companion-elementor' ),
				),
			)
		);

		// Style > Headings > First > Typography.
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'first_typography',
				'selector' => '{{WRAPPER}} .ec-first-text',
			)
		);

		// Style > Headings > First > Advanced Styling > Text Shadow.
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			array(
				'name'     => 'first_text_shadow',
				'label'    => esc_html__( 'Text Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-first-text',
			)
		);

		// Style > Headings > First > Advanced Styling > Padding.
		$this->add_responsive_control(
			'first_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-first-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Style > Headings > First > Advanced Styling > Background.
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'first_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-first-text',
			)
		);

		// Style > Headings > First > Advanced Styling > Border.
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'first_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-first-text',
			)
		);

		// Style > Headings > First > Advanced Styling > Border Radius.
		$this->add_responsive_control(
			'first_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-first-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Style > Headings > First > Advanced Styling > Box Shadow.
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'first_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-first-text',
			)
		);

		$this->end_controls_tab();

		// Tab : Style > Headings > Second.
		$this->start_controls_tab(
			'second_heading',
			array(
				'label' => esc_html__( 'Second', 'companion-elementor' ),
			)
		);

		// Style > Headings > Second > Color.
		$this->add_control(
			'second_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#269bd1',
				'selectors' => array(
					'{{WRAPPER}} .ec-second-text' => 'color: {{VALUE}}',
				),
			)
		);

		// Style > Headings > Second > Color.
		$this->add_control(
			'second_bg_style',
			array(
				'label'   => esc_html__( 'Background Style', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'normal',
				'options' => array(
					'normal'  => esc_html__( 'Normal', 'companion-elementor' ),
					'clipped' => esc_html__( 'Clipped', 'companion-elementor' ),
				),
			)
		);

		// Style > Headings > Second > Typography.
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'second_typography',
				'selector' => '{{WRAPPER}} .ec-second-text',
			)
		);

		// Style > Headings > Second > Advanced Styling > Text Shadow.
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			array(
				'name'     => 'second_text_shadow',
				'label'    => esc_html__( 'Text Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-second-text',
			)
		);

		// Style > Headings > Second > Advanced Styling > Padding.
		$this->add_responsive_control(
			'second_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-second-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Style > Headings > Second > Advanced Styling > Background.
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'second_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-second-text',
			)
		);

		// Style > Headings > Second > Advanced Styling > Border.
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'second_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-second-text',
			)
		);

		// Style > Headings > Second > Advanced Styling > Border Radius.
		$this->add_responsive_control(
			'second_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-second-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Style > Headings > Second > Advanced Styling > Box Shadow.
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'second_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-second-text',
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section(); // Section : Style > Headings.
	}

	private function register_style_description_controls() {
		/**
		 * Section : Style > Description.
		 */
		$this->start_controls_section(
			'ec_dual_heading_description_style_section',
			array(
				'label' => esc_html__( 'Description', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		// Style > Description > Color.
		$this->add_control(
			'description_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-dual-heading-description' => 'color: {{VALUE}}',
				),
			)
		);

		// Style > Description > Typography.
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .ec-dual-heading-description',
			)
		);

		$this->end_controls_section();
	}

	private function register_style_icon_controls() {
		/**
		 * Section : Style > Icon.
		 */
		$this->start_controls_section(
			'ec_dual_heading_icon_style_section',
			array(
				'label' => esc_html__( 'Icon', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		// Style > Icon > Color.
		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-dual-heading-icon i' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 32,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-dual-heading-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/dual-heading/';

		$this->start_controls_section(
			'section_helpful_info',
			array(
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'help_doc',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings        = $this->get_settings_for_display();
		$html_tag        = $settings['html_tag'];
		$first_text      = $settings['first_text'];
		$first_link      = $settings['first_link'];
		$second_text     = $settings['second_text'];
		$second_link     = $settings['second_link'];
		$layout          = $settings['layout'];
		$class           = 'ec-dual-heading-wrapper';
		$icon            = $settings['icon'];
		$description     = $settings['description'];
		$first_bg_style  = ( 'clipped' === $settings['first_bg_style'] ) ? 'ec-first-text-clipped' : '';
		$second_bg_style = ( 'clipped' === $settings['second_bg_style'] ) ? 'ec-second-text-clipped' : '';

		$stack_class = ( 'yes' === $settings['headings_stacked'] ) ? ' ec-stacked' : '';

		$first_html_tag  = $first_link['url'] ? 'a' : 'span';
		$second_html_tag = $second_link['url'] ? 'a' : 'span';

		$first_attrs = '';
		if ( $first_link['url'] ) {
			$first_attrs  = ' href="' . $first_link['url'] . '"';
			$first_attrs .= $first_link['is_external'] ? ' target="_blank"' : '';
			$first_attrs .= $first_link['nofollow'] ? ' rel="nofollow"' : '';

		}

		$second_attrs = '';
		if ( $second_link['url'] ) {
			$second_attrs  = ' href="' . $second_link['url'] . '"';
			$second_attrs .= $second_link['is_external'] ? ' target="_blank"' : '';
			$second_attrs .= $second_link['nofollow'] ? ' rel="nofollow"' : '';

		}

		if ( 'iconTop' === $layout ) {
			$class .= ' icon-top';
		} elseif ( 'descriptionTop' === $layout ) {
			$class .= ' description-top';
		} elseif ( 'headingBottom' === $layout ) {
			$class .= ' heading-bottom';
		}

		$this->add_inline_editing_attributes( 'first_text', 'basic' );
		$this->add_render_attribute(
			'first_text',
			array(
				'class' => array( 'ec-first-text', esc_attr__( $first_bg_style ) ),
			)
		);

		$this->add_inline_editing_attributes( 'second_text', 'basic' );
		$this->add_render_attribute(
			'second_text',
			array(
				'class' => array( 'ec-second-text', esc_attr__( $second_bg_style ) ),
			)
		);
		?>

		<div class="<?php echo esc_attr( $class ); ?>">

		<<?php echo esc_attr( $html_tag ); ?> class="ec-dual-heading <?php echo esc_attr( $stack_class ); ?>">

		<?php if ( $first_text ) : ?>
			<<?php echo esc_attr( $first_html_tag ); ?> <?php echo $this->get_render_attribute_string( 'first_text' ); ?> <?php echo $first_attrs; ?>>
				<?php echo esc_html( $first_text ); ?>
			</<?php echo esc_attr( $first_html_tag ); ?>>
		<?php endif; ?>

		<?php if ( $second_text ) : ?>
			<<?php echo esc_attr( $second_html_tag ); ?> <?php echo $this->get_render_attribute_string( 'second_text' ); ?> <?php echo $second_attrs; ?>>
				<?php echo esc_html( $second_text ); ?>
			</<?php echo esc_attr( $second_html_tag ); ?>>
		<?php endif; ?>

		</<?php echo esc_attr( $html_tag ); ?>>

		<?php if ( $description ) : ?>
			<div class="ec-dual-heading-description">
					<?php echo esc_html( $description ); ?>
			</div>
		<?php endif; ?>

		<?php if ( $icon ) : ?>
			<div class="ec-dual-heading-icon">
				<i class="<?php echo ( is_array( $settings['icon'] ) ? $settings['icon']['value'] : $settings['icon'] ); ?>" aria-hidden="true"></i>
			</div>
		<?php endif; ?>

		</div> <!-- /.ec-dual-heading-wrapper -->

		<?php
	}
}
