<?php

namespace CompanionElementor\Modules\Table\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;

defined( 'ABSPATH' ) || exit;

class Table extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-table';
	}

	public function get_title() {
		return __( 'Table', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-table';
	}

	public function get_keywords() {
		return [ 'companion', 'data', 'table' ];
	}

	protected function register_controls() {

		$this->register_table_header_controls();
		$this->register_table_body_controls();
		$this->register_table_settings_controls();
		$this->register_style_header_controls();
		$this->register_style_body_controls();
	}

	private function register_table_header_controls() {
		$this->start_controls_section(
			'section_head',
			[
				'label' => __( 'Table Head', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'header_content_type',
			[
				'label'   => __( 'Action', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'row',
				'options' => [
					'row'  => __( 'Create New Row', 'companion-elementor' ),
					'cell' => __( 'Add Cell', 'companion-elementor' ),
				],
			]
		);

		$repeater->start_controls_tabs(
			'header_cell_tabs',
			[
				'condition' => [
					'header_content_type' => 'cell',
				],
			]
		);

		$repeater->start_controls_tab(
			'header_cell_content_tab',
			[
				'label' => __( 'Content', 'companion-elementor' ),
			]
		);

		$repeater->add_control(
			'header_text',
			[
				'label'     => __( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'condition' => [
					'header_content_type' => 'cell',
				],
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab(
			'header_cell_icon_tab',
			[
				'label' => __( 'Icon', 'companion-elementor' ),
			]
		);

		$repeater->add_control(
			'header_icon',
			[
				'label'   => __( 'Icon', 'companion-elementor' ),
				'type'    => Controls_Manager::ICON,
				'default' => '',
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab(
			'header_cell_additional_tab',
			[
				'label' => __( 'Additional', 'companion-elementor' ),
			]
		);

		$repeater->add_control(
			'header_colspan',
			[
				'label'   => __( 'Horizontal Expand', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 20,
				'step'    => 1,
				'default' => 1,
			]
		);

		$repeater->add_control(
			'header_rowspan',
			[
				'label'   => __( 'Vertical Expand', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 20,
				'step'    => 1,
				'default' => 1,
			]
		);

		$repeater->end_controls_tab();

		$repeater->end_controls_tabs();

		$this->add_control(
			'table_header_repeater',
			[
				'label'       => __( 'Table Header Data', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'header_content_type' => 'row',
					],
					[
						'header_content_type' => 'cell',
						/* Translators: %s number. */
						'header_text'         => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 1 ),
					],
					[
						'header_content_type' => 'cell',
						/* Translators: %s number. */
						'header_text'         => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 2 ),
					],

				],
				'title_field' => '{{{ header_content_type }}} : {{{ header_text }}}',
			]
		);

		$this->end_controls_section();
	}

	private function register_table_body_controls() {
		$this->start_controls_section(
			'section_body',
			[
				'label' => __( 'Table Body', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new Repeater();

		$repeater->add_control(
			'body_content_type',
			[
				'label'   => __( 'Action', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'row',
				'options' => [
					'row'  => __( 'Create New Row', 'companion-elementor' ),
					'cell' => __( 'Add Cell', 'companion-elementor' ),
				],
			]
		);

		$repeater->add_control(
			'body_row_heading',
			[
				'label'        => __( 'Make this Row a Heading', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'companion-elementor' ),
				'label_off'    => __( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'body_content_type' => 'row',
				],
			]
		);

		$repeater->start_controls_tabs(
			'body_cell_tabs',
			[
				'condition' => [
					'body_content_type' => 'cell',
				],
			]
		);

		$repeater->start_controls_tab(
			'body_cell_content_tab',
			[
				'label' => __( 'Content', 'companion-elementor' ),
			]
		);

		$repeater->add_control(
			'body_text',
			[
				'label' => __( 'Text', 'companion-elementor' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab(
			'body_cell_icon_tab',
			[
				'label' => __( 'Icon', 'companion-elementor' ),
			]
		);

		$repeater->add_control(
			'body_icon',
			[
				'label'   => __( 'Icon', 'companion-elementor' ),
				'type'    => Controls_Manager::ICON,
				'default' => '',
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab(
			'body_cell_additional_tab',
			[
				'label' => __( 'Additional', 'companion-elementor' ),
			]
		);

		$repeater->add_control(
			'body_colspan',
			[
				'label'   => __( 'Horizontal Expand', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 20,
				'step'    => 1,
				'default' => 1,
			]
		);

		$repeater->add_control(
			'body_rowspan',
			[
				'label'   => __( 'Vertical Expand', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 20,
				'step'    => 1,
				'default' => 1,
			]
		);

		$repeater->end_controls_tab();

		$repeater->end_controls_tabs();

		$this->add_control(
			'table_body_repeater',
			[
				'label'       => __( 'Table Header Data', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'body_content_type' => 'row',
					],
					[
						'body_content_type' => 'cell',
						/* Translators: %s number. */
						'body_text'         => sprintf( esc_html__( 'Row %1$s Content %2$s', 'companion-elementor' ), 1, 1 ),
					],
					[
						'body_content_type' => 'cell',
						/* Translators: %s number. */
						'body_text'         => sprintf( esc_html__( 'Row %1$s Content %2$s', 'companion-elementor' ), 1, 2 ),
					],
					[
						'body_content_type' => 'row',
					],
					[
						'body_content_type' => 'cell',
						/* Translators: %s number. */
						'body_text'         => sprintf( esc_html__( 'Row %1$s Content %2$s', 'companion-elementor' ), 2, 1 ),
					],
					[
						'body_content_type' => 'cell',
						/* Translators: %s number. */
						'body_text'         => sprintf( esc_html__( 'Row %1$s Content %2$s', 'companion-elementor' ), 2, 2 ),
					],

				],
				'title_field' => '{{{ body_content_type }}} : {{{ body_text }}}',
			]
		);

		$this->end_controls_section();
	}

	private function register_table_settings_controls() {
		$this->start_controls_section(
			'section_settings',
			[
				'label' => __( 'Settings', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'toggle_heading',
			[
				'label'        => __( 'Enable Toggle', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'companion-elementor' ),
				'label_off'    => __( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_header_controls() {
		$this->start_controls_section(
			'section_style_header',
			[
				'label' => __( 'Header', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'header_alignment',
			[
				'label'       => esc_html__( 'Content Alignment', 'companion-elementor' ),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'     => 'center',
				'selectors'   => [
					'{{WRAPPER}} th.ec-table-data' => 'text-align: {{VALUE}};',
				],
				'label_block' => true,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'header_data_typography',
				'selector' => '{{WRAPPER}} th.ec-table-data',
			]
		);

		$this->add_control(
			'header_data_border_width',
			[
				'label'     => esc_html__( 'Border Width', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 1,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} th.ec-table-data' => 'border-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'header_data_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} th.ec-table-data' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'header_data_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} th.ec-table-data' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'header_style_tabs'
		);

		$this->start_controls_tab(
			'header_style_normal_tab',
			[
				'label' => __( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'header_row_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} thead tr' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'header_row_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} thead tr',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'header_style_hover_tab',
			[
				'label' => __( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'header_row_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} thead tr:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'header_row_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} thead tr:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_body_controls() {
		$this->start_controls_section(
			'section_style_body',
			[
				'label' => __( 'Body', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'body_alignment',
			[
				'label'       => esc_html__( 'Content Alignment', 'companion-elementor' ),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'     => 'center',
				'selectors'   => [
					'{{WRAPPER}} td.ec-table-data' => 'text-align: {{VALUE}};',
				],
				'label_block' => true,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'body_data_typography',
				'selector' => '{{WRAPPER}} td.ec-table-data',
			]
		);

		$this->add_control(
			'body_data_border_width',
			[
				'label'     => esc_html__( 'Border Width', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 1,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} td.ec-table-data' => 'border-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'body_data_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} td.ec-table-data' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'body_data_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} td.ec-table-data' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'body_style_tabs'
		);

		$this->start_controls_tab(
			'body_style_normal_tab',
			[
				'label' => __( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'body_row_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} tbody tr' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'body_row_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} tbody tr',
			]
		);

		$this->add_control(
			'body_row_heading_color',
			[
				'label'     => esc_html__( 'Row Heading Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} tbody .ec-tr-heading' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'body_row_heading_bg',
				'label'    => esc_html__( 'Row Heading Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} tbody .ec-tr-heading',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'body_style_hover_tab',
			[
				'label' => __( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'body_row_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} tbody tr:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'body_row_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} tbody tr:hover',
			]
		);

		$this->add_control(
			'body_row_heading_hover_color',
			[
				'label'     => esc_html__( 'Row Heading Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} tbody .ec-tr-heading:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'body_row_heading_hover_bg',
				'label'    => esc_html__( 'Row Heading Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} tbody .ec-tr-heading:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$header_data = $settings['table_header_repeater'];
		$body_data   = $settings['table_body_repeater'];
		$toggle      = 'yes' === $settings['toggle_heading'] ? 'toggle' : '';
		?>
		<div class="ec-table-wrapper <?php echo esc_attr( 'ec-table__' . $toggle ); ?>">
			<table class="ec-table">
				<?php
				if ( count( $header_data ) > 1 || ( 1 === count( $header_data ) && '' != $header_data[0]['header_text'] ) ) {
					echo '<thead>';
				}

				/* TODO: Refactor header and body loop into single block. */
				foreach ( $header_data as $index => $data ) {
					$cell     = '';
					$rowspan  = ( isset( $data['header_rowspan'] ) && ( 1 != $data['header_rowspan'] ) ) ? ' rowspan="' . $data['header_rowspan'] . ' "' : '';
					$colspan  = ( isset( $data['header_colspan'] ) && ( 1 != $data['header_colspan'] ) ) ? ' colspan="' . $data['header_colspan'] . ' "' : '';
					$content  = $data['header_icon'] ? '<i class="' . esc_attr( $data['header_icon'] ) . '"></i>' : '';
					$content .= $data['header_text'] ? '<span class="ec-content">' . wp_kses_post( $data['header_text'] ) . '</span>' : '';

					if ( 'cell' === $data['header_content_type'] ) {
						$cell = 'normal_cell';

						if ( 0 === $index ) {
							$cell = 'first_cell';
						}
					}

					if ( 'row' === $data['header_content_type'] ) {
						$cell = 'new_row';
					}

					switch ( $cell ) {
						// First cell without row.
						case 'first_cell':
							echo '<tr><th class="ec-table-data"' . $rowspan . $colspan . '>' . $content . '</th>';
							break;

						// Create a new row.
						case 'new_row':
							echo '</tr><tr>';
							break;

						// Add a cell.
						case 'normal_cell':
							echo '<th class="ec-table-data"' . $rowspan . $colspan . '>' . $content . '</th>';
							break;
					}
				}

				if ( count( $header_data ) > 1 || ( 1 === count( $header_data ) && '' != $header_data[0]['header_text'] ) ) {
					echo '</thead><!-- /thead -->';
				}

				if ( count( $body_data ) > 1 || ( 1 === count( $body_data ) && '' != $body_data[0]['body_text'] ) ) {
					echo '<tbody>';
				}

				foreach ( $body_data as $index => $data ) {
					$cell      = '';
					$row_class = ( isset( $data['body_row_heading'] ) && 'yes' === $data['body_row_heading'] ) ? 'ec-tr-heading' : '';
					$row_class = $row_class ? 'class="' . $row_class . '"' : '';
					$rowspan   = ( isset( $data['body_rowspan'] ) && ( 1 != $data['body_rowspan'] ) ) ? ' rowspan="' . $data['body_rowspan'] . ' "' : '';
					$colspan   = ( isset( $data['body_colspan'] ) && ( 1 != $data['body_colspan'] ) ) ? ' colspan="' . $data['body_colspan'] . ' "' : '';
					$content   = $data['body_icon'] ? '<i class="' . esc_attr( $data['body_icon'] ) . '"></i>' : '';
					$content  .= $data['body_text'] ? '<span class="ec-content">' . wp_kses_post( $data['body_text'] ) . '</span>' : '';

					if ( 'cell' === $data['body_content_type'] ) {
						$cell = 'normal_cell';

						if ( 0 === $index ) {
							$cell = 'first_cell';
						}
					}

					if ( 'row' === $data['body_content_type'] ) {
						$cell = 'new_row';
					}

					switch ( $cell ) {
						// First cell without row.
						case 'first_cell':
							echo '<tr><td class="ec-table-data" ' . $rowspan . $colspan . '>' . $content . '</td>';
							break;

						// Create a new row.
						case 'new_row':
							echo '</tr><tr ' . $row_class . '>';
							break;

						// Add a cell.
						case 'normal_cell':
							echo '<td class="ec-table-data"' . $rowspan . $colspan . '>' . $content . '</td>';
							break;
					}
				}

				if ( count( $body_data ) > 1 || ( 1 === count( $body_data ) && '' != $body_data[0]['body_text'] ) ) {
					echo '</tbody>';
				}
				?>
			</table>
		</div> <!-- /.ec-table-wrapper -->
		<?php
	}
}
