<?php

namespace CompanionElementor\Modules\GoogleMaps\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;

defined( 'ABSPATH' ) || exit;

class Google_Maps extends Base_Widget {

	protected $api_key = null;

	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->api_key = get_option( 'ec_google_map_api_key', '' );
	}


	public function get_name() {
		return 'elementor-companion-google-maps';
	}

	public function get_title() {
		return __( 'Google Maps', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-google-maps';
	}

	public function get_keywords() {
		return array( 'companion', 'google', 'maps', 'google maps' );
	}

	public function get_script_depends() {
		if ( $this->api_key ) {
			if ( ! wp_script_is( 'ec-google-maps', 'registered' ) ) {
				wp_register_script(
					'ec-google-maps',
					"https://maps.googleapis.com/maps/api/js?key={$this->api_key}&libraries=places&callback=Function.prototype",
					[],
					COMPANION_ELEMENTOR_VERSION,
					true
				);
			}

			return [
				'ec-google-maps',
			];
		}

		return [];
	}

	protected function register_controls() {
		$this->register_map_controls();
		$this->register_map_location_controls();
	}

	private function register_map_controls() {
		$this->start_controls_section(
			'ec_map_general',
			[
				'label' => esc_html__( 'Map', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		if ( empty( $this->api_key ) ) {
			$this->add_control(
				'map_key_notice',
				[
					'type'            => Controls_Manager::RAW_HTML,
					/* Translators: */
					'raw'             => sprintf( __( 'Navigate to <strong><a href="%1$s" target="_blank">Dashboard > %2$s > Integrations</a></strong> to set up <strong>Google Map API Key</strong>.', 'companion-elementor' ), admin_url( 'admin.php?page=companion-addons' ), 'Companion Elementor' ),
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				]
			);
		}

		$this->add_control(
			'zoom',
			[
				'label'     => esc_html__( 'Zoom', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 10,
				],
				'range'     => [
					'px' => [
						'min' => 1,
						'max' => 20,
					],
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'height',
			[
				'label'      => esc_html__( 'Height', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 40,
						'max' => 1440,
					],
				],
				'size_units' => [ 'px', 'em', 'rem', 'vh', 'custom' ],
				'default'    => [
					'size' => 400,
				],
				'selectors'  => [
					'{{WRAPPER}} iframe'         => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-map-canvas' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_map_location_controls() {
		$this->start_controls_section(
			'ec_map_location',
			[
				'label' => esc_html__( 'Location', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'map_location_helper',
			[
				'type'      => \Elementor\Controls_Manager::RAW_HTML,
				'raw'       => '<a href="https://www.latlong.net/" target="_blank">' . esc_html__( 'Click Here', 'companion-elementor' ) . '</a> ' . esc_html__( 'to find Coordinates of your location.', 'companion-elementor' ),
				'separator' => 'after',
			]
		);

		$this->add_control(
			'map_latitude',
			[
				'label'   => esc_html__( 'Latitude', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '27.700769',
			]
		);

		$this->add_control(
			'map_longtitude',
			[
				'label'   => esc_html__( 'Longtitude', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '85.300140',
			]
		);

		$this->add_control(
			'map_custom_marker',
			[
				'label'     => esc_html__( 'Use Custom Marker', 'companion-elementor' ),
				'type'      => Controls_Manager::SWITCHER,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'map_marker_icon',
			[
				'label'     => esc_html__( 'Upload Marker Icon', 'companion-elementor' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'map_custom_marker' => 'yes',
				],
			]
		);

		$this->add_control(
			'map_marker_icon_size_width',
			[
				'label'     => esc_html__( 'Marker Icon Size Width', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 30,
				],
				'range'     => [
					'px' => [
						'min' => 10,
						'max' => 150,
					],
				],
				'condition' => [
					'map_custom_marker' => 'yes',
				],
			]
		);

		$this->add_control(
			'map_marker_icon_size_height',
			[
				'label'     => esc_html__( 'Marker Icon Size height', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 30,
				],
				'range'     => [
					'px' => [
						'min' => 10,
						'max' => 150,
					],
				],
				'condition' => [
					'map_custom_marker' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings          = $this->get_settings_for_display();
		$has_api_key       = get_option( 'ec_google_map_api_key' );
		$lat               = $settings['map_latitude'] ?? '27.700769';
		$long              = $settings['map_longtitude'] ?? '85.300140';
		$title             = $settings['map_location_title'] ?? '';
		$has_custom_marker = $settings['map_custom_marker'] ?? 'no';

		$map_url = add_query_arg(
			[
				'q'      => "$lat,$long",
				'hl'     => 'en',
				'z'      => $settings['zoom']['size'],
				't'      => 'm',
				'output' => 'embed',
				'iwloc'  => 'near',
			],
			'https://maps.google.com/maps',
		);

		$map_options = [
			'map'        => [
				'center'            => [
					'lat' => (float) $lat,
					'lng' => (float) $long,
				],
				'zoom'              => $settings['zoom']['size'],
				'fullscreenControl' => true,
				'mapTypeControl'    => true,
				'streetViewControl' => true,
				'zoomControl'       => true,
				'draggable'         => true,
			],
			'marker'     => [
				'position' => [
					'lat' => (float) $lat,
					'lng' => (float) $long,
				],
				'title'    => $title ?? "$lat, $long",
			],
			'markerIcon' => [
				'url'    => 'yes' === $has_custom_marker ? $settings['map_marker_icon']['url'] ?? null : null,
				'height' => $settings['map_marker_icon_size_height']['size'] ?? 30,
				'width'  => $settings['map_marker_icon_size_width']['size'] ?? 30,
			],

		];

		$this->add_render_attribute(
			'map',
			[
				'data-map-options' => wp_json_encode( $map_options ),
			]
		);

		?>
		<?php if ( $has_api_key ) : ?>
			<div class="ec-map-canvas-wrapper" <?php echo $this->get_render_attribute_string( 'map' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
				<div class="ec-map-canvas"></div>
			</div>
		<?php else : ?>
			<div class="ec-map-iframe">
				<iframe src="<?php echo esc_url( $map_url ); ?>" frameborder="0" width="100%" style="border:none"></iframe>
			</div>
		<?php endif; ?>
		<?php
	}
}
