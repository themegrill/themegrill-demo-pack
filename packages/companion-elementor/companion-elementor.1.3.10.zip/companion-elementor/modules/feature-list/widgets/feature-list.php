<?php
/**
 * Feature list class.
 */

namespace CompanionElementor\Modules\FeatureList\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use Elementor\Repeater;

defined( 'ABSPATH' ) || exit;

class Feature_List extends Base_Widget {


	public function get_name() {
		return 'elementor-companion-feature-list';
	}

	public function get_title() {
		return __( 'Feature List', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-editor-list-ul';
	}

	public function get_keywords() {
		return [ 'companion', 'feature list', 'list' ];
	}


	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_title_controls();
		$this->register_style_description_controls();
		$this->register_style_connector_controls();
	}

	private function register_content_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'feature_list_icon_type',
			[
				'label'   => esc_html__( 'Icon Type', 'companion-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'icon',
				'options' => [
					'icon'  => [
						'title' => esc_html__( 'Icon', 'companion-elementor' ),
						'icon'  => 'eicon-info-circle-o',
					],
					'image' => [
						'title' => esc_html__( 'Image', 'companion-elementor' ),
						'icon'  => 'eicon-image',
					],
				],
			]
		);

		$repeater->add_control(
			'feature_list_icon',
			[
				'label'            => esc_html__( 'Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => [
					'value'   => 'fa fa-heart',
					'library' => 'solid',
				],
				'condition'        => [
					'feature_list_icon_type' => 'icon',
				],
			]
		);

		$repeater->add_control(
			'feature_list_image',
			[
				'label'     => esc_html__( 'Image', 'companion-elementor' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'feature_list_icon_type' => 'image',
				],
			]
		);

		$repeater->add_control(
			'feature_list_custom_styles',
			array(
				'label'        => esc_html__( 'Custom Styles', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => array(
					'feature_list_icon_type' => 'icon',
				),
			)
		);

		$repeater->add_control(
			'feature_list_custom_style_title_color',
			[
				'label'     => esc_html__( 'Title Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .ec-feature-list-title a' => 'color: {{VALUE}};',
				],
				'condition' => [
					'feature_list_custom_styles' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'feature_list_custom_style_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .ec-feature-item-icon' => 'color: {{VALUE}};',
				],
				'condition' => [
					'feature_list_custom_styles' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'feature_list_custom_style_icon_background_color',
			[
				'label'     => esc_html__( 'Icon Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .ec-feature-item-icon' => 'background: {{VALUE}};',
				],
				'condition' => [
					'feature_list_custom_styles' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'feature_list_title',
			[
				'label'       => __( 'Title', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Title', 'companion-elementor' ),
				'dynamic'     => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'feature_list_content',
			[
				'label' => __( 'Content', 'companion-elementor' ),
				'type'  => Controls_Manager::WYSIWYG,
			]
		);

		$this->add_control(
			'tabs',
			array(
				'label'       => __( 'Feature list Items', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						/* Translators: %s number. */

						'feature_list_title'   => sprintf( esc_html__( 'Feature Item %s', 'companion-elementor' ), 1 ),
						'feature_list_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer libero sapien, facilisis non euismod eget, dignissim a ante.', 'companion-elementor' ),
						'feature_list_icon'    => array(
							'value'   => 'fa fa-times',
							'library' => 'solid',
						),
					),
					array(
						/* Translators: %s number. */
						'feature_list_title'   => sprintf( esc_html__( 'Feature Item %s', 'companion-elementor' ), 2 ),
						'feature_list_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer libero sapien, facilisis non euismod eget, dignissim a ante.', 'companion-elementor' ),
						'feature_list_icon'    => array(
							'value'   => 'fa fa-plus',
							'library' => 'solid',
						),
					),
					array(
						/* Translators: %s number. */
						'feature_list_title'   => sprintf( esc_html__( 'Feature Item %s', 'companion-elementor' ), 3 ),
						'feature_list_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer libero sapien, facilisis non euismod eget, dignissim a ante.', 'companion-elementor' ),
						'feature_list_icon'    => array(
							'value'   => 'fa fa-arrow-right',
							'library' => 'solid',
						),
					),
				),
				'title_field' => '{{{ feature_list_title }}}',
			)
		);

		$this->add_control(
			'ec_feature_list_show_connector',
			array(
				'label'        => esc_html__( 'Show Connector', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'separator'    => 'before',
			)
		);

		$this->add_responsive_control(
			'ec_feature_list_icon_position',
			array(
				'label'   => esc_html__( 'Icon Position', 'companion-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'left',
				'options' => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					),
				),
			)
		);

		$this->add_control(
			'ec_feature_list_icon_style',
			array(
				'label'   => esc_html__( 'Icon Style', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'circle',
				'options' => array(
					'circle'  => esc_html__( 'circle', 'companion-elementor' ),
					'square'  => esc_html__( 'square', 'companion-elementor' ),
					'rhombus' => esc_html__( 'Rhombus', 'companion-elementor' ),
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_title_controls() {
		$this->start_controls_section(
			'ec_feature_list_title_style',
			[
				'label' => esc_html__( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'ec_feature_list_title_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .ec-feature-list-title a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'ec_feature_list_title_typography',
				'selector' => '{{WRAPPER}} .ec-feature-list-title',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_description_controls() {
		$this->start_controls_section(
			'ec_feature_list_description_style',
			[
				'label' => esc_html__( 'Description', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'ec_feature_list_description_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-feature-list-description' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ec-feature-item-content p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'ec_feature_list_description_typography',
				'selector' => '{{WRAPPER}} .ec-feature-list-description',
				'selector' => '{{WRAPPER}} .ec-feature-item-content p',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_connector_controls() {
		$this->start_controls_section(
			'ec_feature_list_connector_style',
			[
				'label' => esc_html__( 'Connector', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'ec_feature_list_connector_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-feature-item:not(:last-of-type) .ec-connector' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ec_feature_list_connector_border_type',
			[
				'label'     => esc_html__( 'Border Type', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'none'   => esc_html__( 'None', 'companion-elementor' ),
					'solid'  => esc_html__( 'Solid', 'companion-elementor' ),
					'double' => esc_html__( 'Double', 'companion-elementor' ),
					'dotted' => esc_html__( 'Dotted', 'companion-elementor' ),
					'dashed' => esc_html__( 'Dashed', 'companion-elementor' ),
					'groove' => esc_html__( 'Groove', 'companion-elementor' ),
				],
				'selectors' => [
					'{{WRAPPER}} .ec-feature-item:not(:last-of-type) .ec-connector' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ec_feature_list_connector_border_width',
			[
				'label'     => esc_html__( 'Border Width', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 1,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-feature-item:not(:last-of-type) .ec-connector' => 'border-width: {{SIZE}}{{UNIT}}; border-right: none;',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings                       = $this->get_settings_for_display();
		$tabs                           = $settings['tabs'];
		$ec_feature_list_show_connector = $settings['ec_feature_list_show_connector'];
		$ec_feature_list_icon_position  = $settings['ec_feature_list_icon_position'];
		$ec_feature_list_icon_style     = $settings['ec_feature_list_icon_style'];

		?>
		<div class="ec-feature-list-wrapper">
			<ul class="ec-feature-list">
				<?php
				foreach ( $tabs as $tab ) :
						$icon  = '';
						$image = '';

					if ( 'icon' === $tab['feature_list_icon_type'] && $tab['feature_list_icon']['value'] ) {
						$icon = $tab['feature_list_icon']['value'];
					} elseif ( 'image' === $tab['feature_list_icon_type'] && $tab['feature_list_image']['url'] ) {
						$image = $tab['feature_list_image']['url'];
					}
					?>

					<li class="ec-feature-item
					<?php
					echo 'elementor-repeater-item-' . esc_attr( $tab['_id'] );
					echo ' ' . esc_attr( $ec_feature_list_icon_position );
					?>
					">
						<?php if ( $icon || $image ) : ?>

							<div class="ec-feature-item-icon-wrapper">

							<?php if ( 'yes' === $ec_feature_list_show_connector && 'center' !== $ec_feature_list_icon_position ) : ?>
								<span class="ec-connector"> </span>
							<?php endif; ?>

								<?php if ( $icon ) : ?>
									<span class="ec-feature-item-icon <?php echo 'ec-' . esc_attr( $ec_feature_list_icon_style ); ?>">
										<i class="<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></i>
									</span>
								<?php elseif ( $image ) : ?>
									<div class="ec-feature-item-image">
										<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $tab['feature_list_title'] ); ?>">
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<div class="ec-feature-item-content">
							<h3 class="ec-feature-list-title">
								<a href=""><?php echo esc_html( $tab['feature_list_title'] ); ?></a>
							</h3>
							<p class="ec-feature-list-description">
								<?php echo wp_kses_post( $this->parse_text_editor( $tab['feature_list_content'] ) ); ?>
							</p>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
	}
}
