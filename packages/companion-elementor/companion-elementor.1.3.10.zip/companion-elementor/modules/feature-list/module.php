<?php

namespace CompanionElementor\Modules\FeatureList;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Feature_List',
		];
	}

	public function get_name() {
		return 'feature-list';
	}

}
