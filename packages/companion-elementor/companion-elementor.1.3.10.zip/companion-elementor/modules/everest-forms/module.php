<?php

namespace CompanionElementor\Modules\EverestForms;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Everest_Forms',
		];
	}

	public function get_name() {
		return 'everest-forms';
	}

}
