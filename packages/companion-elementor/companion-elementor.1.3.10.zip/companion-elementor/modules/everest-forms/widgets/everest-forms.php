<?php

namespace CompanionElementor\Modules\EverestForms\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use CompanionElementor\Classes\Utils as CompanionElementorUtils;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

defined( 'ABSPATH' ) || exit;

class Everest_Forms extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-everest-forms';
	}

	public function get_title() {
		return __( 'Everest Forms', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-form-horizontal';
	}

	public function get_keywords() {
		return [ 'companion', 'form', 'forms', 'field', 'button', 'everest forms', 'evf', 'contact' ];
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_style_evf_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {

		if ( file_exists( WP_PLUGIN_DIR . '/everest-forms/everest-forms.php' ) && is_plugin_inactive( 'everest-forms/everest-forms.php' ) ) {
			$evf_link     = admin_url() . 'plugins.php';
			$evf_text     = 'activate';
			$evf_text_two = 'activated';
		}

		if ( ! file_exists( WP_PLUGIN_DIR . '/everest-forms/everest-forms.php' ) ) {
			$evf_link     = admin_url() . 'plugin-install.php?s=Everest+Forms&tab=search&type=term';
			$evf_text     = 'install and activate';
			$evf_text_two = 'installed and activated';
		}

		if ( ! function_exists( 'evf' ) ) {
			$this->start_controls_section(
				'evf_warning',
				[
					'label' => esc_html__( 'Everest Forms', 'companion-elementor' ),
				]
			);

			$this->add_control(
				'evf_warning_text',
				[
					'type' => Controls_Manager::RAW_HTML,
					'raw'  => sprintf(
						/* translators: %1$s: Text Two, %2$s: Text, %3$s: Link */
						__( '<strong>Everest Forms</strong> is not %1$s. Please %2$s <a href="%3$s" target="_blank">Everest Forms</a>.', 'companion-elementor' ),
						isset( $evf_text_two ) ? esc_html( $evf_text_two ) : '',
						isset( $evf_text ) ? esc_html( $evf_text ) : '',
						isset( $evf_link ) ? esc_url( $evf_link ) : ''
					),
				]
			);

			$this->end_controls_section();

		} else {
			$this->start_controls_section(
				'evf',
				[
					'label' => esc_html__( 'Everest Forms', 'companion-elementor' ),
				]
			);

			$this->add_control(
				'evf_list',
				[
					'label'       => esc_html__( 'Select Everest Form', 'companion-elementor' ),
					'type'        => Controls_Manager::SELECT,
					'label_block' => true,
					'options'     => CompanionElementorUtils::get_everest_forms(),
					'default'     => '0',
				]
			);

			$this->end_controls_section();
		}
	}

	private function register_style_evf_controls() {

		$this->start_controls_section(
			'evf_general',
			[
				'label' => esc_html__( 'General', 'companion-elementpr' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'evf_column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '15',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}}  .everest-forms .evf-field-container .evf-frontend-row .evf-frontend-grid.evf-grid-2:first-child' => 'padding-right: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}}  .everest-forms .evf-field-container .evf-frontend-row .evf-frontend-grid.evf-grid-2:last-child'  => 'padding-left: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'evf_row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '10',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .everest-forms .input-text' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'evf_label',
			[
				'label' => esc_html__( 'Label', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'evf_label_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '10',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .evf-field-label' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'evf_label_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .evf-label' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'evf_label_typography',
				'selector' => '{{WRAPPER}} .evf-label',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'evf_field_style',
			[
				'label' => esc_html__( 'Input & Textarea', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'evf_field_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}}  .everest-forms .input-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'evf_field_text',
			[
				'label'     => esc_html__( 'Text Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#494d50',
				'selectors' => [
					'{{WRAPPER}} .everest-forms .input-text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'evf_field_typography',
				'selector' => '{{WRAPPER}} .everest-forms .input-text',
			]
		);

		$this->add_control(
			'evf_field_bg',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .everest-forms .input-text' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->start_controls_tabs( 'evf_field' );

		$this->start_controls_tab(
			'evf_field_normal',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'evf_field_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .everest-forms .input-text',
			]
		);

		$this->add_control(
			'evf_field_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}}  .everest-forms .input-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'evf_field_box_shadow',
				'selector' => '{{WRAPPER}} .everest-forms .input-text:not([type="radio"]):not([type="checkbox"])',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'ec_evf_field_focus',
			[
				'label' => esc_html__( 'Focus', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'evf_field_border_color_focus',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .everest-forms input:focus, {{WRAPPER}} .everest-form select:focus, {{WRAPPER}} .everest-form textarea:focus' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'evf_field_box_shadow_focus',
				'selector' => '{{WRAPPER}} .everest-forms input:not([type="radio"]):not([type="checkbox"]):focus, {{WRAPPER}} .everest-form select:focus, {{WRAPPER}} .everest-form textarea:focus',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'evf_placeholder',
			[
				'label' => esc_html__( 'Placeholder', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'evf_placeholder_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .everest-forms .input-text::-webkit-input-placeholder' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'evf_btn',
			[
				'label' => esc_html__( 'Submit Button', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'evf_btn_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => 'left',
				'selectors' => [
					'{{WRAPPER}} .everest-forms .evf-submit-container' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'evf_btn_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '10',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit], {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'evf_btn_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit], {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'evf_btn_typography',
				'selector' => '{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit], {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]',
			]
		);

		$this->add_control(
			'evf_btn_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit], {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'evf_btn_tabs' );

		$this->start_controls_tab(
			'evf_btn_normal',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'evf_btn_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit], {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'evf_btn_bg',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit], {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'evf_btn_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit], {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'evf_btn_box_shadow',
				'selector' => '{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit], {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'evf_btn_hover',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'evf_btn_color_hover',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit]:hover, {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'evf_btn_bg_hover',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit]:hover, {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'evf_btn_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit]:hover, {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'evf_btn_box_shadow_hover',
				'selector' => '{{WRAPPER}} .everest-forms .evf-submit-container button[type=submit]:hover, {{WRAPPER}} .everest-forms .evf-submit-container input[type=submit]:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/everest-forms/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	public function render() {

		if ( ! function_exists( 'evf' ) ) {
			return;
		}

		$settings = $this->get_settings_for_display();
		$evf_list = $settings['evf_list'];

		if ( ! empty( $evf_list ) ) :
			?>
			<div class="ec-evf-wrapper">
				<?php echo do_shortcode( '[everest_form id="' . $evf_list . '" ]' ); ?>
			</div>
			<?php
		endif;
	}
}
