<?php
/**
 * Offcanvas class.
 */
namespace CompanionElementor\Modules\Offcanvas\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Plugin;

defined( 'ABSPATH' ) || exit;

class Offcanvas extends Base_Widget {


	public function get_name() {
		return 'elementor-companion-offcanvas';
	}

	public function get_title() {
		return __( 'Off Canvas', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-sidebar';
	}

	public function get_keywords() {
		return array( 'companion', 'off Canvas' );
	}


	protected function register_controls() {
		$this->register_offcanvas_content_controls();
		$this->register_style_offcanvas_button_controls();
		$this->register_style_offcanvas_container_controls();
	}

	private function register_offcanvas_content_controls() {
		$this->start_controls_section(
			'section_offcanvas_content',
			array(
				'label' => __( 'Content', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'offcanvas_content_template',
			array(
				'label'       => esc_html__( 'Select Template', 'companion-elementor' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => \CompanionElementor\Classes\Utils::get_templates(),
				'label_block' => true,
				'default'     => '0',
			)
		);

		$this->add_control(
			'show_offcanvas_content_text',
			array(
				'label'        => esc_html__( 'Content Header', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'offcanvas_content_text',
			array(
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Offcanvas', 'companion-elementor' ),
				'condition' => array(
					'show_offcanvas_content_text' => 'yes',
				),
			)
		);

		$this->add_control(
			'offcanvas_content_position',
			array(
				'label'   => esc_html__( 'Position', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'right',
				'options' => array(
					'right' => esc_html__( 'Right', 'companion-elementor' ),
					'left'  => esc_html__( 'Left', 'companion-elementor' ),
				),
			)
		);

		$this->add_control(
			'offcanvas_button_heading',
			array(
				'label' => esc_html__( 'Button', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			)
		);

		$this->add_control(
			'show_offcanvas_button_text',
			array(
				'label'        => esc_html__( 'Show Text', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'offcanvas_button_text',
			array(
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Click Here', 'companion-elementor' ),
				'condition' => array(
					'show_offcanvas_button_text' => 'yes',
				),
			)
		);

		$this->add_control(
			'show_offcanvas_icon',
			array(
				'label'        => esc_html__( 'Show Icon', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'offcanvas_icon',
			array(
				'label'       => __( 'Icon', 'companion-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => array(
					'value'   => 'fas fa-bars',
					'library' => 'fa-solid',
				),
				'skin'        => 'inline',
				'label_block' => false,
				'condition'   => array(
					'show_offcanvas_icon' => 'yes',
				),
			)
		);

		$this->add_responsive_control(
			'offcanvas_icon_position',
			array(
				'label'     => esc_html__( 'Icon Position', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'right',
				'options'   => array(
					'left'  => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'condition' => array(
					'show_offcanvas_icon' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_offcanvas_button_controls() {
		$this->start_controls_section(
			'offcanvas_button_style_section',
			array(
				'label' => esc_html__( 'Button', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'offcanvas_button_typography',
				'selector' => '{{WRAPPER}} .ec-offcanvas',
			)
		);

		$this->start_controls_tabs(
			'offcanvas_button_tabs'
		);

		$this->start_controls_tab(
			'offcanvas_button_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'offcanvas_button_normal_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-offcanvas' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'offcanvas_button_normal_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-offcanvas',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'offcanvas_button_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'offcanvas_button_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-offcanvas:hover' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'offcanvas_button_hover_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-offcanvas:hover',
			)
		);

		$this->end_controls_tab();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'      => 'offcanvas_button_border',
				'selector'  => '{{WRAPPER}} .ec-offcanvas',
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'offcanvas_button_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-offcanvas' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'offcanvas_button_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-offcanvas',
			)
		);

		$this->add_responsive_control(
			'offcanvas_button_icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 24,
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-offcanvas .fa-bars:before' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_offcanvas_container_controls() {
		$this->start_controls_section(
			'ec_offcanvas_container_style_section',
			array(
				'label' => esc_html__( 'Container', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'offcanvas_container_heading',
			array(
				'label'     => esc_html__( 'Container', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'offcanvas_container_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-offcanvas-content',
			)
		);

		$this->add_control(
			'offcanvas_container_border_divider_before',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'offcanvas_container_border',
				'selector' => '{{WRAPPER}} .ec-offcanvas-content',
			)
		);

		$this->add_control(
			'offcanvas_container_border_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_responsive_control(
			'offcanvas_container_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-offcanvas-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'offcanvas_container_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-offcanvas-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings                   = $this->get_settings_for_display();
		$offcanvas_button_text      = $settings['offcanvas_button_text'];
		$offcanvas_content_position = $settings['offcanvas_content_position'];
		$offcanvas_content_text     = $settings['offcanvas_content_text'];
		$offcanvas_icon_position    = $settings['offcanvas_icon_position'];
		$offcanvas_content_template = $settings['offcanvas_content_template'] ?? 0;
		?>
		<div class="ec-offcanvas-wrapper">
			<button class="ec-offcanvas">
				<span class="ec-offcanvas-text <?php echo esc_attr( 'icon-position-' . $offcanvas_icon_position ); ?>">
					<?php echo esc_html( $offcanvas_button_text ); ?>
				</span>
				<i class="<?php echo esc_attr( is_array( $settings['offcanvas_icon'] ) ? $settings['offcanvas_icon']['value'] : $settings['offcanvas_icon'] ); ?>" aria-hidden="true"></i>
			</button>
			<div class="ec-offcanvas-overlay">
				<div class="ec-offcanvas-content <?php echo esc_attr( 'content-position-' . $offcanvas_content_position ); ?>">
					<div class="ec-offcanvas-content-head">
						<button type="button" aria-label="Close" class="ec-offcanvas-close">
							<i class="fa fa-times" aria-hidden="true"></i>
						</button>
						<?php echo esc_html( $offcanvas_content_text ); ?>
					</div>
					<div class="ec-offcanvas-content-body">
						<?php if ( ! $offcanvas_content_template ) : ?>
						<p><?php esc_html_e( 'Please select a template!', 'companion-elementor' ); ?></p>
						<?php else : ?>
							<?php
								echo Plugin::$instance->frontend->get_builder_content_for_display( $offcanvas_content_template ); // phpcs:ignore
							?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>	
		<?php
	}
}
