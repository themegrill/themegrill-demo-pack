<?php

namespace CompanionElementor\Modules\Offcanvas;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return array(
			'Offcanvas',
		);
	}

	public function get_name() {
		return 'offcanvas';
	}
}
