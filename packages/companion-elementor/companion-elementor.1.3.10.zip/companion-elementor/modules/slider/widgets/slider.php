<?php

namespace CompanionElementor\Modules\Slider\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Plugin;

defined( 'ABSPATH' ) || exit;

class Slider extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-slider';
	}

	public function get_title() {
		return __( 'Slider', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-slides';
	}

	public function get_keywords() {
		return [ 'companion', 'slider', 'carousel' ];
	}

	/**
	 * Get style dependencies.
	 *
	 * Retrieve the list of style dependencies the widget requires.
	 *
	 * @since 3.24.0
	 * @access public
	 *
	 * @return array Widget style dependencies.
	 */
	public function get_style_depends(): array {
		return [ 'e-swiper', 'widget-image-carousel' ];
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_settings_controls();
		$this->register_style_slider_controls();
		$this->register_style_content_controls();
		$this->register_style_title_controls();
		$this->register_style_description_controls();
		$this->register_style_caption_controls();
		$this->register_style_primary_btn_controls();
		$this->register_style_secondary_btn_controls();
		$this->register_style_navigation_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'ec_slider_section',
			[
				'label' => esc_html__( 'Slider', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'images',
			[
				'label'   => esc_html__( 'Image', 'companion-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'before_title',
			[
				'label' => esc_html__( 'Before Title', 'companion-elementor' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'   => esc_html__( 'Title', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Add Your Title Here​', 'companion-elementor' ),
				'rows'    => 2,
			]
		);

		$repeater->add_control(
			'after_title',
			[
				'label' => esc_html__( 'After Title', 'companion-elementor' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'description',
			[
				'label'   => esc_html__( 'Description', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'companion-elementor' ),
			]
		);

		$repeater->add_control(
			'caption',
			[
				'label'   => esc_html__( 'Caption', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Add Your Caption Text Here​', 'companion-elementor' ),
				'rows'    => 2,
			]
		);

		$repeater->add_control(
			'primary_button',
			[
				'label'   => esc_html__( 'Primary Button', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Click Here', 'companion-elementor' ),
			]
		);

		$repeater->add_control(
			'primary_button_link',
			[
				'label'         => esc_html__( 'Primary Button Link', 'companion-elementor' ),
				'type'          => Controls_Manager::URL,
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$repeater->add_control(
			'secondary_button',
			[
				'label'   => esc_html__( 'Secondary Button', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			]
		);

		$repeater->add_control(
			'secondary_button_link',
			[
				'label'         => esc_html__( 'Secondary Button Link', 'companion-elementor' ),
				'type'          => Controls_Manager::URL,
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'slider_list',
			[
				'label'       => esc_html__( 'Slides', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						/* Translators: %s number. */
						'title'                 => sprintf( esc_html__( 'Slide %s', 'companion-elementor' ), 1 ),
						'primary_button'        => esc_html__( 'Click Here', 'companion-elementor' ),
						'secondary_button'      => esc_html__( 'Read More', 'companion-elementor' ),
						'primary_button_link'   => [
							'url'         => '#',
							'is_external' => false,
							'nofollow'    => false,
						],
						'secondary_button_link' => [
							'url'         => '#',
							'is_external' => false,
							'nofollow'    => false,
						],
					],
					[
						/* Translators: %s number. */
						'title'                 => sprintf( esc_html__( 'Slide %s', 'companion-elementor' ), 2 ),
						'primary_button'        => esc_html__( 'Click Here', 'companion-elementor' ),
						'secondary_button'      => esc_html__( 'Read More', 'companion-elementor' ),
						'primary_button_link'   => [
							'url'         => '#',
							'is_external' => false,
							'nofollow'    => false,
						],
						'secondary_button_link' => [
							'url'         => '#',
							'is_external' => false,
							'nofollow'    => false,
						],
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();
	}

	private function register_settings_controls() {
		$this->start_controls_section(
			'ec_slider_settings_section',
			[
				'label' => esc_html__( 'Settings', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'   => esc_html__( 'Autoplay', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'yes',
				'options' => [
					'yes' => esc_html__( 'Yes', 'companion-elementor' ),
					'no'  => esc_html__( 'No', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'delay',
			[
				'label'     => esc_html__( 'Delay', 'companion-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 9999999999,
				'step'      => 1,
				'default'   => 4000,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'loop',
			[
				'label'        => esc_html__( 'Loop', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'effect',
			[
				'label'   => esc_html__( 'Effect', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'slide',
				'options' => [
					'slide'     => esc_html__( 'Slide', 'companion-elementor' ),
					'fade'      => esc_html__( 'Fade', 'companion-elementor' ),
					'cube'      => esc_html__( 'Cube', 'companion-elementor' ),
					'coverflow' => esc_html__( 'Coverflow', 'companion-elementor' ),
					'flip'      => esc_html__( 'Flip', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label'   => esc_html__( 'Speed', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 9999999999,
				'step'    => 1,
				'default' => 500,
			]
		);

		$this->add_control(
			'navigation',
			[
				'label'   => esc_html__( 'Navigation', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'both',
				'options' => [
					'both'   => esc_html__( 'Arrows &amp; Dots', 'companion-elementor' ),
					'arrows' => esc_html__( 'Arrows', 'companion-elementor' ),
					'dots'   => esc_html__( 'Dots', 'companion-elementor' ),
					'none'   => esc_html__( 'None', 'companion-elementor' ),
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_slider_controls() {
		$this->start_controls_section(
			'ec_slider_style_section',
			[
				'label' => esc_html__( 'Slider', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'slider_image',
				'default' => 'full',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'           => 'slider_overlay',
				'label'          => esc_html__( 'Overlay', 'companion-elementor' ),
				'types'          => [
					'classic',
					'gradient',
				],
				'selector'       => '{{WRAPPER}} .swiper-slide .overlay',
				'fields_options' => [
					'color' => [
						'default' => 'rgba(0, 0, 0, 0.3)',
					],
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_content_controls() {
		$this->start_controls_section(
			'ec_slider_style_content_section',
			[
				'label' => esc_html__( 'Content', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_alignment',
			[
				'label'        => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'      => 'center',
				'prefix_class' => 'ec-slider--',
			]
		);

		$this->add_control(
			'content_text_alignment',
			[
				'label'        => esc_html__( 'Text Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'      => 'center',
				'prefix_class' => 'ec-slider-text--',
			]
		);

		$this->add_responsive_control(
			'show_desc',
			[
				'label'           => esc_html__( 'Show Description', 'companion-elementor' ),
				'type'            => Controls_Manager::SELECT,
				'options'         => [
					'none'  => esc_html__( 'No', 'companion-elementor' ),
					'block' => esc_html__( 'Yes', 'companion-elementor' ),
				],
				'desktop_default' => 'block',
				'tablet_default'  => 'block',
				'mobile_default'  => 'none',
				'selectors'       => [
					'{{WRAPPER}} .ec-description' => 'display: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'show_caption',
			[
				'label'           => esc_html__( 'Show Caption', 'companion-elementor' ),
				'type'            => Controls_Manager::SELECT,
				'options'         => [
					'none'  => esc_html__( 'No', 'companion-elementor' ),
					'block' => esc_html__( 'Yes', 'companion-elementor' ),
				],
				'desktop_default' => 'block',
				'tablet_default'  => 'block',
				'mobile_default'  => 'none',
				'selectors'       => [
					'{{WRAPPER}} .ec-caption' => 'display: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_horizontal_position',
			[
				'label'      => esc_html__( 'Horizontal Position', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'%',
				],
				'range'      => [
					'%' => [
						'min' => -20,
						'max' => 80,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => '',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'content_vertical_position',
			[
				'label'      => esc_html__( 'Vertical Position', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'%',
				],
				'range'      => [
					'%' => [
						'min' => -20,
						'max' => 80,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => '',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_width',
			[
				'label'           => esc_html__( 'Width', 'companion-elementor' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => [
					'px',
					'em',
					'rem',
					'%',
				],
				'range'           => [
					'%'   => [
						'min' => 1,
						'max' => 100,
					],
					'em'  => [
						'min' => 0,
						'max' => 100,
					],
					'rem' => [
						'min' => 0,
						'max' => 100,
					],
					'px'  => [
						'min' => 0,
						'max' => 1920,
					],
				],
				'desktop_default' => [
					'unit' => '%',
					'size' => 60,
				],
				'tablet_default'  => [
					'unit' => '%',
					'size' => 70,
				],
				'mobile_default'  => [
					'unit' => '%',
					'size' => 80,
				],
				'selectors'       => [
					'{{WRAPPER}} .ec-slide-content' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'content_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-slide-content',
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'content_border',
				'selector' => '{{WRAPPER}} .ec-slide-content',
			]
		);

		$this->add_responsive_control(
			'content_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'content_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-slide-content',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_title_controls() {
		$this->start_controls_section(
			'ec_slider_style_title_section',
			[
				'label' => esc_html__( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'before_title_heading',
			[
				'label'     => esc_html__( 'Before Title', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'titles_stacked',
			[
				'label'        => esc_html__( 'Stacked', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'prefix_class' => 'ec-title-stacked--',
			]
		);

		$this->add_control(
			'before_title_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .ec-heading .before-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'before_title_typography',
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-heading .before-title',
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label'     => esc_html__( 'Title', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'   => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h3',
				'options' => [
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .ec-heading' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-heading',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'title_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-heading',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'title_border',
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-heading',
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .ec-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .ec-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'after_title_heading',
			[
				'label'     => esc_html__( 'After Title', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'after_title_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .ec-heading .after-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'after_title_typography',
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-heading .after-title',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_description_controls() {
		$this->start_controls_section(
			'ec_slider_style_description_section',
			[
				'label' => esc_html__( 'Description', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'description_tag',
			[
				'label'   => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'div',
				'options' => [
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .ec-description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-description',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'description_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-description',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'description_border',
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-description',
			]
		);

		$this->add_responsive_control(
			'description_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .ec-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'description_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .ec-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_caption_controls() {
		$this->start_controls_section(
			'ec_slider_style_caption_section',
			[
				'label' => esc_html__( 'Caption', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'caption_heading',
			[
				'label'     => esc_html__( 'Caption', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'caption_tag',
			[
				'label'   => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'span',
				'options' => [
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'caption_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .ec-caption' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'caption_typography',
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-caption',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'caption_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-caption',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'caption_border',
				'selector' => '{{WRAPPER}} .ec-slide-content .ec-caption',
			]
		);

		$this->add_responsive_control(
			'caption_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .ec-caption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'caption_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .ec-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_primary_btn_controls() {
		$this->start_controls_section(
			'ec_slider_primary_button_style_section',
			[
				'label' => esc_html__( 'Primary Button', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'primary_button_typography',
				'selector' => '{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary',
			]
		);

		$this->add_responsive_control(
			'primary_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'primary_button_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'primary_button_border',
				'selector' => '{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary',
			]
		);

		$this->add_responsive_control(
			'primary_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'primary_button_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary',
			]
		);

		$this->start_controls_tabs(
			'primary_button_tabs'
		);

		$this->start_controls_tab(
			'primary_button_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'primary_button_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'primary_button_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'primary_button_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'primary_button_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'primary_button_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary:hover',
			]
		);

		$this->add_control(
			'primary_button_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-primary:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_secondary_btn_controls() {
		$this->start_controls_section(
			'ec_slider_secondary_button_style_section',
			[
				'label' => esc_html__( 'Secondary Button', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'secondary_button_typography',
				'selector' => '{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary',
			]
		);

		$this->add_responsive_control(
			'secondary_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_button_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'           => 'secondary_button_border',
				'fields_options' => [
					'border' => [
						'default' => 'solid',
					],
					'width'  => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => true,
						],
					],
					'color'  => [
						'default' => '#ffffff',
					],
				],
				'selector'       => '{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary',
			]
		);

		$this->add_responsive_control(
			'secondary_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'secondary_button_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary',
			]
		);

		$this->start_controls_tabs(
			'secondary_button_tabs'
		);

		$this->start_controls_tab(
			'secondary_button_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'secondary_button_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'secondary_button_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'secondary_button_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'secondary_button_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'secondary_button_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary:hover',
			]
		);

		$this->add_control(
			'secondary_button_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-slide-content .cta .ec-btn-secondary:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_navigation_controls() {
		$this->start_controls_section(
			'ec_slider_navigation_style_section',
			[
				'label' => esc_html__( 'Navigation', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'arrows_heading',
			[
				'label'     => esc_html__( 'Arrows', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'arrow_left_icon',
			[
				'label'   => esc_html__( 'Left Icon', 'companion-elementor' ),
				'type'    => Controls_Manager::ICON,
				'default' => 'fa fa-chevron-left',
			]
		);

		$this->add_control(
			'arrow_right_icon',
			[
				'label'   => esc_html__( 'Right Icon', 'companion-elementor' ),
				'type'    => Controls_Manager::ICON,
				'default' => 'fa fa-chevron-right',
			]
		);

		$this->add_responsive_control(
			'arrow_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'em',
					'size' => 2.4,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-nav .ec-nav-next' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'arrow_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-nav .ec-nav-next i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'arrow_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'arrow_border',
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			]
		);

		$this->add_control(
			'arrow_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'arrow_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-nav .ec-nav-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'arrow_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			]
		);

		$this->start_controls_tabs(
			'arrow_tabs'
		);

		$this->start_controls_tab(
			'arrow_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'arrow_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-nav .ec-nav-next i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'arrow_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'arrow_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'arrow_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-nav .ec-nav-next:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev:hover i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'arrow_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next:hover, {{WRAPPER}} .ec-nav .ec-nav-prev:hover',
			]
		);

		$this->add_control(
			'arrow_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-nav .ec-nav-next:hover' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'dots_heading',
			[
				'label'     => esc_html__( 'Dots', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'dot_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'dot_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 18,
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/slider-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings          = $this->get_settings_for_display();
		$slider_list       = $settings['slider_list'];
		$slider_image_size = $settings['slider_image_size'];
		$title_tag         = $settings['title_tag'];
		$description_tag   = $settings['description_tag'];
		$caption_tag       = $settings['caption_tag'];
		$arrow_left_icon   = ! empty( $settings['arrow_left_icon'] ) ? $settings['arrow_left_icon'] : 'fa fa-chevron-left';
		$arrow_right_icon  = ! empty( $settings['arrow_right_icon'] ) ? $settings['arrow_right_icon'] : 'fa fa-chevron-right';

		// Settings.
		$options             = array();
		$options['autoplay'] = $settings['autoplay'];
		$options['delay']    = $settings['delay'];
		$options['loop']     = $settings['loop'];
		$options['effect']   = $settings['effect'];
		$options['speed']    = $settings['speed'];

		$options['arrows'] = in_array(
			$settings['navigation'],
			array(
				'arrows',
				'both',
			),
			true
		);

		$options['dots'] = in_array(
			$settings['navigation'],
			array(
				'dots',
				'both',
			),
			true
		);

		$swiper_class = Plugin::$instance->experiments->is_feature_active( 'e_swiper_latest' ) ? 'swiper' : 'swiper-container';
		?>

		<div class="ec-slider-wrapper">
			<div class="ec-slider swiper-container <?php echo esc_attr( $swiper_class ); ?>"
				data-slider_options=<?php echo wp_json_encode( $options ); ?>>

				<?php if ( ! empty( $slider_list ) ) : ?>

					<div class="swiper-wrapper">
					<?php foreach ( $slider_list as $slide ) : ?>
						<div class="swiper-slide">
						<div class="overlay"></div>

						<?php if ( $slide['images']['url'] ) : ?>
							<?php
							$image_id   = $slide['images']['id'];
							$image_size = $slider_image_size;

							if ( 'custom' === $image_size ) {
								$image_src = Group_Control_Image_Size::get_attachment_image_src( $image_id, 'slider_image', (array) $settings );
							} else {
								$image_src = wp_get_attachment_image_src( $image_id, $image_size );
								$image_src = isset( $image_src[0] ) ? $image_src[0] : '';
							}

							if ( ! $image_id ) {
								$image_src = $slide['images']['url'];
							}
							?>

							<?php if ( $image_src ) : ?>
								<img src="<?php echo esc_url( $image_src ); ?>" alt="<?php echo esc_attr( $slide['title'] ); ?>" >
							<?php endif; ?>
						<?php endif; ?>

						<div class="ec-slide-content">
						<!-- Caption -->
						<?php if ( $slide['caption'] ) : ?>
						<<?php echo esc_attr( $caption_tag ); ?> class="ec-caption">
							<?php echo $slide['caption']; ?>
						</<?php echo esc_attr( $caption_tag ); ?>> <!-- /.ec-caption -->
					<?php endif; ?>

						<!-- Heading -->
						<?php if ( $slide['title'] ) : ?>
							<<?php echo esc_attr( $title_tag ); ?> class="ec-heading">

							<?php if ( $slide['before_title'] ) : ?>
								<span class="before-title"><?php echo esc_html( $slide['before_title'] ); ?></span>
							<?php endif; ?>

							<?php echo esc_html( $slide['title'] ); ?>

							<?php if ( $slide['after_title'] ) : ?>
								<span class="after-title"><?php echo esc_html( $slide['after_title'] ); ?></span>
							<?php endif; ?>

							</<?php echo esc_attr( $title_tag ); ?>> <!-- /.ec-heading -->
						<?php endif; ?>

						<!-- Content -->
						<?php if ( $slide['description'] ) : ?>
							<<?php echo esc_attr( $description_tag ); ?> class="ec-description">
							<?php echo $slide['description']; ?>
							</<?php echo esc_attr( $description_tag ); ?>> <!-- /.ec-description -->
						<?php endif; ?>

						<!-- CTA -->
						<div class="cta">
							<?php if ( $slide['primary_button'] && $slide['primary_button_link']['url'] ) : ?>
								<a class="ec-btn ec-btn-primary" href="<?php echo esc_url( $slide['primary_button_link']['url'] ); ?>"
									<?php echo( ! empty( $slide['primary_button_link']['is_external'] ) ? 'target="_blank"' : '' ); ?>
									<?php
									echo( ! empty( $slide['primary_button_link']['nofollow'] ) ?
										'rel="nofollow"' : '' );
									?>
										>
									<?php echo esc_html( $slide['primary_button'] ); ?>
								</a>
							<?php endif; ?>

							<?php if ( $slide['secondary_button'] && $slide['secondary_button_link']['url'] ) : ?>
								<a class="ec-btn ec-btn-secondary" href="<?php echo esc_url( $slide['secondary_button_link']['url'] ); ?>"
									<?php
									echo( ! empty( $slide['secondary_button_link']['is_external'] ) ?
										'target="_blank"' : '' );
									?>
									<?php
									echo( ! empty( $slide['secondary_button_link']['nofollow'] ) ?
										'rel="nofollow"' : '' );
									?>
										>
									<?php echo esc_html( $slide['secondary_button'] ); ?>
								</a>
							<?php endif; ?>
						</div><!-- /.cta -->
						</div> <!-- /.ec-slide-content -->
						</div> <!-- /.swiper-slide -->

					<?php endforeach; ?>
					</div> <!-- /.swiper-wrapper -->

					<!-- Pagination -->
					<?php if ( 'both' === $settings['navigation'] || 'dots' === $settings['navigation'] ) : ?>
						<div class="ec-pagination"></div>
					<?php endif; ?>

					<!-- Navigation -->
					<?php if ( 'both' === $settings['navigation'] || 'arrows' === $settings['navigation'] ) : ?>
						<div class="ec-nav">
							<span class="ec-nav-prev"><i class="fa <?php echo esc_attr( $arrow_left_icon ); ?>"></i></span>
							<span class="ec-nav-next"><i class="fa <?php echo esc_attr( $arrow_right_icon ); ?>"></i></span>
						</div> <!-- /.ec-nav -->
					<?php endif; ?>

				<?php endif; ?>

				</div> <!-- /.ec-slider -->
		</div> <!-- /.ec-slider-wrapper -->
		<?php
	}
}
