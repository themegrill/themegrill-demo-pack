<?php

namespace CompanionElementor\Modules\Modal\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Plugin;
use CompanionElementor\Classes\Utils as CompanionElementorUtils;
use Elementor\Utils;
use Elementor\Icons_Manager;

defined( 'ABSPATH' ) || exit;

class Modal extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-modal';
	}

	public function get_title() {
		return __( 'Modal', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-play';
	}

	public function get_script_depends() {
		return array(
			'magnific-popup',
		);
	}

	public function get_style_depends() {
		return array(
			'magnific-popup',
		);
	}

	public function get_keywords() {
		return [ 'companion', 'modal', 'video', 'youtube', 'vimeo' ];
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_popup_controls();
		$this->register_style_popup_controls();
		$this->register_style_icon_controls();
		$this->register_style_btn_controls();
		$this->register_style_text_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'ec_modal_content_section',
			[
				'label' => esc_html__( 'Popup Content', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'content_type',
			[
				'label'   => esc_html__( 'Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'content',
				'options' => [
					'content'  => esc_html__( 'Content', 'companion-elementor' ),
					'template' => esc_html__( 'Template', 'companion-elementor' ),
					'video'    => esc_html__( 'Video Embed Code', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'content',
			[
				'label'     => esc_html__( 'Content', 'companion-elementor' ),
				'type'      => Controls_Manager::WYSIWYG,
				'default'   => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'companion-elementor' ),
				'condition' => [
					'content_type' => 'content',
				],
			]
		);

		$this->add_control(
			'template',
			[
				'label'     => esc_html__( 'Template', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '0',
				'options'   => CompanionElementorUtils::get_templates(),
				'condition' => [
					'content_type' => 'template',
				],
			]
		);

		$this->add_control(
			'video_embed',
			[
				'label'       => esc_html__( 'Video Embed Code', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'condition'   => [
					'content_type' => [ 'video' ],
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_popup_controls() {
		$this->start_controls_section(
			'ec_modal_src_section',
			[
				'label' => esc_html__( 'Modal Source', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control(
			'src_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => 'left',
				'selectors' => [
					'{{WRAPPER}} .ec-modal' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'src_type',
			[
				'label'   => esc_html__( 'Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'button',
				'options' => [
					'icon'   => esc_html__( 'Icon', 'companion-elementor' ),
					'text'   => esc_html__( 'Text', 'companion-elementor' ),
					'button' => esc_html__( 'Button', 'companion-elementor' ),
					'image'  => esc_html__( 'Image', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'src_icon_v5',
			[
				'label'            => esc_html__( 'Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'src_icon',
				'default'          => [
					'value'   => 'fa fa-play-circle-o',
					'library' => 'solid',
				],
				'condition'        => [
					'src_type' => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'src_icon_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 31.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 31.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 64,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-modal-src .fa' => 'font-size: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'src_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'src_btn_text',
			[
				'label'     => esc_html__( 'Button Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Click Me', 'companion-elementor' ),
				'condition' => [
					'src_type' => 'button',
				],
			]
		);

		$this->add_control(
			'src_btn_icon_v5',
			[
				'label'            => esc_html__( 'Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'src_btn_icon',
				'default'          => [
					'value'   => '',
					'library' => 'solid',
				],
				'condition'        => [
					'src_type' => 'button',
				],
				'render_type'      => 'template',
			]
		);

		$this->add_control(
			'src_btn_icon_pos',
			[
				'label'     => esc_html__( 'Icon Position', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'before',
				'options'   => [
					'before' => esc_html__( 'Before', 'companion-elementor' ),
					'after'  => esc_html__( 'After', 'companion-elementor' ),
				],
				'condition' => [
					'src_type'      => 'button',
					'src_btn_icon!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'src_btn_icon_spacing',
			[
				'label'      => esc_html__( 'Icon Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-modal-src.button .icon-position-before .fa' => 'margin-right: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .ec-modal-src.button .icon-position-after .fa'  => 'margin-left: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'src_type'      => 'button',
					'src_btn_icon!' => '',
				],
			]
		);

		$this->add_control(
			'src_text',
			[
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Click Me', 'companion-elementor' ),
				'condition' => [
					'src_type' => 'text',
				],
			]
		);

		$this->add_control(
			'src_img',
			[
				'label'     => esc_html__( 'Image', 'companion-elementor' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'src_type' => 'image',
				],
			]
		);

		$this->add_control(
			'img_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'%',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-modal-src img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'src_type' => 'image',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_popup_controls() {
		$this->start_controls_section(
			'ec_modal_style_section',
			[
				'label' => esc_html__( 'Popup Content', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'width',
			[
				'label'      => esc_html__( 'Width', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 1400,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 187.5,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 187.5,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 800,
				],
				'selectors'  => [
					'.ec-modal-popup-message-{{ID}} .ec-modal-popup-box' => 'max-width: {{SIZE}}{{UNIT}}',
				],
				'separator'  => 'after',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'content_typography',
				'selector'  => '.ec-modal-popup-message-{{ID}} .ec-modal-popup-box.content',
				'condition' => [
					'content_type' => 'content',
				],
			]
		);

		$this->add_control(
			'content_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'.ec-modal-popup-message-{{ID}} .ec-modal-popup-box.content' => 'color: {{VALUE}}',
				],
				'condition' => [
					'content_type' => 'content',
				],
			]
		);

		$this->add_control(
			'content_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'.ec-modal-popup-message-{{ID}} .ec-modal-popup-box.content' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'src_type' => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'.ec-modal-popup-message-{{ID}} .ec-modal-popup-box.content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'content_popup_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '.ec-modal-popup-message-box.mfp-bg',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_icon_controls() {
		$this->start_controls_section(
			'ec_modal_icon_style_section',
			[
				'label'     => esc_html__( 'Icon', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'src_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'src_icon_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-modal .ec-modal-src' => 'color: {{VALUE}}',
				],
				'condition' => [
					'src_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'src_icon_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-modal .ec-modal-src:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'src_type' => 'icon',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_btn_controls() {
		$this->start_controls_section(
			'ec_modal_btn_style_section',
			[
				'label'     => esc_html__( 'Button', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'src_type' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'src_btn_typography',
				'selector' => '{{WRAPPER}} .ec-modal .ec-modal-src.button',
			]
		);

		$this->add_responsive_control(
			'src_btn_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-modal .ec-modal-src.button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'src_btn_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-modal .ec-modal-src.button',
			]
		);

		$this->add_responsive_control(
			'src_btn_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-modal .ec-modal-src.button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'src_btn_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-modal .ec-modal-src.button',
			]
		);

		$this->start_controls_tabs(
			'src_btn_tabs'
		);

		$this->start_controls_tab(
			'src_btn_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'src_btn_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-modal .ec-modal-src.button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'src_btn_normal_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-modal .ec-modal-src.button',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'src_btn_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'src_btn_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-modal .ec-modal-src.button:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'src_btn_hover_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-modal .ec-modal-src.button:hover',
			]
		);

		$this->add_control(
			'src_btn_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-modal .ec-modal-src.button:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_text_controls() {
		$this->start_controls_section(
			'ec_modal_text_style_section',
			[
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'src_type' => 'text',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'src_text_typography',
				'selector' => '{{WRAPPER}} .ec-modal .ec-modal-src.text',
			]
		);

		$this->add_responsive_control(
			'src_text_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-modal .ec-modal-src.text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'src_text_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-modal .ec-modal-src.text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'src_text_tabs'
		);

		$this->start_controls_tab(
			'src_text_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'src_text_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-modal .ec-modal-src.text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'src_text_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'src_text_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-modal .ec-modal-src.text:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/modal-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings         = $this->get_settings_for_display();
		$content_type     = $settings['content_type'];
		$content          = $settings['content'];
		$template         = $settings['template'];
		$src_type         = $settings['src_type'];
		$src_icon         = ! empty( $settings['src_icon_v5'] ) ? $settings['src_icon_v5'] : 'fa fa-play-circle-o';
		$src_btn_text     = $settings['src_btn_text'];
		$src_btn_icon     = $settings['src_btn_icon_v5'];
		$src_btn_icon_pos = $settings['src_btn_icon_pos'];
		$src_text         = $settings['src_text'];
		$src_img          = $settings['src_img'];

		// General options.
		$src_class = ( 'template' === $content_type ) ? 'template' : 'content';

		// Modal options.
		$options            = array();
		$options['modalID'] = $this->get_id();
		?>

		<div class="ec-modal-wrapper">
			<div class="ec-modal">

				<div class="ec-modal-src <?php echo esc_attr( $src_type ); ?>"
					data-mfp-src="#ec-modal-popup-box-<?php echo esc_attr( $this->get_id() ); ?>" >

					<?php if ( 'icon' === $src_type && $src_icon ) : ?>
						<?php
						$migrated = isset( $settings['__fa4_migrated']['src_icon_v5'] );
						$is_new   = ! array_key_exists( 'src_icon', $settings );
						if ( $is_new || $migrated ) :
							Icons_Manager::render_icon( $settings['src_icon_v5'], [ 'aria-hidden' => 'true' ] );
						else :
							?>
							<i class="<?php echo ( is_array( $settings['src_icon'] ) ? $settings['src_icon']['value'] : $settings['src_icon'] ); ?>" aria-hidden="true"></i>
						<?php endif; ?>

					<?php elseif ( 'button' === $src_type && $src_btn_text ) : ?>

						<?php echo esc_html( $src_btn_text ); ?>

						<?php if ( $src_btn_icon || ( ! empty( $settings['src_btn_icon'] ) ) ) : ?>
							<span class="icon-position-<?php echo esc_attr( $src_btn_icon_pos ); ?>">
									<?php
									$migrated = isset( $settings['__fa4_migrated']['src_btn_icon_v5'] );
									$is_new   = ! array_key_exists( 'src_btn_icon', $settings );

									if ( $is_new || $migrated ) :
										Icons_Manager::render_icon( $src_btn_icon, [ 'aria-hidden' => 'true' ] );
									else :
										?>
										<i class="<?php echo ( is_array( $settings['src_btn_icon'] ) ? $settings['src_btn_icon']['value'] : $settings['src_btn_icon'] ); ?>" aria-hidden="true"></i>
									<?php endif; ?>
								</span>
						<?php endif; ?>

					<?php elseif ( 'text' === $src_type && $src_text ) : ?>
						<?php echo esc_html( $src_text ); ?>

					<?php elseif ( 'image' === $src_type && $src_img ) : ?>

						<?php
						$image_id  = $src_img['id'];
						$image_src = wp_get_attachment_image_src( $image_id, 'full' );
						$image_src = ! empty( $image_src ) ? $image_src[0] : '';

						if ( ! $image_id ) {
							$image_src = $src_img['url'];
						}
						?>
						<img src="<?php echo esc_url( $image_src ); ?>" />

					<?php endif; ?>

				</div> <!-- /.ec-modal-src -->

				<div id="ec-modal-popup-box-<?php echo esc_attr( $this->get_id() ); ?>"
					class="ec-modal-popup-box mfp-hide <?php echo esc_attr( $src_class ); ?>"
					data-modal_settings=<?php echo wp_json_encode( $options ); ?> >
					<div class="ec-modal-content">
						<?php
						if ( 'content' === $content_type ) :

							echo $this->parse_text_editor( $content ); // phpcs:ignore WordPress.Security.EscapeOutput

						elseif ( 'template' === $content_type ) :

							if ( '0' !== $template && ! empty( $template ) ) :
								echo Plugin::instance()->frontend->get_builder_content_for_display( $template ); // phpcs:ignore WordPress.Security.EscapeOutput
							endif;

						elseif ( ( 'video' === $content_type ) ) :
							global $wp_embed;
							echo $wp_embed->autoembed( $settings['video_embed'] );
						endif;
						?>
					</div>
				</div> <!-- /.ec-modal-popup-box- -->

			</div> <!-- /.ec-modal -->
		</div> <!-- /.ec-modal-wrapper -->

		<?php
	}
}
