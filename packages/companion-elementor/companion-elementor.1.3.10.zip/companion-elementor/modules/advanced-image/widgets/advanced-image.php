<?php

namespace CompanionElementor\Modules\AdvancedImage\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

defined( 'ABSPATH' ) || exit;

class Advanced_Image extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-advanced-image';
	}

	public function get_title() {
		return __( 'Advanced Image', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-image';
	}

	public function get_keywords() {
		return [ 'companion', 'image', 'banner', 'hover' ];
	}

	protected function register_controls() {

		$this->register_general_controls();
		$this->register_cta_controls();
		$this->register_style_general_controls();
		$this->register_style_cta_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'section_general',
			[
				'label' => __( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => __( 'Image', 'companion-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_cta_controls() {
		$this->start_controls_section(
			'ec_service_box_cta_section',
			[
				'label' => esc_html__( 'Call To Action', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'cta_type',
			[
				'label'   => esc_html__( 'Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'none'   => esc_html__( 'None', 'companion-elementor' ),
					'text'   => esc_html__( 'Text', 'companion-elementor' ),
					'button' => esc_html__( 'Button', 'companion-elementor' ),
					'box'    => esc_html__( 'Box', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'cta_text',
			[
				'label'       => esc_html__( 'Text', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Read More', 'companion-elementor' ),
				'label_block' => true,
				'condition'   => [
					'cta_type' => [ 'text', 'button' ],
				],
			]
		);

		$this->add_control(
			'cta_icon',
			[
				'label'     => esc_html__( 'Icon', 'companion-elementor' ),
				'type'      => Controls_Manager::ICON,
				'default'   => 'fa fa-plus',
				'condition' => [
					'cta_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'cta_link',
			[
				'label'       => esc_html__( 'Link', 'companion-elementor' ),
				'type'        => Controls_Manager::URL,
				'default'     => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
				'placeholder' => esc_html__( 'https://your-link.com', 'companion-elementor' ),
				'condition'   => [
					'cta_type!' => 'none',
				],
			]
		);

		$this->add_control(
			'cta_link_to',
			[
				'label'     => esc_html__( 'Link To', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT2,
				'multiple'  => true,
				'options'   => [
					'title' => esc_html__( 'Title', 'companion-elementor' ),
					'icon'  => esc_html__( 'Icon', 'companion-elementor' ),
				],
				'default'   => [ 'title' ],
				'condition' => [
					'cta_type' => 'element',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_general_controls() {
		$this->start_controls_section(
			'section_style_general',
			[
				'label' => __( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_alignment',
			[
				'label'           => __( 'Content Alignment', 'companion-elementor' ),
				'type'            => Controls_Manager::CHOOSE,
				'desktop_default' => 'center',
				'tablet_default'  => 'center',
				'mobile_default'  => 'center',
				'options'         => [
					'flex-start' => [
						'title' => __( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'     => [
						'title' => __( 'Center', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'   => [
						'title' => __( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors'       => [
					'{{WRAPPER}} .ec-content' => 'align-items: {{VALUE}};',
				],
				'label_block'     => true,
			]
		);

		$this->add_responsive_control(
			'border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-advanced-image-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'overlay',
			[
				'label'        => esc_html__( 'Overlay', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'overlay_color',
			[
				'label'     => esc_html__( 'Overlay Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-overlay' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'overlay' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'image_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'%',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_cta_controls() {
		$this->start_controls_section(
			'section_style_cta',
			[
				'label'     => __( 'Call To Action', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'cta_type' => [ 'text', 'button' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'cta_typography',
				'selector'  => '{{WRAPPER}} .ec-cta',
				'condition' => [
					'cta_type' => [ 'text', 'button' ],
				],
			]
		);

		$this->add_responsive_control(
			'cta_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-cta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => [ 'button' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'cta_border',
				'selector'  => '{{WRAPPER}} .ec-cta',
				'condition' => [
					'cta_type' => [ 'button' ],
				],
			]
		);

		$this->add_responsive_control(
			'cta_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-cta' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => [ 'button' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'cta_box_shadow',
				'label'     => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector'  => '{{WRAPPER}} .ec-cta',
				'condition' => [
					'cta_type' => [ 'button' ],
				],
			]
		);

		$this->start_controls_tabs(
			'cta_tabs'
		);

		$this->start_controls_tab(
			'cta_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_color',
			array_merge(
				[
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#FFFFFF',
					'selectors' => [
						'{{WRAPPER}} .ec-cta' => 'color: {{VALUE}}',
					],
					'condition' => [
						'cta_type' => [ 'text', 'button' ],
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_4,
					],
				] : [
					'global' => [
						'default' => '',
					],
				]
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array_merge(
				[
					'name'      => 'cta_bg',
					'label'     => esc_html__( 'Background', 'companion-elementor' ),
					'types'     => [
						'classic',
						'gradient',
					],
					'selector'  => '{{WRAPPER}} .ec-cta-btn',
					'condition' => [
						'cta_type' => [ 'button' ],
					],
				],
				class_exists( Color::class ) ? [
					'fields_options' => [
						'color' => [
							'scheme' => [
								'type'  => Color::get_type(),
								'value' => Color::COLOR_4,
							],
						],
					],
				] : [
					'fields_options' => [
						'color' => [
							'global' => [
								'default' => Global_Colors::COLOR_ACCENT,
							],
						],
					],
				]
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cta_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-cta:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'cta_type' => [ 'text', 'button' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array_merge(
				[
					'name'      => 'cta_hover_bg',
					'label'     => esc_html__( 'Background', 'companion-elementor' ),
					'types'     => [
						'classic',
						'gradient',
					],
					'selector'  => '{{WRAPPER}} .ec-cta-btn:hover',
					'condition' => [
						'cta_type' => [ 'button' ],
					],
				],
				class_exists( Color::class ) ? [
					'fields_options' => [
						'color' => [
							'scheme' => [
								'type'  => Color::get_type(),
								'value' => Color::COLOR_4,
							],
						],
					],
				] : [
					'fields_options' => [
						'color' => [
							'global' => [
								'default' => Global_Colors::COLOR_ACCENT,
							],
						],
					],
				]
			)
		);

		$this->add_control(
			'cta_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-cta-btn:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'cta_type' => [ 'button' ],
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/advanced-image/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings    = $this->get_settings_for_display();
		$image       = $settings['image']['url'];
		$overlay     = $settings['overlay'];
		$cta_type    = $settings['cta_type'];
		$link        = $settings['cta_link'];
		$cta_text    = $settings['cta_text'];
		$show_cta    = ( 'text' === $cta_type ) || ( 'button' === $cta_type );
		$link_to_cta = isset( $link ) ? ( $link['url'] && $show_cta ) : '';
		$link_to_box = isset( $link ) ? ( $link['url'] && ( 'box' === $cta_type ) ) : '';
		?>

		<div class="ec-advanced-image-wrapper">

			<?php if ( $link_to_box ) : ?>
				<a class="ec-box-link"
					href="<?php echo esc_url( $link['url'] ); ?>" <?php echo $link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $link['nofollow'] ? 'rel="nofollow"' : ''; ?>></a>
			<?php endif; ?>

			<?php if ( $image ) : ?>
				<img class="ec-image" src="<?php echo esc_url( $image ); ?>">
			<?php endif; ?>

			<?php if ( $overlay ) : ?>
				<div class="ec-overlay"></div>
			<?php endif; ?>

			<div class="ec-content">

				<?php if ( $link_to_cta ) : ?>
					<a class="ec-cta <?php echo ( 'button' === $cta_type ) ? esc_attr( 'ec-cta-btn' ) : ''; ?>"
						href="<?php echo esc_url( $link['url'] ); ?>" <?php echo $link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $link['nofollow'] ? 'rel="nofollow"' : ''; ?>>
						<?php echo esc_html( $cta_text ); ?>
					</a>
				<?php endif; ?>
			</div>

		</div> <!-- /.ec-advanced-image-wrapper -->

		<?php
	}
}
