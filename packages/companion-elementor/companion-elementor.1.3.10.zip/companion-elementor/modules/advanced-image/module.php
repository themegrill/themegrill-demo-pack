<?php

namespace CompanionElementor\Modules\AdvancedImage;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Advanced_Image',
		];
	}

	public function get_name() {
		return 'advanced-image';
	}

}
