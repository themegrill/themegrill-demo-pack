<?php

namespace CompanionElementor\Modules\ServiceBox\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Icons_Manager;
use Elementor\Utils;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

defined( 'ABSPATH' ) || exit;

class Service_Box extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-service-box';
	}

	public function get_title() {
		return __( 'Service Box', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-info-box';
	}

	public function get_keywords() {
		return [ 'companion', 'service box', 'info box', 'icon box', 'image box' ];
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_separator_controls();
		$this->register_cta_controls();
		$this->register_style_general_controls();
		$this->register_style_service_box_hover_controls();
		$this->register_style_icon_controls();
		$this->register_style_caption_controls();
		$this->register_style_title_controls();
		$this->register_style_description_controls();
		$this->register_style_cta_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'ec_service_box_section',
			[
				'label' => esc_html__( 'Service Box', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'icon_type',
			[
				'label'   => esc_html__( 'Icon Type', 'companion-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'icon',
				'options' => [
					'icon'  => [
						'title' => esc_html__( 'Icon', 'companion-elementor' ),
						'icon'  => 'fa fa-info',
					],
					'image' => [
						'title' => esc_html__( 'Image', 'companion-elementor' ),
						'icon'  => 'fa fa-photo',
					],
				],
			]
		);

		$this->add_control(
			'icon_v5',
			[
				'label'            => esc_html__( 'Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => [
					'value'   => 'fa fa-heart',
					'library' => 'solid',
				],
				'condition'        => [
					'icon_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label'     => esc_html__( 'Image', 'companion-elementor' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'icon_type' => 'image',
				],
			]
		);

		$this->add_control(
			'caption',
			[
				'label'       => esc_html__( 'Caption', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Caption', 'companion-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'This is the title', 'companion-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'description',
			[
				'label'   => esc_html__( 'Description', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'companion-elementor' ),
				'rows'    => 10,
			]
		);

		$this->end_controls_section();
	}

	private function register_separator_controls() {
		$this->start_controls_section(
			'ec_service_box_separator_content_section',
			[
				'label' => esc_html__( 'Separator', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'after_caption_sep',
			[
				'label'        => esc_html__( 'After Caption', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$this->add_control(
			'after_title_sep',
			[
				'label'        => esc_html__( 'After Title', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$this->start_controls_tabs(
			'sep_tabs'
		);

		$this->start_controls_tab(
			'after_caption_sep_tab',
			[
				'label'     => esc_html__( 'After Caption', 'companion-elementor' ),
				'condition' => [
					'after_caption_sep' => 'yes',
				],
			]
		);

		$this->add_control(
			'after_caption_sep_style',
			[
				'label'     => esc_html__( 'Style', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'solid'  => esc_html__( 'Solid', 'companion-elementor' ),
					'dashed' => esc_html__( 'Dashed', 'companion-elementor' ),
					'dotted' => esc_html__( 'Dotted', 'companion-elementor' ),
					'double' => esc_html__( 'Double', 'companion-elementor' ),
				],
				'selectors' => [
					'{{WRAPPER}} .ec-sep-cap .ec-sep-inner' => 'border-top-style: {{VALUE}};',
				],
				'condition' => [
					'after_caption_sep' => 'yes',
				],
			]
		);

		$this->add_control(
			'after_caption_sep_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-sep-cap .ec-sep-inner' => 'border-top-color: {{VALUE}}',
				],
				'condition' => [
					'after_caption_sep' => 'yes',
				],
			]
		);

		$this->add_control(
			'after_caption_sep_weight',
			[
				'label'      => esc_html__( 'Weight', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'default'    => [
					'size' => 3,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-sep-cap .ec-sep-inner' => 'border-top-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'after_caption_sep' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'after_caption_sep_width',
			[
				'label'       => esc_html__( 'Width', 'companion-elementor' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ '%', 'px' ],
				'range'       => [
					'px' => [
						'max' => 1000,
					],
				],
				'default'     => [
					'size' => 30,
					'unit' => 'px',
				],
				'label_block' => true,
				'selectors'   => [
					'{{WRAPPER}} .ec-sep-cap .ec-sep-inner' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'after_caption_sep' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'after_caption_sep_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .ec-sep-cap .ec-sep-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'after_caption_sep' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'after_caption_sep_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .ec-sep-cap .ec-sep-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'after_caption_sep' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'after_title_sep_tab',
			[
				'label'     => esc_html__( 'After Title', 'companion-elementor' ),
				'condition' => [
					'after_title_sep' => 'yes',
				],
			]
		);

		$this->add_control(
			'after_title_sep_style',
			[
				'label'     => esc_html__( 'Style', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'solid'  => esc_html__( 'Solid', 'companion-elementor' ),
					'dashed' => esc_html__( 'Dashed', 'companion-elementor' ),
					'dotted' => esc_html__( 'Dotted', 'companion-elementor' ),
					'double' => esc_html__( 'Double', 'companion-elementor' ),
				],
				'selectors' => [
					'{{WRAPPER}} .ec-sep-title .ec-sep-inner' => 'border-top-style: {{VALUE}};',
				],
				'condition' => [
					'after_title_sep' => 'yes',
				],
			]
		);

		$this->add_control(
			'after_title_sep_color',
			array_merge(
				[
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ec-sep-title .ec-sep-inner' => 'border-top-color: {{VALUE}}',
					],
					'condition' => [
						'after_title_sep' => 'yes',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_4,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_ACCENT,
					],
				]
			)
		);

		$this->add_control(
			'after_title_sep_weight',
			[
				'label'      => esc_html__( 'Weight', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'default'    => [
					'size' => 3,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-sep-title .ec-sep-inner' => 'border-top-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'after_title_sep' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'after_title_sep_width',
			[
				'label'       => esc_html__( 'Width', 'companion-elementor' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ '%', 'px' ],
				'range'       => [
					'px' => [
						'max' => 1000,
					],
				],
				'default'     => [
					'size' => 30,
					'unit' => '%',
				],
				'label_block' => true,
				'selectors'   => [
					'{{WRAPPER}} .ec-sep-title .ec-sep-inner' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'after_title_sep' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'after_title_sep_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .ec-sep-title .ec-sep-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'after_title_sep' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'after_title_sep_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .ec-sep-title .ec-sep-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'after_title_sep' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_cta_controls() {
		$this->start_controls_section(
			'ec_service_box_cta_section',
			[
				'label' => esc_html__( 'Call To Action', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'cta_type',
			[
				'label'   => esc_html__( 'Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'none'    => esc_html__( 'None', 'companion-elementor' ),
					'element' => esc_html__( 'Element', 'companion-elementor' ),
					'text'    => esc_html__( 'Text', 'companion-elementor' ),
					'button'  => esc_html__( 'Button', 'companion-elementor' ),
					'icon'    => esc_html__( 'Icon', 'companion-elementor' ),
					'box'     => esc_html__( 'Box', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'cta_text',
			[
				'label'       => esc_html__( 'Text', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Read More', 'companion-elementor' ),
				'label_block' => true,
				'condition'   => [
					'cta_type' => [ 'text', 'button' ],
				],
			]
		);

		$this->add_control(
			'cta_icon',
			[
				'label'     => esc_html__( 'Icon', 'companion-elementor' ),
				'type'      => Controls_Manager::ICON,
				'default'   => 'fa fa-plus',
				'condition' => [
					'cta_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'cta_link',
			[
				'label'       => esc_html__( 'Link', 'companion-elementor' ),
				'type'        => Controls_Manager::URL,
				'default'     => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
				'placeholder' => esc_html__( 'https://your-link.com', 'companion-elementor' ),
				'condition'   => [
					'cta_type!' => 'none',
				],
			]
		);

		$this->add_control(
			'cta_link_to',
			[
				'label'     => esc_html__( 'Link To', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT2,
				'multiple'  => true,
				'options'   => [
					'title' => esc_html__( 'Title', 'companion-elementor' ),
					'icon'  => esc_html__( 'Icon', 'companion-elementor' ),
				],
				'default'   => [ 'title' ],
				'condition' => [
					'cta_type' => 'element',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_general_controls() {
		$this->start_controls_section(
			'ec_service_box_style_section',
			[
				'label' => esc_html__( 'Service Box', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_alignment',
			[
				'label'       => esc_html__( 'Content Alignment', 'companion-elementor' ),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'     => 'center',
				'selectors'   => [
					'{{WRAPPER}} .ec-service-box' => 'text-align: {{VALUE}};',
				],
				'label_block' => true,
			]
		);

		$this->add_responsive_control(
			'service_box_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'service_box_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'service_box_border',
				'selector' => '{{WRAPPER}} .ec-service-box',
			]
		);

		$this->add_control(
			'service_box_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'service_box_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'service_box_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-service-box',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_service_box_hover_controls() {
		$this->start_controls_section(
			'ec_service_box_hover_style_section',
			[
				'label' => esc_html__( 'Service Box (Hover)', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'service_box_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-service-box:hover',
			]
		);

		$this->add_control(
			'service_box_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'service_box_hover_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box:hover .ec-icon-inner i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'service_box_hover_icon_border_color',
			[
				'label'     => esc_html__( 'Icon Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box:hover .ec-icon-inner' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'service_box_hover_caption_color',
			[
				'label'     => esc_html__( 'Caption Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box:hover .ec-caption' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'service_box_hover_title_color',
			[
				'label'     => esc_html__( 'Title Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box:hover .ec-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'service_box_hover_description_color',
			[
				'label'     => esc_html__( 'Description Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box:hover .ec-description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'service_box_hover_cta_color',
			[
				'label'     => esc_html__( 'Call To Action Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box:hover .ec-service-box-cta a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'service_box_hover_cta_bg',
			[
				'label'     => esc_html__( 'Call To Action Background', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box:hover .ec-cta-btn a' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'service_box_hover_cta_border_color',
			[
				'label'     => esc_html__( 'Call To Action Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box:hover .ec-cta-btn a' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_icon_controls() {
		$this->start_controls_section(
			'ec_service_box_icon_style_section',
			[
				'label' => esc_html__( 'Icon/Image', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_position',
			[
				'label'              => esc_html__( 'Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'top',
				'options'            => [
					'left'  => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'top'   => [
						'title' => esc_html__( 'Top', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'prefix_class'       => 'ec-service-box%s--',
				'frontend_available' => true,
				'condition'          => [
					'icon_type' => [ 'icon', 'image' ],
				],
			]
		);

		$this->add_control(
			'icon_vertical_alignment',
			[
				'label'     => esc_html__( 'Vertical Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'flex-start',
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Top', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					],
					'center'     => [
						'title' => esc_html__( 'Middle', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'flex-end'   => [
						'title' => esc_html__( 'Bottom', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-service-box' => 'align-items: {{VALUE}}',
				],
				'condition' => [
					'icon_position' => [ 'left', 'right' ],
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 12.5,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 12.5,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box .ec-icon-inner'   => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-service-box .ec-icon-inner i' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon_type' => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'icon_font_size',
			[
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box .ec-icon-inner i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon_type' => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'image_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
					'%',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 600,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 37.5,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 37.5,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 120,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box .ec-image-inner' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon_type' => 'image',
				],
			]
		);

		$this->add_control(
			'icon_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_border',
				'selector' => '{{WRAPPER}} .ec-service-box .ec-icon-inner, {{WRAPPER}} .ec-service-box .ec-image-inner',
			]
		);

		$this->add_control(
			'icon_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box .ec-icon-inner'      => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ec-service-box .ec-image-inner'     => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ec-service-box .ec-image-inner img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-service-box .ec-icon-inner, {{WRAPPER}} .ec-service-box .ec-image-inner',
			]
		);

		$this->add_responsive_control(
			'icon_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box .ec-icon-inner'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ec-service-box .ec-image-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box .ec-image-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'icon_type' => 'image',
				],
			]
		);

		$this->start_controls_tabs(
			'icon_tabs',
			[
				'condition' => [
					'icon_type' => 'icon',
				],
			]
		);

		$this->start_controls_tab(
			'icon_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'icon_normal_color',
			array_merge(
				[
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ec-service-box .ec-icon-inner i' => 'color: {{VALUE}}',
						'{{WRAPPER}} .ec-service-box .ec-icon-inner svg' => 'fill: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_1,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_PRIMARY,
					],
				]
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'icon_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-service-box .ec-icon-inner',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'icon_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box .ec-icon-inner:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-service-box .ec-icon-inner:hover svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'icon_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-service-box .ec-icon-inner:hover',
			]
		);

		$this->add_control(
			'icon_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box .ec-icon-inner:hover'  => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ec-service-box .ec-image-inner:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_caption_controls() {
		$this->start_controls_section(
			'ec_service_box_style_caption_section',
			[
				'label' => esc_html__( 'Caption', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'caption_heading',
			[
				'label'     => esc_html__( 'Caption', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'caption_tag',
			[
				'label'   => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'span',
				'options' => [
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'caption_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box-content .ec-caption' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'caption_typography',
				'selector' => '{{WRAPPER}} .ec-service-box-content .ec-caption',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'caption_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-service-box-content .ec-caption',
			]
		);

		$this->add_control(
			'caption_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'caption_border',
				'selector' => '{{WRAPPER}} .ec-service-box-content .ec-caption',
			]
		);

		$this->add_control(
			'caption_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'caption_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-content .ec-caption' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'caption_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-content .ec-caption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'caption_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-content .ec-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_title_controls() {
		$this->start_controls_section(
			'ec_service_box_style_title_section',
			[
				'label' => esc_html__( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label'     => esc_html__( 'Title', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'   => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h3',
				'options' => [
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box-content .ec-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .ec-service-box-content .ec-title',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'title_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-service-box-content .ec-title',
			]
		);

		$this->add_control(
			'title_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'title_border',
				'selector' => '{{WRAPPER}} .ec-service-box-content .ec-title',
			]
		);

		$this->add_control(
			'title_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'title_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-content .ec-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-content .ec-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_description_controls() {
		$this->start_controls_section(
			'ec_service_box_style_description_section',
			[
				'label' => esc_html__( 'Description', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'description_heading',
			[
				'label'     => esc_html__( 'Description', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box-content .ec-description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .ec-service-box-content .ec-description',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'description_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-service-box-content .ec-description',
			]
		);

		$this->add_control(
			'description_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'description_border',
				'selector' => '{{WRAPPER}} .ec-service-box-content .ec-description',
			]
		);

		$this->add_control(
			'description_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'description_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-content .ec-description' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'description_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-content .ec-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	private function register_style_cta_controls() {
		$this->start_controls_section(
			'ec_service_box_cta_style_section',
			[
				'label'     => esc_html__( 'Call To Action', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'cta_type!' => [ 'none', 'element', 'box' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'cta_typography',
				'selector'  => '{{WRAPPER}} .ec-service-box-cta',
				'condition' => [
					'cta_type!' => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'cta_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-cta.ec-cta-btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => [ 'button' ],
				],
			]
		);

		$this->add_responsive_control(
			'icon_width',
			[
				'label'      => esc_html__( 'Width', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-cta.ec-cta-icon a' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => [ 'icon' ],
				],
			]
		);

		$this->add_responsive_control(
			'icon_height',
			[
				'label'      => esc_html__( 'Height', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-cta.ec-cta-icon a'   => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-service-box-cta.ec-cta-icon a i' => 'line-height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => [ 'icon' ],
				],
			]
		);

		$this->add_responsive_control(
			'cta_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-cta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'cta_border',
				'selector'  => '{{WRAPPER}} .ec-service-box-cta.ec-cta-btn a, {{WRAPPER}} .ec-service-box-cta.ec-cta-icon a',
				'condition' => [
					'cta_type' => [ 'button', 'icon' ],
				],
			]
		);

		$this->add_responsive_control(
			'cta_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-service-box-cta.ec-cta-btn a, {{WRAPPER}} .ec-service-box-cta.ec-cta-icon a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cta_type' => [ 'button', 'icon' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'cta_box_shadow',
				'label'     => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector'  => '{{WRAPPER}} .ec-service-box-cta.ec-cta-btn a, {{WRAPPER}} .ec-service-box-cta.ec-cta-icon a',
				'condition' => [
					'cta_type' => [ 'button', 'icon' ],
				],
			]
		);

		$this->start_controls_tabs(
			'cta_tabs'
		);

		$this->start_controls_tab(
			'cta_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box-cta a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cta_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-service-box-cta.ec-cta-btn a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cta_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box-cta a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cta_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-service-box-cta.ec-cta-btn a:hover',
			]
		);

		$this->add_control(
			'cta_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-service-box-cta.ec-cta-btn a:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/service-box-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings    = $this->get_settings_for_display();
		$icon        = ( 'icon' === $settings['icon_type'] ) && $settings['icon_v5'] ? $settings['icon_v5'] : '';
		$image       = ( 'image' === $settings['icon_type'] ) && $settings['image'] ? $settings['image']['url'] : '';
		$caption     = $settings['caption'];
		$title       = $settings['title'];
		$description = $settings['description'];
		$cta_type    = $settings['cta_type'];
		$link        = $settings['cta_link'];
		$link_to     = $settings['cta_link_to'];
		$cta_text    = $settings['cta_text'];
		$cta_icon    = $settings['cta_icon'];
		$caption_tag = $settings['caption_tag'];
		$title_tag   = $settings['title_tag'];

		$link_to_icon   = ( $link_to && $link['url'] && in_array( 'icon', $link_to, true ) );
		$link_to_title  = ( $link_to && $link['url'] && in_array( 'title', $link_to, true ) );
		$show_cta       = ( 'icon' === $cta_type ) || ( 'text' === $cta_type ) || ( 'button' === $cta_type );
		$is_link_to_cta = ( $show_cta && isset( $link['url'] ) );
		$is_link_to_box = ( 'box' === $cta_type ) && isset( $link['url'] );
		?>

		<div class="ec-service-box-wrapper">
			<div class="ec-service-box">

				<?php if ( $is_link_to_box ) : ?>
					<a class="ec-service-box-link"
						href="<?php echo esc_url( $link['url'] ); ?>" <?php echo $link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $link['nofollow'] ? 'rel="nofollow"' : ''; ?>></a>
				<?php endif; ?>

				<?php if ( $icon || $image ) : ?>
					<div class="ec-icon">
						<?php if ( $icon || array_key_exists( 'icon', $settings ) ) : ?>
							<span class="ec-icon-inner">
								<?php if ( $link_to_icon ) : ?>
									<a href="<?php echo esc_url( $link['url'] ); ?>" <?php echo $link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $link['nofollow'] ? 'rel="nofollow"' : ''; ?>>
								<?php endif; ?>

								<?php
								$migrated = isset( $settings['__fa4_migrated']['icon_v5'] );
								$is_new   = ! array_key_exists( 'icon', $settings );
								if ( $is_new || $migrated ) :
									Icons_Manager::render_icon( $settings['icon_v5'], [ 'aria-hidden' => 'true' ] );
								else :
									?>
									<i class="<?php echo ( is_array( $settings['icon'] ) ? $settings['icon']['value'] : $settings['icon'] ); ?>" aria-hidden="true"></i>
								<?php endif; ?>

								<?php if ( $link_to_icon ) : ?>
									</a>
								<?php endif; ?>
							</span> <!-- /.ec-icon-inner -->

						<?php elseif ( $image ) : ?>
							<div class="ec-image-inner">
								<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>">
							</div> <!-- /.ec-image-inner -->
						<?php endif; ?>
					</div> <!-- /.ec-icon -->
				<?php endif; ?>

				<div class="ec-service-box-content">
					<?php if ( $caption ) : ?>
					<<?php echo esc_attr( $caption_tag ); ?> class="ec-caption">
						<?php echo esc_html( $caption ); ?>
				</<?php echo esc_attr( $caption_tag ); ?>>
			<?php endif; ?>

				<?php if ( $settings['after_caption_sep'] ) : ?>
					<div class="ec-sep ec-sep-cap">
						<div class="ec-sep-inner"></div>
					</div>
				<?php endif; ?>

				<?php if ( $title ) : ?>
				<<?php echo esc_attr( $title_tag ); ?> class="ec-title">
					<?php if ( $link_to_title ) : ?>
				<a href="<?php echo esc_url( $link['url'] ); ?>" <?php echo $link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $link['nofollow'] ? 'rel="nofollow"' : ''; ?>>
					<?php endif; ?>
					<?php echo esc_html( $title ); ?>
					<?php if ( $link_to_title ) : ?>
				</a>
			<?php endif; ?>
			</<?php echo esc_attr( $title_tag ); ?>>
			<?php endif; ?>

			<?php if ( $settings['after_title_sep'] ) : ?>
				<div class="ec-sep ec-sep-title">
					<div class="ec-sep-inner"></div>
				</div>
			<?php endif; ?>

			<?php if ( $description ) : ?>
				<div class="ec-description">
					<?php echo wp_kses_post( $description ); ?>
				</div>
			<?php endif; ?>

			<?php if ( $show_cta && ( $cta_text || $cta_icon ) ) : ?>
				<div class="ec-service-box-cta <?php echo ( 'button' === $cta_type ) ? esc_attr( 'ec-cta-btn' ) : ''; ?> <?php echo ( 'icon' === $cta_type ) ? esc_attr( 'ec-cta-icon' ) : ''; ?>">
					<?php if ( $is_link_to_cta ) : ?>
					<a href="<?php echo esc_url( $link['url'] ); ?>" <?php echo $link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $link['nofollow'] ? 'rel="nofollow"' : ''; ?>>
						<?php endif; ?>

						<?php if ( $cta_text ) : ?>
							<span class="ec-cta-text"><?php echo esc_html( $cta_text ); ?></span>
						<?php elseif ( $cta_icon ) : ?>
							<i class="<?php echo esc_attr( $cta_icon ); ?>"></i>
						<?php endif; ?>

						<?php if ( $is_link_to_cta ) : ?>
					</a>
				<?php endif; ?>

				</div> <!-- /.ec-service-box-cta -->
			<?php endif; ?>
		</div> <!-- /.ec-service-box-content -->

		</div> <!-- /.ec-service-box -->
		</div> <!-- /.ec-service-box-wrapper -->
		<?php
	}
}
