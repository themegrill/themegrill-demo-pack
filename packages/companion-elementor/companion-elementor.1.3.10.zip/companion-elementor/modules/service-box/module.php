<?php

namespace CompanionElementor\Modules\ServiceBox;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Service_Box',
		];
	}

	public function get_name() {
		return 'service-box';
	}

}
