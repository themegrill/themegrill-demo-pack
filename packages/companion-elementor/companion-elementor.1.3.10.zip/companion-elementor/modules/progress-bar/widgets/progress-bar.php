<?php
/**
 * Progress bar class.
 */
namespace CompanionElementor\Modules\ProgressBar\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

defined( 'ABSPATH' ) || exit;

class Progress_Bar extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-progress-bar';
	}

	public function get_title() {
		return __( 'Progress Bar', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-skill-bar';
	}

	public function get_keywords() {
		return array( 'companion', 'progress bar', 'progress', 'bar' );
	}

	protected function register_controls() {
		$this->register_progress_bar_controls();
		$this->register_style_progress_bar_general_controls();
		$this->register_style_progress_bar_heading_controls();
		$this->register_style_progress_bar_counter_controls();
		$this->register_style_progress_bar_controls();
		$this->register_style_progress_circle_controls();
	}

	private function register_progress_bar_controls() {
		$this->start_controls_section(
			'section_progress_bar',
			array(
				'label' => esc_html__( 'Progress Bar', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'progress_bar_layout',
			array(
				'label'   => esc_html__( 'Layout', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'horizontal',
				'options' => array(
					'circle'     => esc_html__( 'Circle', 'companion-elementor' ),
					'horizontal' => esc_html__( 'Horizontal', 'companion-elementor' ),
				),
			)
		);

		$this->add_control(
			'progress_bar_heading',
			array(
				'label'   => esc_html__( 'Heading', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Write Heading...', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'progress_bar_heading_position',
			array(
				'label'   => esc_html__( 'Heading Position', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'outsideBar',
				'options' => array(
					'outsideBar' => esc_html__( 'Outside Bar', 'companion-elementor' ),
					'insideBar'  => esc_html__( 'Inside Bar', 'companion-elementor' ),
				),
			)
		);

		$this->add_control(
			'progress_bar_counter_value',
			array(
				'label'   => esc_html__( 'Counter Value', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 70,
				'min'     => 0,
				'step'    => 1,
				'dynamic' => array(
					'active' => true,
				),
			)
		);

		$this->add_control(
			'progress_bar_max_value',
			array(
				'label'   => esc_html__( 'Max Value', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 100,
				'min'     => 0,
				'step'    => 1,
				'dynamic' => array(
					'active' => true,
				),
			)
		);

		$this->add_control(
			'progress_bar_counter_show',
			array(
				'label'        => esc_html__( 'Show Counter', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_progress_bar_general_controls() {
		$this->start_controls_section(
			'progress_bar_general_section',
			array(
				'label' => esc_html__( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'progress_bar_background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-progress-bar' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ec-progress-circle svg circle' => 'stroke: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'progress_bar_fill_color',
			array(
				'label'     => esc_html__( 'Fill Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-progress-bar-inner-bar' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ec-progress-circle .ec-progress-circle__bar' => 'stroke: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_progress_bar_heading_controls() {
		$this->start_controls_section(
			'progress_bar_heading_section',
			array(
				'label' => esc_html__( 'Heading', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'progress_bar_heading_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-progress-bar-text' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'progress_bar_heading_typography',
				'selector' => '{{WRAPPER}} .ec-progress-bar-text',
			)
		);

		$this->end_controls_section();
	}

	private function register_style_progress_bar_counter_controls() {
		$this->start_controls_section(
			'progress_bar_counter_section',
			array(
				'label' => esc_html__( 'Counter', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'progress_bar_counter_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-progress-inner-value' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'progress_bar_counter_typography',
				'selector' => '{{WRAPPER}} .ec-progress-inner-value',
			)
		);

		$this->end_controls_section();
	}

	private function register_style_progress_bar_controls() {
		$this->start_controls_section(
			'progress_bar_style_section',
			array(
				'label' => esc_html__( 'Bar', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'progress_bar_width',
			array(
				'label'     => esc_html__( 'Width', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'%' => array(
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					),
				),
				'default'   => array(
					'unit' => '%',
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-progress-bar, {{WRAPPER}} .ec-progress-outside-label' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'progress_bar_height',
			array(
				'label'     => esc_html__( 'Height', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 24,
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-progress-bar' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_progress_circle_controls() {
		$this->start_controls_section(
			'progress_circle_style_section',
			array(
				'label' => esc_html__( 'Circle', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'progress_circle_size',
			array(
				'label'     => esc_html__( 'Size', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 100,
						'max'  => 300,
						'step' => 1,
					),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 194,
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-progress-circle' => '--progress-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'progress_circle_thickness',
			array(
				'label'     => esc_html__( 'Thickness', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 1,
						'max'  => 100,
						'step' => 1,
					),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 8,
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-progress-circle' => '--progress-thickness: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings                      = $this->get_settings_for_display();
		$progress_bar_heading          = $settings['progress_bar_heading'];
		$progress_bar_layout           = $settings['progress_bar_layout'];
		$progress_bar_counter_value    = $settings['progress_bar_counter_value'];
		$progress_bar_counter_show     = $settings['progress_bar_counter_show'];
		$progress_bar_heading_position = $settings['progress_bar_heading_position'];
		$progress_bar_max_value        = $settings['progress_bar_max_value'];
		$progress_bar_counter_percent  = round( ( $settings['progress_bar_counter_value'] / $settings['progress_bar_max_value'] ) * 100 );
		$progress_bar_options          = array(
			'counterValue'        => $settings['progress_bar_counter_value'],
			'percentValueCounter' => $progress_bar_counter_percent,
		);

		$this->add_render_attribute(
			'ec-progress-bar',
			array(
				'class'        => 'ec-progress-bar-wrapper',
				'data-options' => wp_json_encode( $progress_bar_options ),
			)
		);
		?>
		<div <?php echo $this->get_render_attribute_string( 'ec-progress-bar' ); ?>>
			<?php if ( 'horizontal' === $progress_bar_layout ) { ?>
				<?php if ( 'outsideBar' === $progress_bar_heading_position ) { ?>
				<div class="ec-progress-outside-label">
					<span class="ec-progress-bar-text"><?php echo esc_html( $progress_bar_heading ); ?></span>
					<span class="ec-progress-inner-value">
						<?php
						if ( 'yes' === $progress_bar_counter_show ) {
							echo esc_html( $progress_bar_counter_value ); }
						?>
					</span>
				</div>
				<div class="ec-progress-bar">
					<div class="ec-progress-bar-inner-bar">
					</div>
				</div>
				<?php } elseif ( 'insideBar' === $progress_bar_heading_position ) { ?>
					<div class="ec-progress-bar">
						<div class="ec-progress-bar-inner-bar">
							<span class="ec-progress-bar-text"><?php echo esc_html( $progress_bar_heading ); ?></span>
							<span class="ec-progress-inner-value">
								<?php
								if ( 'yes' === $progress_bar_counter_show ) {
									echo esc_html( $progress_bar_counter_value ); }
								?>
							</span>
						</div>
					</div>
				<?php } ?>
			<?php } ?>
			<?php if ( 'circle' === $progress_bar_layout ) { ?>
				<div class="ec-progress-circle ec--with-animation ec-animate" style="--progress-max: <?php echo esc_attr( $progress_bar_max_value ); ?>;">
					<svg>
						<circle class="ec-progress-circle__background"></circle>
						<circle class="ec-progress-circle__bar"></circle>
					</svg>
					<div class="ec-number">
						<span class="ec-progress-circle__inner-text">
						<span class="ec-progress-bar-text"><?php echo esc_attr( $progress_bar_heading ); ?></span>
						<span class="ec-progress-inner-value">
							<?php
							if ( 'yes' === $progress_bar_counter_show ) {
								echo esc_html( $progress_bar_counter_value ); }
							?>
						</span>
					</span>
					</div>
				</div>
			<?php } ?>
		</div>
		<?php
	}
}
