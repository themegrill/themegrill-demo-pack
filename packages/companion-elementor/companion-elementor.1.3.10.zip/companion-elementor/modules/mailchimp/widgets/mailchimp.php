<?php
/**
 * Mailchimp class.
 */
namespace CompanionElementor\Modules\Mailchimp\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use CompanionElementor\Classes\Utils as CompanionElementorUtils;

defined( 'ABSPATH' ) || exit;

class Mailchimp extends Base_Widget {


	public function get_name() {
		return 'elementor-companion-mailchimp';
	}

	public function get_title() {
		return __( 'Mailchimp', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-mailchimp';
	}

	public function get_keywords() {
		return array( 'companion', 'mailchimp' );
	}

	protected function register_controls() {
		$this->register_setting_controls();
		$this->register_general_controls();
		$this->register_style_container_controls();
		$this->register_style_label_controls();
		$this->register_style_field_controls();
		$this->register_style_sub_button_controls();
	}

	private function register_setting_controls() {
		$this->start_controls_section(
			'section_setting',
			array(
				'label' => esc_html__( 'Setting', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'mailchimp_audience',
			array(
				'label'   => esc_html__( 'Select Audience', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'def',
				'options' => CompanionElementorUtils::get_mailchimp_lists(),

			)
		);

		if ( '' == get_option( 'ec_mailchimp_api_key' ) ) {
			$this->add_control(
				'mailchimp_key_notice',
				array(
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => sprintf( __( 'Navigate to <strong><a href="%1$s" target="_blank">Dashboard > %2$s > Integrations</a></strong> to set up <strong>MailChimp API Key</strong>.', 'companion-elementor' ), admin_url( 'admin.php?page=companion-addons' ), 'Companion Elementor' ),
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				)
			);
		}

		$this->end_controls_section();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'section_general',
			array(
				'label' => esc_html__( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_form_header',
			array(
				'label'        => esc_html__( 'Show form header', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'form_title',
			array(
				'label'     => esc_html__( 'Form Title', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Join the family!', 'companion-elementor' ),
				'condition' => array(
					'show_form_header' => 'yes',
				),
			)
		);

		$this->add_control(
			'form_description',
			array(
				'label'     => esc_html__( 'Form Description', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXTAREA,
				'default'   => esc_html__( 'Sign up for a Newsletter.', 'companion-elementor' ),
				'condition' => array(
					'show_form_header' => 'yes',
				),
			)
		);

		$this->add_control(
			'form_icon',
			array(
				'label'       => __( 'Icon', 'companion-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => array(
					'value'   => 'fas fa-envelope',
					'library' => 'fa-solid',
				),
				'skin'        => 'inline',
				'label_block' => false,
				'condition'   => array(
					'show_form_header' => 'yes',
				),
			)
		);

		$this->add_responsive_control(
			'form_icon_position',
			array(
				'label'     => esc_html__( 'Icon Position', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'top',
				'options'   => array(
					'left'  => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					),
					'top'   => array(
						'title' => esc_html__( 'Top', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'condition' => array(
					'show_form_header' => 'yes',
				),
			)
		);

		$this->add_control(
			'email_label',
			array(
				'label'     => esc_html__( 'Email Label', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Email', 'companion-elementor' ),
				'separator' => 'before',
			)
		);

		$this->add_control(
			'email_placeholder',
			array(
				'label'   => esc_html__( 'Email placeholder', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'sample@mail.com', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'     => esc_html__( 'Button Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Subscribe', 'companion-elementor' ),
				'separator' => 'before',

			)
		);

		$this->end_controls_section();
	}

	private function register_style_container_controls() {
		$this->start_controls_section(
			'ec_container_section',
			array(
				'label' => esc_html__( 'Container', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'container_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-mailchimp-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'container_border_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'      => 'container_border',
				'selector'  => '{{WRAPPER}} .ec-mailchimp-wrapper',
				'separator' => 'after',
			)
		);

		$this->add_responsive_control(
			'container_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-mailchimp-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'container_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-mailchimp-wrapper',
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'container_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-mailchimp-wrapper',
			)
		);

		$this->end_controls_section();
	}

	private function register_style_label_controls() {
		$this->start_controls_section(
			'ec_label_section',
			array(
				'label' => esc_html__( 'label', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'label_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-mailchimp-email label' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'label_typography',
				'selector' => '{{WRAPPER}} .ec-mailchimp-email label',
			)
		);

		$this->add_responsive_control(
			'label_spacing',
			array(
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-mailchimp-email label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
				'separator' => 'before',
			)
		);

		$this->end_controls_section();
	}

	private function register_style_field_controls() {
		$this->start_controls_section(
			'ec_field_section',
			array(
				'label' => esc_html__( 'Field', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'field_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}}  .ec-mailchimp-wrapper input[type="email"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		$this->add_control(
			'field_padding_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_responsive_control(
			'field_height',
			array(
				'label'     => esc_html__( 'Height', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'unit' => 'px',
					'size' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-mailchimp-wrapper input[type="email"]' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'field_height_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_control(
			'field_text',
			array(
				'label'     => esc_html__( 'Text Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-mailchimp-wrapper input[type="email"]' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'field_typography',
				'selector' => '{{WRAPPER}} .ec-mailchimp-wrapper input[type="email"]',
			)
		);

		$this->add_control(
			'field_bg',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-mailchimp-wrapper input[type="email"]' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'field_bg_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->start_controls_tabs( 'field' );

		$this->start_controls_tab(
			'field_normal',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'field_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-mailchimp-wrapper input[type="email"]',
			)
		);

		$this->add_control(
			'field_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}}  .ec-mailchimp-wrapper input[type="email"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'field_box_shadow',
				'selector' => '{{WRAPPER}} .ec-mailchimp-wrapper input[type="email"]:not([type="radio"]):not([type="checkbox"])',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'field_focus',
			array(
				'label' => esc_html__( 'Focus', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'field_border_color_focus',
			array(
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-mailchimp-wrapper input[type="email"], {{WRAPPER}} .ec-mailchimp-wrapper input[type="email"], {{WRAPPER}} .ec-mailchimp-wrapper input[type="email"]:focus' => 'border-color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'field_box_shadow_focus',
				'selector' => '{{WRAPPER}} .ec-mailchimp-wrapper input[type="email"]:not([type="radio"]):not([type="checkbox"]):focus, {{WRAPPER}} .ec-mailchimp-wrapper input[type="email"]:focus, {{WRAPPER}} .ec-mailchimp-wrapper input[type="email"]:focus',
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_sub_button_controls() {
		$this->start_controls_section(
			'ec_sub_button_section',
			array(
				'label' => esc_html__( 'Button', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'sub_button_typography',
				'selector' => '{{WRAPPER}} .ec-mailchimp-subscribe-button',
			)
		);

		$this->start_controls_tabs(
			'sub_button_tabs'
		);

		$this->start_controls_tab(
			'sub_button_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'sub_button_normal_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-mailchimp-subscribe-button' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'sub_button_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-mailchimp-subscribe-button',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'sub_button_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'sub_button_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-mailchimp-subscribe-button:hover' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'sub_button_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-mailchimp-subscribe-button:hover',
			)
		);

		$this->end_controls_tab();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'      => 'sub_button_border',
				'selector'  => '{{WRAPPER}} .ec-mailchimp-subscribe-button',
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'sub_button_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-mailchimp-subscribe-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'sub_button_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-mailchimp-subscribe-button',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings           = $this->get_settings_for_display();
		$show_form_header   = $settings['show_form_header'];
		$form_title         = $settings['form_title'];
		$form_description   = $settings['form_description'];
		$form_icon_position = $settings['form_icon_position'];
		$email_label        = $settings['email_label'];
		$email_placeholder  = $settings['email_placeholder'];
		$button_text        = $settings['button_text'];
		?>
		<form class="ec-mailchimp-form" method="post">
			<?php
				wp_nonce_field( 'ec_mailchimp_form_nonce', 'ec_mailchimp_form_nonce' );
			?>
			<input type="hidden" name="ec_mailchimp_audience" value="<?php echo esc_attr( $settings['mailchimp_audience'] ?? '' ); ?>">
			<div class="ec-mailchimp-wrapper">

			<?php if ( 'yes' === $show_form_header ) : ?>
				<div class="ec-mailchimp-header <?php echo esc_attr( 'icon-position-' . $form_icon_position ); ?>">
					<?php if ( 'top' === $form_icon_position ) : ?>
						<div class="ec-mailchimp-icon-text">
							<i class="<?php echo esc_attr( is_array( $settings['form_icon'] ) ? $settings['form_icon']['value'] : $settings['form_icon'] ); ?>" aria-hidden="true"></i>
							<h3><?php echo esc_html( $form_title ); ?></h3>
						</div>
					<?php endif; ?>
					<?php if ( 'left' === $form_icon_position ) : ?>
						<div class="ec-mailchimp-icon-text">
								<h3><i class="<?php echo esc_attr( is_array( $settings['form_icon'] ) ? $settings['form_icon']['value'] : $settings['form_icon'] ); ?>" aria-hidden="true"></i><?php echo esc_html( $form_title ); ?></h3>
						</div>
					<?php endif; ?>

					<?php if ( 'right' === $form_icon_position ) : ?>
						<div class="ec-mailchimp-icon-text">
							<h3><?php echo esc_html( $form_title ); ?><i class="<?php echo esc_attr( is_array( $settings['form_icon'] ) ? $settings['form_icon']['value'] : $settings['form_icon'] ); ?>" aria-hidden="true"></i></h3>
						</div>
					<?php endif; ?>

					<div class="ec-mailchimp-header-description">
						<p><?php echo esc_html( $form_description ); ?></p>
					</div>
				</div>
			<?php endif; ?>

				<div class="ec-mailchimp-fields">
					<div class="ec-mailchimp-email">
						<label><?php echo esc_html( $email_label ); ?></label>
						<input type="email" name="ec_mailchimp_email" placeholder="<?php echo esc_attr( $email_placeholder ); ?>" required="required">
					</div>
					<div class="ec-mailchimp-subscribe">
						<button type="submit" class="ec-mailchimp-subscribe-button" data-loading="Subscribing...">
							<?php echo esc_html( $button_text ); ?>
						</button>
					</div>
				</div>
			</div>
		</form>
		<?php
	}
}
