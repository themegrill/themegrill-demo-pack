<?php

namespace CompanionElementor\Modules\AccordionToggle\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || exit;

class Accordion_Toggle extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-accordion-toggle';
	}

	public function get_title() {
		return __( 'Accordion Toggle', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-accordion';
	}

	public function get_keywords() {
		return [ 'companion', 'accordion', 'toggle', 'collapse' ];
	}

	protected function register_controls() {

		$this->register_general_controls();
		$this->register_style_general_controls();
		$this->register_style_title_controls();
		$this->register_style_icon_controls();
		$this->register_style_content_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'section_general',
			[
				'label' => __( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'tab_title',
			[
				'label'       => __( 'Title', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Title', 'companion-elementor' ),
				'dynamic'     => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'tab_content',
			[
				'label'   => __( 'Content', 'companion-elementor' ),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => __( '', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'tabs',
			[
				'label'       => __( 'Accordion Items', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						/* Translators: %s number. */
						'tab_title'   => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 1 ),
						'tab_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'companion-elementor' ),
					],
					[
						/* Translators: %s number. */
						'tab_title'   => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 2 ),
						'tab_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'companion-elementor' ),
					],
				],
				'title_field' => '{{{ tab_title }}}',
			]
		);

		$this->add_control(
			'type',
			[
				'label'        => __( 'Type', 'companion-elementor' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'accordion',
				'options'      => [
					'accordion' => __( 'Accordion', 'companion-elementor' ),
					'toggle'    => __( 'Toggle', 'companion-elementor' ),
				],
				'prefix_class' => 'ec-',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'layout',
			[
				'label'   => esc_html__( 'Layout', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1' => esc_html__( 'Style 1', 'companion-elementor' ),
					'2' => esc_html__( 'Style 2', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'icon',
			[
				'label'       => __( 'Icon', 'companion-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'separator'   => 'before',
				'default'     => [
					'value'   => 'fas fa-plus',
					'library' => 'fa-solid',
				],
				'recommended' => [
					'fa-solid'   => [
						'plus',
						'chevron-down',
						'angle-down',
						'angle-double-down',
						'caret-down',
						'caret-square-down',
					],
					'fa-regular' => [
						'caret-square-down',
					],
				],
				'skin'        => 'inline',
				'label_block' => false,
			]
		);

		$this->add_control(
			'active_icon',
			[
				'label'       => __( 'Active Icon', 'companion-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => [
					'value'   => 'fas fa-minus',
					'library' => 'fa-solid',
				],
				'recommended' => [
					'fa-solid'   => [
						'minus',
						'chevron-up',
						'angle-up',
						'angle-double-up',
						'caret-up',
						'caret-square-up',
					],
					'fa-regular' => [
						'caret-square-up',
					],
				],
				'skin'        => 'inline',
				'label_block' => false,
				'condition'   => [
					'icon[value]!' => '',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_general_controls() {
		$this->start_controls_section(
			'section_style_general',
			[
				'label' => __( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'tabs_border_width',
			[
				'label'     => esc_html__( 'Border Width', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 1,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-at-item' => 'border-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'tabs_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-at-item' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'tabs_hover_bg_color',
			[
				'label'     => esc_html__( 'Hover Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-at-item:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'tabs_active_bg_color',
			[
				'label'     => esc_html__( 'Active Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-at-item.ec-active' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_title_controls() {
		$this->start_controls_section(
			'section_style_title',
			[
				'label' => __( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-tab-title' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-tab-title, {{WRAPPER}} .ec-tab-title a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'title_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-active .ec-tab-title, {{WRAPPER}} .ec-active .ec-tab-title a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .ec-tab-title',
			]
		);

		$this->add_responsive_control(
			'title_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-tab-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_icon_controls() {
		$this->start_controls_section(
			'section_style_icon',
			[
				'label' => __( 'Icon', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_position',
			[
				'label'   => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left'  => [
						'title' => esc_html__( 'Start', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__( 'End', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-at-icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-at-icon .e-font-icon-svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-active .ec-at-icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-active .ec-at-icon .e-font-icon-svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-at-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_content_controls() {
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => __( 'Content', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-tab-content' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'selector' => '{{WRAPPER}} .ec-tab-content',
				'selector' => '{{WRAPPER}} .ec-tab-content p',
			]
		);

		$this->add_control(
			'content_border_width',
			[
				'label'     => esc_html__( 'Border Width', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 1,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-at__style-2 .ec-tab-content' => 'border-left-width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_control(
			'content_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-at__style-2 .ec-tab-content' => 'border-left-color: {{VALUE}}',
				],
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-tab-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => '1',
				],
			]
		);

		$this->add_responsive_control(
			'layout_2_content_padding',
			[
				'label'      => esc_html__( 'Inner Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'default'    => [
					'top'      => '10',
					'right'    => '40',
					'bottom'   => '10',
					'left'     => '40',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-at__style-2 .ec-tab-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => '2',
				],
			]
		);

		$this->add_responsive_control(
			'layout_2_content_margin',
			[
				'label'      => esc_html__( 'Outer Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'default'    => [
					'top'      => '15',
					'right'    => '0',
					'bottom'   => '15',
					'left'     => '70',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-at__style-2 .ec-tab-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => '2',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/accordion-toggle/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$tabs     = $settings['tabs'];
		$layout   = $settings['layout'];
		$icon     = true;

		if ( empty( $settings['icon']['value'] ) ) {
			$icon = false;
		}
		?>

		<div class="ec-at-wrapper <?php echo esc_attr( 'ec-at__style-' . $layout ); ?>">
			<?php
			foreach ( $tabs as $index => $tab ) :
				$tab_count               = $index + 1;
				$tab_content_setting_key = $this->get_repeater_setting_key( 'tab_content', 'tabs', $index );

				$this->add_render_attribute(
					$tab_content_setting_key,
					array(
						'id'       => 'ec-tab-content-5691',
						'class'    => 'ec-tab-content',
						'data-tab' => $tab_count,
					)
				);

				$this->add_inline_editing_attributes( $tab_content_setting_key, 'advanced' );
				?>
				<div class="ec-at-item <?php echo ( 0 === $index && 'accordion' === $settings['type'] ) ? 'ec-active' : ''; ?>">
					<div id="ec-tab-title-5691" class="ec-tab-title" aria-controls="ec-tab-content-5691">
						<?php if ( $icon ) : ?>
							<span class="ec-at-icon ec-at-icon--<?php echo esc_attr( $settings['icon_position'] ); ?>">
								<span class="ec-icon-close">
									<?php Icons_Manager::render_icon( $settings['icon'] ); ?>
								</span>
								<span class="ec-icon-open">
									<?php Icons_Manager::render_icon( $settings['active_icon'] ); ?>
								</span>
							</span>
						<?php endif; ?>

						<a href=""><?php echo esc_html( $tab['tab_title'] ); ?></a>
					</div>

					<div <?php echo $this->get_render_attribute_string( $tab_content_setting_key ); ?>>
						<?php echo $this->parse_text_editor( $tab['tab_content'] ); ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<?php
	}
}
