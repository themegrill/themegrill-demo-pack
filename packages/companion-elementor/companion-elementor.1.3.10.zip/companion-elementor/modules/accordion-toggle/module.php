<?php

namespace CompanionElementor\Modules\AccordionToggle;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Accordion_Toggle',
		];
	}

	public function get_name() {
		return 'accordion-toggle';
	}

}
