<?php

namespace CompanionElementor\Modules\MediaCarousel\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Plugin;

defined( 'ABSPATH' ) || exit;

class Media_Carousel extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-media-carousel';
	}

	public function get_title() {
		return __( 'Media Carousel', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-media-carousel';
	}

	public function get_keywords() {
		return [ 'companion', 'media carousel', 'image', 'carousel', 'slider' ];
	}

	/**
	 * Get style dependencies.
	 *
	 * Retrieve the list of style dependencies the widget requires.
	 *
	 * @since 3.24.0
	 * @access public
	 *
	 * @return array Widget style dependencies.
	 */
	public function get_style_depends(): array {
		return [ 'e-swiper', 'widget-image-carousel' ];
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_settings_controls();
		$this->register_style_slides_controls();
		$this->register_style_image_controls();
		$this->register_style_caption_controls();
		$this->register_style_title_controls();
		$this->register_style_description_controls();
		$this->register_style_cta_controls();
		$this->register_style_navigation_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {

		$this->start_controls_section(
			'ec_media_carousel_slides_section',
			[
				'label' => esc_html__( 'Slides', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$slides_repeater = new Repeater();

		$slides_repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'companion-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$slides_repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Title', 'companion-elementor' ),
				'label_block' => true,
			]
		);

		$slides_repeater->add_control(
			'content',
			[
				'label'   => esc_html__( 'Content', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'companion-elementor' ),
			]
		);

		$slides_repeater->add_control(
			'btn_text',
			[
				'label'       => esc_html__( 'Button Text', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Read More', 'companion-elementor' ),
				'label_block' => true,
			]
		);

		$slides_repeater->add_control(
			'btn_link',
			[
				'label'         => esc_html__( 'Button Link', 'companion-elementor' ),
				'type'          => Controls_Manager::URL,
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'slides',
			[
				'label'       => esc_html__( 'Slides', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $slides_repeater->get_controls(),
				'default'     => [
					[
						/* Translators: %s number. */
						'title' => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 1 ),
					],
					[
						/* Translators: %s number. */
						'title' => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 2 ),
					],

					[
						/* Translators: %s number. */
						'title' => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 3 ),
					],
					[
						/* Translators: %s number. */
						'title' => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 4 ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'image',
				'default' => 'full',
				'exclude' => [ 'custom' ],
			]
		);

		$this->add_control(
			'enable_caption',
			[
				'label'        => esc_html__( 'Enable Caption', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();
	}


	private function register_settings_controls() {
		$this->start_controls_section(
			'ec_media_carousel_settings_section',
			[
				'label' => esc_html__( 'Settings', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$spv = range( 1, 8 );
		$spv = array_combine( $spv, $spv );

		$this->add_responsive_control(
			'spv',
			[
				'type'               => Controls_Manager::SELECT,
				'label'              => esc_html__( 'Slides Per View', 'companion-elementor' ),
				'options'            => $spv,
				'frontend_available' => true,
				'desktop_default'    => 3,
				'tablet_default'     => 2,
				'mobile_default'     => 1,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'        => esc_html__( 'Autoplay', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'delay',
			[
				'label'     => esc_html__( 'Delay', 'companion-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 9999999999,
				'step'      => 1,
				'default'   => 4000,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'loop',
			[
				'label'        => esc_html__( 'Loop', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'speed',
			[
				'label'   => esc_html__( 'Speed', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 9999999999,
				'step'    => 1,
				'default' => 500,
			]
		);

		$this->add_control(
			'navigation',
			[
				'label'   => esc_html__( 'Navigation', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'both',
				'options' => [
					'both'   => esc_html__( 'Arrows & Dots', 'companion-elementor' ),
					'arrows' => esc_html__( 'Arrows', 'companion-elementor' ),
					'dots'   => esc_html__( 'Dots', 'companion-elementor' ),
					'none'   => esc_html__( 'None', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'arrows_position',
			[
				'label'     => esc_html__( 'Arrows Position', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'top-center',
				'options'   => [
					'top-left'          => esc_html__( 'Top Left', 'companion-elementor' ),
					'top-center'        => esc_html__( 'Top Center', 'companion-elementor' ),
					'top-right'         => esc_html__( 'Top Right', 'companion-elementor' ),
					'left-right-center' => esc_html__( 'Left Right ( Vertically Center )', 'companion-elementor' ),
				],
				'condition' => [
					'navigation' => [ 'both', 'arrows' ],
				],
			]
		);

		$this->add_responsive_control(
			'slider_row',
			[
				'type'               => Controls_Manager::SELECT,
				'label'              => esc_html__( 'Slider Row', 'companion-elementor' ),
				'options'            => [
					1 => esc_html__( '1 Row', 'companion-elementor' ),
					2 => esc_html__( '2 Rows', 'companion-elementor' ),
					3 => esc_html__( '3 Rows', 'companion-elementor' ),
					4 => esc_html__( '4 Rows', 'companion-elementor' ),
				],
				'frontend_available' => true,
				'default'            => 1,
			]
		);

		$this->end_controls_section();
	}

	private function register_style_slides_controls() {
		$this->start_controls_section(
			'ec_media_carousel_slides_style_section',
			[
				'label' => esc_html__( 'Slides', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'slide_alignment',
			[
				'label'        => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'      => 'left',
				'prefix_class' => 'ec-media-carousel--',
			]
		);

		$this->add_responsive_control(
			'slide_vertical_alignment',
			[
				'label'       => esc_html__( 'Vertical Alignment', 'companion-elementor' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => true,
				'options'     => [
					'flex-start' => [
						'title' => esc_html__( 'Start', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					],
					'center'     => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'flex-end'   => [
						'title' => esc_html__( 'End', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'condition'   => [
					'spv!' => '1',
				],
				'selectors'   => [
					'{{WRAPPER}} .swiper-wrapper' => 'display: flex; align-items: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'slide_spacing',
			[
				'label'           => esc_html__( 'Space Between', 'companion-elementor' ),
				'type'            => Controls_Manager::SLIDER,
				'default'         => [
					'size' => 30,
				],
				'size_units'      => [
					'px',
					'rem',
					'em',
				],
				'range'           => [
					'px'  => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.1,
					],
				],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 10,
					'unit' => 'px',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'slide_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .swiper-slide',
			]
		);

		$this->add_responsive_control(
			'slide_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-slide' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'           => 'slide_border',
				'selector'       => '{{WRAPPER}} .swiper-slide',
				'fields_options' => [
					'border' => [
						'default' => 'double',
					],
					'width'  => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => true,
						],
					],
					'color'  => [
						'default' => '#e9ecef',
					],
				],
			]
		);

		$this->add_responsive_control(
			'slide_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-slide' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'slide_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .swiper-slide',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_image_controls() {
		$this->start_controls_section(
			'section_style_image',
			[
				'label' => esc_html__( 'Image', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'image_hover_effects',
			[
				'label'   => esc_html__( 'Hover Effects', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					''     => esc_html__( 'None', 'companion-elementor' ),
					'zoom' => esc_html__( 'Zoom In/Out', 'companion-elementor' ),
				],
			]
		);

		$this->start_controls_tabs(
			'image_tabs'
		);

		$this->start_controls_tab(
			'image_tab_normal',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'image_opacity',
			[
				'label'     => esc_html__( 'Opacity', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-slide img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'image_tab_hover',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'image_opacity_hover',
			[
				'label'     => esc_html__( 'Opacity', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-slide:hover img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_control(
			'image_scale_hover',
			[
				'label'     => esc_html__( 'Scale', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0.5,
						'max'  => 2,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-slide:hover img' => 'transform: scale({{SIZE}});',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_caption_controls() {
		$this->start_controls_section(
			'ec_media_carousel_caption_style_section',
			[
				'label' => esc_html__( 'Caption', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'caption_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'caption_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-caption',
			]
		);

		$this->add_responsive_control(
			'caption_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-caption' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_title_controls() {
		$this->start_controls_section(
			'ec_media_carousel_title_style_section',
			[
				'label' => esc_html__( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-caption .ec-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .ec-caption .ec-title',
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-caption .ec-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_description_controls() {
		$this->start_controls_section(
			'ec_media_carousel_description_style_section',
			[
				'label' => esc_html__( 'Description', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'description_heading',
			[
				'label'     => esc_html__( 'Description', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-caption .ec-description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .ec-caption .ec-description',
			]
		);

		$this->add_responsive_control(
			'description_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-caption .ec-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_cta_controls() {
		$this->start_controls_section(
			'ec_media_carousel_style_section',
			[
				'label' => esc_html__( 'Call To Action', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'cta_typography',
				'selector' => '{{WRAPPER}} .ec-btn',
			]
		);

		$this->add_responsive_control(
			'cta_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cta_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'cta_border',
				'selector' => '{{WRAPPER}} .ec-btn',
			]
		);

		$this->add_responsive_control(
			'cta_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'cta_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-btn',
			]
		);

		$this->start_controls_tabs(
			'cta_tabs'
		);

		$this->start_controls_tab(
			'cta_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-btn' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cta_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-btn',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cta_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'cta_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cta_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-btn:hover',
			]
		);

		$this->add_control(
			'cta_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-btn:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_navigation_controls() {
		$this->start_controls_section(
			'ec_media_carousel_navigation_style_section',
			[
				'label' => esc_html__( 'Navigation', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'arrows_heading',
			[
				'label'     => esc_html__( 'Arrows', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'arrows_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .ec-nav' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'arrow_left_icon',
			[
				'label'   => esc_html__( 'Left Icon', 'companion-elementor' ),
				'type'    => Controls_Manager::ICON,
				'default' => 'fa fa-chevron-left',
			]
		);

		$this->add_control(
			'arrow_right_icon',
			[
				'label'   => esc_html__( 'Right Icon', 'companion-elementor' ),
				'type'    => Controls_Manager::ICON,
				'default' => 'fa fa-chevron-right',
			]
		);

		$this->add_responsive_control(
			'arrow_width',
			[
				'label'      => esc_html__( 'Width', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-nav .ec-nav-next' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'arrow_height',
			[
				'label'      => esc_html__( 'Height', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-nav .ec-nav-next'   => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-next i' => 'line-height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev'   => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev i' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'arrow_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-nav .ec-nav-next i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'arrow_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'arrow_border',
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			]
		);

		$this->add_control(
			'arrow_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'arrow_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-nav .ec-nav-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'arrow_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			]
		);

		$this->start_controls_tabs(
			'arrow_tabs'
		);

		$this->start_controls_tab(
			'arrow_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'arrow_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-nav .ec-nav-next i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'arrow_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'arrow_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'arrow_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-nav .ec-nav-next:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev:hover i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'arrow_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next:hover, {{WRAPPER}} .ec-nav .ec-nav-prev:hover',
			]
		);

		$this->add_control(
			'arrow_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-nav .ec-nav-next:hover' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'dots_heading',
			[
				'label'     => esc_html__( 'Dots', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'dot_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'dot_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .ec-pagination' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'dot_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 18,
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/media-carousel-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings         = $this->get_settings_for_display();
		$enable_caption   = $settings['enable_caption'];
		$image_size       = $settings['image_size'];
		$slides           = $settings['slides'];
		$arrow_left_icon  = ! empty( $settings['arrow_left_icon'] ) ? $settings['arrow_left_icon'] : 'fa fa-chevron-left';
		$arrow_right_icon = ! empty( $settings['arrow_right_icon'] ) ? $settings['arrow_right_icon'] : 'fa fa-chevron-right';
		$arrows_position  = $settings['arrows_position'];

		$options                       = [];
		$options['spv']                = $settings['spv'];
		$options['spvTablet']          = $settings['spv_tablet'];
		$options['spvMobile']          = $settings['spv_mobile'];
		$options['autoplay']           = $settings['autoplay'];
		$options['delay']              = $settings['delay'];
		$options['loop']               = $settings['loop'];
		$options['speed']              = $settings['speed'];
		$options['slider_row']         = $settings['slider_row'];
		$options['spaceBetween']       = ! array_key_exists( 'slide_spacing', $settings ) ? 30 : $settings['slide_spacing']['size'];
		$options['spaceBetweenTablet'] = ! array_key_exists( 'slide_spacing_tablet', $settings ) ? 20 : $settings['slide_spacing_tablet']['size'];
		$options['spaceBetweenMobile'] = ! array_key_exists( 'slide_spacing_mobile', $settings ) ? 10 : $settings['slide_spacing_mobile']['size'];

		$options['arrows'] = in_array(
			$settings['navigation'],
			[
				'arrows',
				'both',
			],
			true
		);

		$options['dots'] = in_array(
			$settings['navigation'],
			[
				'dots',
				'both',
			],
			true
		);

		$swiper_class = Plugin::$instance->experiments->is_feature_active( 'e_swiper_latest' ) ? 'swiper' : 'swiper-container';
		?>

		<div class="ec-media-carousel-wrapper">
			<div class="ec-media-carousel swiper-container <?php echo esc_attr( $swiper_class ); ?> ec-arrows--<?php echo esc_attr( $arrows_position ); ?>"
				data-carousel_settings=<?php echo wp_json_encode( $options ); ?> >
				<div class="swiper-wrapper">

					<?php foreach ( $slides as $slide ) : ?>
						<div class="swiper-slide">
							<div class="ec-slide">

								<?php if ( $slide['image']['url'] ) : ?>
									<?php
									$image_id = $slide['image']['id'];

									$image_src = wp_get_attachment_image_src( $image_id, $image_size );
									$image_src = ! empty( $image_src ) ? $image_src[0] : '';

									if ( ! $image_id ) {
										$image_src = $slide['image']['url'];
									}
									?>

									<?php if ( $image_src ) : ?>
										<div class="ec-image">
											<img src="<?php echo esc_url( $image_src ); ?>" alt="<?php echo esc_attr( $slide['title'] ); ?>" >
										</div>
									<?php endif; ?>

								<?php endif; ?>

								<?php if ( 'yes' === $enable_caption && ( $slide['title'] || $slide['content'] || $slide['btn_text'] ) ) : ?>

									<div class="ec-caption">

										<?php if ( $slide['title'] ) : ?>
											<h3 class="ec-title"><?php echo esc_html( $slide['title'] ); ?></h3>
										<?php endif; ?>

										<?php if ( $slide['content'] ) : ?>
											<div class="ec-description">
												<?php echo esc_html( $slide['content'] ); ?>
											</div>
										<?php endif; ?>

										<?php if ( $slide['btn_text'] && $slide['btn_link']['url'] ) : ?>
											<a class="ec-btn" href="<?php echo esc_url( $slide['btn_link']['url'] ); ?>"
												<?php echo( ! empty( $slide['btn_link']['is_external'] ) ? 'target="_blank"' : '' ); ?>
												<?php echo( ! empty( $slide['btn_link']['nofollow'] ) ? 'rel="nofollow"' : '' ); ?>>
												<?php echo esc_html( $slide['btn_text'] ); ?>
											</a>
										<?php endif; ?>
									</div> <!-- /.ec-caption -->

								<?php endif; ?>

							</div>
						</div>
					<?php endforeach; ?>
				</div>

				<?php if ( 'both' === $settings['navigation'] || 'arrows' === $settings['navigation'] ) : ?>
					<div class="ec-nav">
						<span class="ec-nav-prev"><i class="fa <?php echo esc_attr( $arrow_left_icon ); ?>"></i></span>
						<span class="ec-nav-next"><i class="fa <?php echo esc_attr( $arrow_right_icon ); ?>"></i></span>
					</div>
				<?php endif; ?>

				<?php if ( 'both' === $settings['navigation'] || 'dots' === $settings['navigation'] ) : ?>
					<div class="ec-pagination"></div>
				<?php endif; ?>
			</div>
		</div>

		<?php
	}
}
