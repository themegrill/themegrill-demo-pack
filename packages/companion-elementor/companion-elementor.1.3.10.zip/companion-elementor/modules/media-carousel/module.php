<?php

namespace CompanionElementor\Modules\MediaCarousel;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Media_Carousel',
		];
	}

	public function get_name() {
		return 'media-carousel';
	}

}
