<?php

namespace CompanionElementor\Modules\Divider\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use Elementor\Icons_Manager;

defined( 'ABSPATH' ) || exit;

class Divider extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-divider';
	}

	public function get_title() {
		return __( 'Divider', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-divider';
	}

	public function get_keywords() {
		return [ 'companion', 'divider', 'separator' ];
	}


	protected function register_controls() {
		$this->register_general_controls();
		$this->register_style_divider_controls();
		$this->register_style_middle_controls();
		$this->register_style_before_after_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'ec_divider_section',
			[
				'label' => esc_html__( 'Divider', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'divider_type',
			[
				'label'   => esc_html__( 'Type', 'companion-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'normal' => [
						'title' => esc_html__( 'Normal', 'companion-elementor' ),
						'icon'  => 'eicon-ellipsis-h',
					],
					'text'   => [
						'title' => esc_html__( 'Text', 'companion-elementor' ),
						'icon'  => 'eicon-text-area',
					],
					'icon'   => [
						'title' => esc_html__( 'Icon', 'companion-elementor' ),
						'icon'  => 'eicon-alert',
					],
					'image'  => [
						'title' => esc_html__( 'Image', 'companion-elementor' ),
						'icon'  => 'eicon-image',
					],
				],
				'default' => 'icon',
			]
		);

		$this->add_control(
			'text',
			[
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'I am a Divider', 'companion-elementor' ),
				'condition' => [
					'divider_type' => 'text',
				],
			]
		);

		$this->add_control(
			'text_tag',
			[
				'label'     => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'div',
				'options'   => [
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				],
				'condition' => [
					'divider_type' => 'text',
				],
			]
		);

		$this->add_control(
			'icon_v5',
			[
				'label'            => esc_html__( 'Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => [
					'value'   => 'far fa-star',
					'library' => 'solid',
				],
				'condition'        => [
					'divider_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label'     => esc_html__( 'Image', 'companion-elementor' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'divider_type' => 'image',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_divider_controls() {
		$this->start_controls_section(
			'ec_divider_style_section',
			[
				'label' => esc_html__( 'Divider', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'divider_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center'     => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-center',
					],
					'flex-end'   => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .ec-divider'            => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} .ec-divider.ec-stacked' => 'align-items: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'divider_stacked',
			[
				'label'        => esc_html__( 'Stacked', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);

		$this->add_control(
			'divider_direction',
			[
				'label'   => esc_html__( 'Direction', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'horizontal',
				'options' => [
					'horizontal' => esc_html__( 'Horizontal', 'companion-elementor' ),
					'vertical'   => esc_html__( 'Vertical', 'companion-elementor' ),
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_middle_controls() {
		$this->start_controls_section(
			'ec_divider_middle_style_section',
			[
				'label' => esc_html__( 'Middle', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_heading',
			[
				'label'     => esc_html__( 'Text', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
				'condition' => [
					'divider_type' => 'text',
				],
			]
		);

		$this->add_control(
			'icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
				'condition' => [
					'divider_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'image_heading',
			[
				'label'     => esc_html__( 'Image', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
				'condition' => [
					'divider_type' => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'middle_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-middle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'middle_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-middle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'divider_type' => 'text',
				],
			]
		);

		$this->add_control(
			'icon_position',
			[
				'label'              => esc_html__( 'Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'top',
				'options'            => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'prefix_class'       => 'ec-icon--',
				'frontend_available' => true,
				'condition'          => [
					'divider_type!' => [ 'none' ],
				],
				'separator'          => 'after',
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-divider-middle' => 'color: {{VALUE}}',
				],
				'condition' => [
					'divider_type' => [ 'text', 'icon' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'text_typography',
				'selector'  => '{{WRAPPER}} .ec-divider-middle',
				'condition' => [
					'divider_type' => [ 'text' ],
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 12.5,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 12.5,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-middle'   => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-divider-middle i' => 'line-height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'divider_type' => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'icon_font_size',
			[
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-middle i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'divider_type' => 'icon',
				],
				'separator'  => 'after',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'icon_bg',
				'label'     => esc_html__( 'Background', 'companion-elementor' ),
				'types'     => [
					'classic',
					'gradient',
				],
				'selector'  => '{{WRAPPER}} .ec-divider-middle',
				'separator' => 'after',
			]
		);

		$this->add_responsive_control(
			'image_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 600,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 37.5,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 37.5,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 120,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-middle' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'divider_type' => 'image',
				],
			]
		);

		$this->add_control(
			'icon_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_border',
				'selector' => '{{WRAPPER}} .ec-divider-middle',
			]
		);

		$this->add_control(
			'icon_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-middle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_before_after_controls() {
		$this->start_controls_section(
			'ec_divider_before_after_style_section',
			[
				'label' => esc_html__( 'Before/After', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'individual_style',
			[
				'label'        => esc_html__( 'Individual Style?', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);

		$this->add_control(
			'divider_style',
			[
				'label'     => esc_html__( 'Style', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'solid'  => esc_html__( 'Solid', 'companion-elementor' ),
					'double' => esc_html__( 'Double', 'companion-elementor' ),
					'dotted' => esc_html__( 'Dotted', 'companion-elementor' ),
					'dashed' => esc_html__( 'Dashed', 'companion-elementor' ),
				],
				'selectors' => [
					'{{WRAPPER}} .ec-divider-side' => 'border-top-style: {{VALUE}}',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-side' => 'border-right-style: {{VALUE}}',
					'{{WRAPPER}} .ec-stacked--tablet.ec-dir-vert--tablet .ec-divider-side' => 'border-right-style: {{VALUE}}',
					'{{WRAPPER}} .ec-stacked--mobile.ec-dir-vert--mobile .ec-divider-side' => 'border-right-style: {{VALUE}}',
				],
				'separator' => 'before',
				'condition' => [
					'individual_style!' => 'yes',
				],
			]
		);

		$this->add_control(
			'divider_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-divider-side' => 'border-top-color: {{VALUE}}',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-side' => 'border-right-color: {{VALUE}}',
					'{{WRAPPER}} .ec-stacked--tablet.ec-dir-vert--tablet .ec-divider-side' => 'border-right-color: {{VALUE}}',
					'{{WRAPPER}} .ec-stacked--mobile.ec-dir-vert--mobile .ec-divider-side' => 'border-right-color: {{VALUE}}',
				],
				'condition' => [
					'individual_style!' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'divider_length',
			[
				'label'      => esc_html__( 'Length', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'%',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-side' => 'max-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked .ec-divider-side' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked--tablet .ec-divider-side' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked--mobile .ec-divider-side' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-side' => 'height: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'individual_style!' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'divider_weight',
			[
				'label'      => esc_html__( 'Weight', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 3,
						'step' => 0.1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 3,
						'step' => 0.1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 3,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-side' => 'border-top-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-side' => 'border-right-width: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .ec-stacked--tablet.ec-dir-vert--tablet .ec-divider-side' => 'border-right-width: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .ec-stacked--mobile.ec-dir-vert--mobile .ec-divider-side' => 'border-right-width: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'individual_style!' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'divider_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-side' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'individual_style!' => 'yes',
				],
			]
		);

		$this->start_controls_tabs(
			'before_after_tabs',
			[
				'condition' => [
					'individual_style' => 'yes',
				],
			]
		);

		// Tab : Style > Before/After > Individual Style > Yes > Before.
		$this->start_controls_tab(
			'before_tab',
			[
				'label' => esc_html__( 'Before', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'before_style',
			[
				'label'     => esc_html__( 'Style', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'solid'  => esc_html__( 'Solid', 'companion-elementor' ),
					'double' => esc_html__( 'Double', 'companion-elementor' ),
					'dotted' => esc_html__( 'Dotted', 'companion-elementor' ),
					'dashed' => esc_html__( 'Dashed', 'companion-elementor' ),
				],
				'selectors' => [
					'{{WRAPPER}} .ec-divider-before' => 'border-top-style: {{VALUE}}',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-before' => 'border-right-style: {{VALUE}}',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'before_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-divider-before' => 'border-top-color: {{VALUE}}',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-before' => 'border-right-color: {{VALUE}}',
				],
				'condition' => [
					'individual_style' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'before_length',
			[
				'label'      => esc_html__( 'Length', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'%',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-before' => 'max-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked .ec-divider-before' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked--tablet .ec-divider-before' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked--mobile .ec-divider-before' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-before' => 'height: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'before_weight',
			[
				'label'      => esc_html__( 'Weight', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 3,
						'step' => 0.1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 3,
						'step' => 0.1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 3,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-before' => 'border-top-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-before' => 'border-right-width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'divider_before_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		// Tab : Style > Before/After > Individual Style > Yes > After.
		$this->start_controls_tab(
			'after_tab',
			[
				'label' => esc_html__( 'After', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'after_style',
			[
				'label'     => esc_html__( 'Style', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'solid'  => esc_html__( 'Solid', 'companion-elementor' ),
					'double' => esc_html__( 'Double', 'companion-elementor' ),
					'dotted' => esc_html__( 'Dotted', 'companion-elementor' ),
					'dashed' => esc_html__( 'Dashed', 'companion-elementor' ),
				],
				'selectors' => [
					'{{WRAPPER}} .ec-divider-after' => 'border-top-style: {{VALUE}}',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-after' => 'border-right-style: {{VALUE}}',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'after_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-divider-after' => 'border-top-color: {{VALUE}}',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-after' => 'border-right-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'after_length',
			[
				'label'      => esc_html__( 'Length', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'%',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-after' => 'max-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked .ec-divider-after' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked--tablet .ec-divider-after' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked--mobile .ec-divider-after' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-after' => 'height: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'after_weight',
			[
				'label'      => esc_html__( 'Weight', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 3,
						'step' => 0.1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 3,
						'step' => 0.1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 3,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-after' => 'border-top-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-stacked.ec-dir-vert .ec-divider-after' => 'border-right-width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'divider_after_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-divider-after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/divider-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$contents = $this->get_settings_for_display();
		$type     = $contents['divider_type'];
		$icon     = ( 'icon' === $type ) && $contents['icon_v5'] ? $contents['icon_v5'] : '';
		$image    = ( 'image' === $type ) && $contents['image'] ? $contents['image']['url'] : '';
		$text     = $contents['text'];
		$text_tag = $contents['text_tag'];

		$stack_class = ( 'yes' === $contents['divider_stacked'] ) ? ' ec-stacked' : '';

		$direction_class = ( 'yes' === $contents['divider_stacked'] && 'vertical' == $contents['divider_direction'] ) ? ' ec-dir-vert' : '';
		?>

		<div class="ec-divider-wrapper">
			<div class="ec-divider ec-divider--<?php echo esc_attr( $type ); ?> <?php echo esc_attr( $direction_class ); ?> <?php echo esc_attr( $stack_class ); ?>">
				<div class="ec-divider-side ec-divider-before"></div>

				<?php if ( 'normal' !== $type ) : ?>
				<div class="ec-divider-middle">
					<?php if ( 'icon' === $type && ( $icon || array_key_exists( 'icon', $contents ) ) ) { ?>

						<?php
						$migrated = isset( $contents['__fa4_migrated']['icon_v5'] );
						$is_new   = ! array_key_exists( 'icon', $contents );

						if ( $is_new || $migrated ) :
							Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true' ] );
						else :
							?>
							<i class="<?php echo ( is_array( $contents['icon'] ) ? $contents['icon']['value'] : $contents['icon'] ); ?>" aria-hidden="true"></i>
						<?php endif; ?>

					<?php } ?>

					<?php if ( 'image' === $type && $image ) { ?>
						<img src="<?php echo esc_url( $image ); ?>" alt="">
					<?php } ?>

					<?php if ( 'text' === $type && $text ) { ?>
					<<?php echo esc_attr( $text_tag ); ?> class="divider-text">
						<?php echo esc_html( $text ); ?>
				</<?php echo esc_attr( $text_tag ); ?>>
			<?php } ?>
			</div> <!-- /.ec-divider-middle -->
			<?php endif; ?>

			<div class="ec-divider-side ec-divider-after"></div>
		</div> <!-- /.ec-divider -->

		</div> <!-- /.ec-divider-wrapper -->

		<?php
	}
}
