<?php

namespace CompanionElementor\Modules\Divider;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Divider',
		];
	}

	public function get_name() {
		return 'divider';
	}

}
