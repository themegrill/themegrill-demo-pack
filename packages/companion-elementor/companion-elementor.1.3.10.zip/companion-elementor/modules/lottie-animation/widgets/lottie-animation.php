<?php

namespace CompanionElementor\Modules\LottieAnimation\Widgets;

use CompanionElementor\Base\Base_Widget;
use CompanionElementor\Classes\Utils;
use Elementor\Group_Control_Background;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Css_Filter;

defined( 'ABSPATH' ) || exit;

class Lottie_Animation extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-lottie-animation';
	}

	public function get_title() {
		return __( 'Lottie Animation', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-lottie';
	}

	public function get_keywords() {
		return array( 'companion', 'lottie animation', 'lottie', 'animation' );
	}

	public function get_script_depends() {
		return array(
			'lottie',
		);
	}

	protected function register_controls() {
		$this->register_layout_controls();
		$this->register_lottie_controls();
		$this->register_style_general_controls();
		$this->register_style_animation_controls();
	}

	protected function register_layout_controls() {
		$this->start_controls_section(
			'ec_layout_setting',
			array(
				'label' => esc_html__( 'Layout', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'source',
			array(
				'label'   => __( 'File Source', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'url'  => __( 'External URL', 'companion-elementor' ),
					'file' => __( 'Media File', 'companion-elementor' ),
				),
				'default' => 'url',
			)
		);

		$this->add_control(
			'json_url',
			array(
				'label'       => __( 'Animation JSON URL', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array(
					'active' => true,
				),
				'default'     => COMPANION_ELEMENTOR_URL . 'assets/json/wordpress-animation.json',
				'label_block' => true,
				'condition'   => array(
					'source' => 'url',
				),
			)
		);

		$this->add_control(
			'json_file',
			array(
				'label'              => __( 'Upload JSON File', 'companion-elementor' ),
				'type'               => Controls_Manager::MEDIA,
				'media_type'         => 'application/json',
				'frontend_available' => true,
				'condition'          => array(
					'source' => 'file',
				),
			)
		);

		$this->add_responsive_control(
			'animation_width',
			array(
				'label'      => __( 'Width', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'default'    => array(
					'unit' => '%',
					'size' => 50,
				),
				'range'      => array(
					'px' => array(
						'min' => 1,
						'max' => 800,
					),
					'em' => array(
						'min' => 1,
						'max' => 30,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-lottie-animations svg' => 'width: 100% !important; height: 100% !important;',
					'{{WRAPPER}} .ec-lottie-animations' => 'width: {{SIZE}}{{UNIT}} !important; height: {{SIZE}}{{UNIT}} !important;',
				),
			)
		);

		$this->add_responsive_control(
			'rotate',
			[
				'label'     => __( 'Rotate', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => -180,
						'max' => 180,
					],
				],
				'default'   => [
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-lottie-animations' => 'transform: rotate({{SIZE}}deg)',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_lottie_controls() {
		$this->start_controls_section(
			'ec_lottie_setting',
			array(
				'label' => esc_html__( 'Lottie', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'autoplay',
			[
				'label'        => esc_html__( 'Autoplay', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'loop',
			[
				'label'        => esc_html__( 'Loop', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'reverse',
			[
				'label'        => __( 'Reverse', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'condition'    => [
					'playOn!' => 'scroll',
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label'   => __( 'Speed', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 1,
				'min'     => 0,
				'max'     => 5,
				'step'    => 1,
			]
		);

		$this->add_control(
			'playOn',
			[
				'label'              => __( 'Play On', 'companion-elementor' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => 'none',
				'options'            => [
					'none'     => __( 'None', 'companion-elementor' ),
					'viewport' => __( 'Viewport', 'companion-elementor' ),
					'hover'    => __( 'Hover', 'companion-elementor' ),
					'scroll'   => __( 'Scroll', 'companion-elementor' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'animate_view',
			[
				'label'     => __( 'Viewport', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'sizes' => [
						'start' => 0,
						'end'   => 100,
					],
					'unit'  => '%',
				],
				'labels'    => [
					__( 'Bottom', 'companion-elementor' ),
					__( 'Top', 'companion-elementor' ),
				],
				'scales'    => 1,
				'handles'   => 'range',
				'condition' => [
					'playOn' => [ 'scroll', 'viewport' ],
				],
			]
		);

		$this->add_responsive_control(
			'animation_align',
			[
				'label'     => __( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'toggle'    => false,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .ec-lottie-animations-wrapper' => 'display: flex; justify-content: {{VALUE}}; align-items: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'lottie_renderer',
			[
				'label'        => __( 'Render As', 'companion-elementor' ),
				'type'         => Controls_Manager::SELECT,
				'options'      => [
					'svg'    => __( 'SVG', 'companion-elementor' ),
					'canvas' => __( 'Canvas', 'companion-elementor' ),
				],
				'default'      => 'svg',
				'prefix_class' => 'ec-lottie-',
				'render_type'  => 'template',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'render_notice',
			[
				'raw'             => __( 'Set render type to canvas if you\'re having performance issues on the page.', 'companion-elementor' ),
				'type'            => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			]
		);

		$this->add_control(
			'link_switcher',
			[
				'label' => __( 'Wrapper Link', 'companion-elementor' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'link_selection',
			[
				'label'       => __( 'Link Type', 'companion-elementor' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'url'  => __( 'URL', 'companion-elementor' ),
					'link' => __( 'Existing Page', 'companion-elementor' ),
				],
				'default'     => 'url',
				'label_block' => true,
				'condition'   => [
					'link_switcher' => 'yes',
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label'       => __( 'Link', 'companion-elementor' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => [
					'active' => true,
				],
				'default'     => [
					'url' => '#',
				],
				'placeholder' => 'https://compelementor.com/',
				'label_block' => true,
				'condition'   => [
					'link_switcher'  => 'yes',
					'link_selection' => 'url',
				],
			]
		);

		$this->add_control(
			'existing_link',
			[
				'label'       => __( 'Existing Page', 'companion-elementor' ),
				'type'        => Controls_Manager::SELECT2,
				'options'     => Utils::get_pages(),
				'query_slug'  => 'page',
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'link_switcher'  => 'yes',
					'link_selection' => 'link',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_style_general_controls() {
		$this->start_controls_section(
			'ec_general_section',
			[
				'label' => esc_html__( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-lottie-animations-wrapper',
			]
		);

		$this->end_controls_section();
	}

	protected function register_style_animation_controls() {
		$this->start_controls_section(
			'ec_animation_section',
			[
				'label' => esc_html__( 'Animation', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'animation_opacity',
			[
				'label'     => esc_html__( 'Opacity', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-lottie-animations' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_control(
			'transition',
			[
				'label'     => esc_html__( 'Transition Duration', 'companion-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 0.3,
				'min'       => 0,
				'max'       => 5,
				'step'      => 0.1,
				'selectors' => [
					'{{WRAPPER}} .ec-lottie-animations' => 'transition-duration: {{VALUE}}s;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'     => 'css_filters',
				'selector' => '{{WRAPPER}} .ec-lottie-animations',
			]
		);

		$this->end_controls_section();
	}

	public function lottie_attributes( $settings ) {
		$attributes = array(
			'loop'            => $settings['loop'],
			'autoplay'        => $settings['autoplay'],
			'speed'           => $settings['speed'],
			'playOn'          => $settings['playOn'],
			'reverse'         => $settings['reverse'],
			'scroll_start'    => isset( $settings['animate_view']['sizes']['start'] ) ? $settings['animate_view']['sizes']['start'] : '0',
			'scroll_end'      => isset( $settings['animate_view']['sizes']['end'] ) ? $settings['animate_view']['sizes']['end'] : '100',
			'lottie_renderer' => $settings['lottie_renderer'],
		);

		return $attributes;
	}

	protected function render() {

		$settings    = $this->get_settings_for_display();
		$lottie_json = 'url' === $settings['source'] ? esc_url( $settings['json_url'] ) : $settings['json_file']['url'];
		$lottie_link = 'url' === $settings['link_selection'] ? $settings['link']['url'] : get_permalink( $settings['existing_link'] );

		if ( '' === $lottie_json ) {
			$lottie_json = COMPANION_ELEMENTOR_URL . 'assets/json/wordpress-animation.json';
		}
		?>
		<?php if ( 'yes' === $settings['link_switcher'] ) : ?>
			<a href="<?php echo esc_url( $lottie_link ); ?>">
		<?php endif; ?>
		<div class="ec-lottie-animations" data-settings="<?php echo htmlspecialchars( wp_json_encode( $this->lottie_attributes( $settings ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" data-json-url="<?php echo esc_url( $lottie_json ); ?>">
		</div>
		<?php if ( 'yes' === $settings['link_switcher'] ) : ?>
			</a>
		<?php endif; ?>
		<?php
	}
}
