<?php

namespace CompanionElementor\Modules\LottieAnimation;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Lottie_Animation',
		];
	}

	public function get_name() {
		return 'lottie_animation';
	}

}
