<?php

namespace CompanionElementor\Modules\NavMenu\Widgets;

use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit;

class Nav_Menu extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-nav-menu';
	}

	public function get_title() {
		return __( 'Nav Menu', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-nav-menu';
	}

	public function get_keywords() {
		return array( 'companion', 'nav menu', 'nav', 'menu' );
	}

	private function get_available_menus() {
		$menus = wp_get_nav_menus();

		$options = array();

		foreach ( $menus as $menu ) {
			$options[ $menu->slug ] = $menu->name;
		}

		return $options;
	}

	protected function register_controls() {
		$this->register_layout_controls();
		$this->register_style_main_menu_controls();
		$this->register_style_sub_menu_controls();
	}

	private function register_layout_controls() {
		$this->start_controls_section(
			'ec_layout_section',
			array(
				'label' => esc_html__( 'Layout', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$menus = $this->get_available_menus();

		if ( ! empty( $menus ) ) {
			$this->add_control(
				'menu',
				array(
					'label'        => esc_html__( 'Menu', 'companion-elementor' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => $menus,
					'default'      => array_keys( $menus )[0],
					'save_default' => true,
					'separator'    => 'after',
					'description'  => sprintf(
						/* Translators: 1: Link to menus screen, 2: Link to widgets screen */
						esc_html__( 'Go to the %1$sMenus screen%2$s to manage your menus.', 'companion-elementor' ),
						sprintf( '<a href="%s" target="_blank">', admin_url( 'nav-menus.php' ) ),
						'</a>'
					),
				)
			);
		} else {
			$this->add_control(
				'menu',
				array(
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => '<strong>' . esc_html__( 'There are no menus in your site.', 'companion-elementor' ) . '</strong><br>' .
							sprintf(
								/* translators: 1: Opening anchor tag, 2: Closing anchor tag */
								esc_html__( 'Go to the %1$sMenus screen%2$s to create one.', 'companion-elementor' ),
								sprintf( '<a href="%s" target="_blank">', admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
								'</a>'
							),
					'separator'       => 'after',
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				)
			);
		}

		$this->add_control(
			'layout',
			array(
				'label'              => esc_html__( 'Layout', 'companion-elementor' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => 'horizontal',
				'options'            => array(
					'horizontal' => esc_html__( 'Horizontal', 'companion-elementor' ),
				),
				'frontend_available' => true,
			)
		);

		$this->add_control(
			'align_items',
			array(
				'label'     => esc_html__( 'Align', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'    => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center'  => array(
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-center',
					),
					'right'   => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					),
					'justify' => array(
						'title' => esc_html__( 'Stretch', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-stretch',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper ul' => 'justify-content: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'pointer',
			array(
				'label'          => esc_html__( 'Pointer', 'companion-elementor' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => 'none',
				'options'        => array(
					'none'        => esc_html__( 'None', 'companion-elementor' ),
					'underline'   => esc_html__( 'Underline', 'companion-elementor' ),
					'overline'    => esc_html__( 'Overline', 'companion-elementor' ),
					'double-line' => esc_html__( 'Double Line', 'companion-elementor' ),
				),
				'style_transfer' => true,
			)
		);

		$this->add_control(
			'animation_line',
			array(
				'label'     => esc_html__( 'Animation', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'none',
				'options'   => array(
					'none'  => 'None',
					'fade'  => 'Fade',
					'slide' => 'Slide',
					'grow'  => 'Grow',
				),
				'condition' => array(
					'pointer' => array( 'underline', 'overline', 'double-line' ),
				),
			)
		);

		$this->add_control(
			'submenu_icon',
			array(
				'label'                  => esc_html__( 'Submenu Indicator', 'companion-elementor' ),
				'type'                   => Controls_Manager::ICONS,
				'separator'              => 'before',
				'default'                => array(
					'value'   => 'fas fa-chevron-down',
					'library' => 'fa-solid',
				),
				'recommended'            => array(
					'fa-solid'   => array(
						'plus',
						'chevron-down',
						'angle-down',
						'angle-double-down',
						'caret-down',
						'caret-square-down',
					),
					'fa-regular' => array(
						'caret-square-down',
					),
				),
				'label_block'            => false,
				'skin'                   => 'inline',
				'exclude_inline_options' => array( 'svg' ),
				'frontend_available'     => true,
			)
		);

		$this->add_control(
			'heading_mobile_dropdown',
			array(
				'label'     => esc_html__( 'Mobile Dropdown', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array(
					'layout!' => 'dropdown',
				),
			)
		);

		$breakpoints = \Elementor\Plugin::$instance->breakpoints->get_active_breakpoints();

		$this->add_control(
			'breakpoint',
			array(
				'label'   => esc_html__( 'Breakpoint', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'tablet',
				'options' => array(
					'mobile' => esc_html__( 'Mobile (≤ 767px)', 'companion-elementor' ),
					'tablet' => esc_html__( 'Tablet (≤ 1024px)', 'companion-elementor' ),
				),
			)
		);

		$this->add_responsive_control(
			'toggle_button_align',
			[
				'label'                => esc_html__( 'Toggle Align', 'companion-elementor' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'default'              => 'center',
				'options'              => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'selectors_dictionary' => [
					'left'   => 'text-align: left',
					'center' => 'text-align: center',
					'right'  => 'text-align: right',
				],
				'selectors'            => [
					'{{WRAPPER}} .ec-mobile-nav' => '{{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_main_menu_controls() {
		$this->start_controls_section(
			'ec_main_menu_style_section',
			array(
				'label'     => esc_html__( 'Main Menu', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'separator' => 'after',
			)
		);

		$this->add_control(
			'menu_item',
			array(
				'label' => esc_html__( 'Menu Item', 'companion-elementor' ),
				'type'  => Controls_Manager::HEADING,
			)
		);

		$this->start_controls_tabs( 'tabs_menu_item_style' );

		$this->start_controls_tab(
			'tab_menu_item_normal',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'color_menu_item',
			array(
				'label'     => esc_html__( 'Text Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper li a' => 'color: {{VALUE}}; fill: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_menu_item_hover',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'color_menu_item_hover',
			array(
				'label'     => esc_html__( 'Text Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper li a:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'color_menu_item_hover_pointer_bg',
			array(
				'label'     => esc_html__( 'Pointer Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper.ec-pointer-underline .menu-item:hover::after,
					{{WRAPPER}} .ec-nav-menu-wrapper.ec-pointer-overline .menu-item:hover::before,
					{{WRAPPER}} .ec-nav-menu-wrapper.ec-pointer-double-line .menu-item:hover::before,
					{{WRAPPER}} .ec-nav-menu-wrapper.ec-pointer-double-line .menu-item:hover::after' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'main_menu_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'main_menu_typography',
				'selector' => '.ec-nav-menu-wrapper li a',
			)
		);

		$this->add_control(
			'main_menu_typography_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_responsive_control(
			'pointer_height',
			array(
				'label'     => esc_html__( 'Pointer Height', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'max' => 20,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper.ec-pointer-underline .menu-item:hover::after,
					{{WRAPPER}} .ec-nav-menu-wrapper.ec-pointer-overline .menu-item:hover::before,
					{{WRAPPER}} .ec-nav-menu-wrapper.ec-pointer-double-line .menu-item:hover::before,
					{{WRAPPER}} .ec-nav-menu-wrapper.ec-pointer-double-line .menu-item:hover::after' => 'height: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->add_responsive_control(
			'menu_item_horizontal_padding',
			array(
				'label'     => esc_html__( 'Horizontal Padding', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'max' => 50,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper .menu-item' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->add_responsive_control(
			'menu_item_vertical_padding',
			array(
				'label'     => esc_html__( 'Vertical Padding', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'max' => 50,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper .menu-item' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->add_responsive_control(
			'menu_gap',
			array(
				'label'      => esc_html__( 'Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
				),
				'range'      => array(
					'px' => array(
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => '',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper ul' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_sub_menu_controls() {
		$this->start_controls_section(
			'ec_sub_menu_style_section',
			array(
				'label' => esc_html__( 'Sub Menu', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'tabs_sub_menu_style' );

		$this->start_controls_tab(
			'tab_sub_menu_normal',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'sub_menu_color',
			array(
				'label'     => esc_html__( 'Text Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper .sub-menu li a' => 'color: {{VALUE}}; fill: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'sub_menu_background_color',
				'label'    => esc_html__( 'Background Color', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-nav-menu-wrapper .sub-menu li a',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_sub_menu_hover',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'sub_menu_color_hover',
			array(
				'label'     => esc_html__( 'Text Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper .sub-menu li a:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'sub_menu_background_hover_color',
				'label'    => esc_html__( 'Background Color', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-nav-menu-wrapper .sub-menu li a:hover',
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'sub_menu_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'sub_menu_typography',
				'selector' => '.ec-nav-menu-wrapper .sub-menu li a',
			)
		);

		$this->add_control(
			'sub_menu_divider_before',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_responsive_control(
			'sub_menu_horizontal_padding',
			array(
				'label'     => esc_html__( 'Horizontal Padding', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'max' => 50,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper .sub-menu li a' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->add_responsive_control(
			'sub_menu_vertical_padding',
			array(
				'label'     => esc_html__( 'Vertical Padding', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'max' => 50,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-nav-menu-wrapper .sub-menu li a' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings           = $this->get_settings();
		$selected_menu_slug = $settings['menu'] ?? 0;
		$pointer            = $settings['pointer'] ?? 'none';
		$animation_line     = $settings['animation_line'] ?? 'none';
		$breakpoint_class   = 'ec-breakpoint-' . $settings['breakpoint'] ?? 'tablet';
		$selected_menu      = wp_get_nav_menu_object( $selected_menu_slug );

		echo '<div class="ec-nav-menu' . esc_attr( " $breakpoint_class" ) . '">';
		if ( $settings['pointer'] ) {
			if ( $selected_menu ) {
				$menu_items = wp_get_nav_menu_items( $selected_menu_slug );

				if ( $menu_items ) {
					add_filter( 'walker_nav_menu_start_el', [ $this, 'add_submenu_icon' ], 10, 4 );
					$menu_wrapper_classes = 'ec-nav-menu-wrapper ec-pointer-' . $pointer . ' ec-animation-' . $animation_line;
					wp_nav_menu(
						array(
							'menu'            => $selected_menu_slug,
							'container'       => 'nav',
							'container_class' => $menu_wrapper_classes,
							'menu_class'      => 'ec-menu',
							'menu_id'         => 'ec-menu',
						)
					);
					?>
					<div class="ec-mobile-nav">
						<button class='ec-menu-toggle'>
							<i aria-hidden='true' class='fas fa-bars'></i>
						</button>
						<!-- Mobile menu content goes here -->
						<nav class="ec-mobile-menu">
							<?php
							wp_nav_menu(
								array(
									'menu'       => $selected_menu_slug,
									'container'  => false,
									'menu_class' => 'ec-mobile-menu-ul',
									'menu_id'    => 'ec-mobile-menu',
								)
							);
							?>
						</nav>
					</div>

					<?php

					remove_filter( 'walker_nav_menu_start_el', [ $this, 'add_submenu_icon' ], 10, 4 );
				} else {
					echo esc_html__( 'This menu has no items.', 'companion-elementor' );
				}
			} else {
				echo esc_html__( 'Selected menu does not exist.', 'companion-elementor' );
			}
		}

		echo '</div>';
	}

	/**
	 * Add submenu icon.
	 *
	 * @param string $item_output
	 * @param object $item
	 * @param int $depth
	 * @param object $args
	 * @return string
	 */
	public function add_submenu_icon( $item_output, $item, $depth, $args ) {
		$settings     = $this->get_settings();
		$submenu_icon = $settings['submenu_icon'];

		if ( 'ec-menu' === $args->menu_id || 'ec-mobile-menu' === $args->menu_id ) {

			if (
				in_array( 'menu-item-has-children', $item->classes, true ) ||
				in_array( 'page_item_has_children', $item->classes, true )
			) {

				$submenu_toggle_markup = '<span role="button" tabindex="0" class="ec-submenu-toggle" onkeypress="">' .
					'<i class="' . $submenu_icon['value'] . '" aria-hidden="true"></i>' .
					'</span>';

				$item_output = str_replace(
					$args->link_after . '</a>',
					'ec-mobile-menu' === $args->menu_id ? $args->link_after . '</a>' . $submenu_toggle_markup : $args->link_after . $submenu_toggle_markup . '</a>',
					$item_output
				);
			}
		}

		return $item_output;
	}
}
