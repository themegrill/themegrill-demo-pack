<?php

namespace CompanionElementor\Modules\NavMenu;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return array(
			'Nav_Menu',
		);
	}

	public function get_name() {
		return 'nav-menu';
	}
}
