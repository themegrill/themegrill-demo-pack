<?php

namespace CompanionElementor\Modules\VideoGallery;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Video_Gallery',
		];
	}

	public function get_name() {
		return 'video-gallery';
	}

}
