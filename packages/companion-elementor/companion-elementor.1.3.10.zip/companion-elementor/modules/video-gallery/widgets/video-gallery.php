<?php

namespace CompanionElementor\Modules\VideoGallery\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Group_Control_Typography;

defined( 'ABSPATH' ) || exit;

class Video_Gallery extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-video-gallery';
	}

	public function get_title() {
		return __( 'Video Gallery', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-video-camera';
	}

	public function get_keywords() {
		return array( 'companion', 'video gallery', 'video' );
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_style_general_controls();
		$this->register_video_general_controls();
		$this->register_style_title_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'section_gallery',
			[
				'label' => esc_html__( 'Gallery', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$video_repeater = new Repeater();

		$video_repeater->add_control(
			'title',
			[
				'label'   => esc_html__( 'Title', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( '', 'companion-elementor' ),
			]
		);

		$video_repeater->add_control(
			'video_type',
			[
				'label'   => esc_html__( 'Video Type', 'companion-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'youtube',
				'options' => [
					'youtube'     => [
						'title' => esc_html__( 'YouTube', 'companion-elementor' ),
						'icon'  => 'fa fa-youtube',
					],
					'self_hosted' => [
						'title' => esc_html__( 'Self Hosted', 'companion-elementor' ),
						'icon'  => 'fa fa-upload',
					],
				],
			]
		);

		$video_repeater->add_control(
			'self_hosted',
			[
				'label'      => esc_html__( 'Upload Your Video', 'companion-elementor' ),
				'type'       => Controls_Manager::MEDIA,
				'media_type' => 'video',
				'condition'  => [
					'video_type' => 'self_hosted',
				],
			]
		);

		$video_repeater->add_control(
			'video_url',
			[
				'label'       => esc_html__( 'Link', 'companion-elementor' ),
				'type'        => Controls_Manager::URL,
				'default'     => [
					'url' => 'https://www.youtube.com/watch?v=AVmheum7cAk&t=4s',
				],
				'placeholder' => esc_html__( 'https://your-link.com', 'companion-elementor' ),
				'condition'   => [
					'video_type' => 'youtube',
				],
			]
		);

		$video_repeater->add_control(
			'thumbnail_size',
			[
				'label'   => esc_html__( 'Thumbnail Size', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'hq',
				'options' => [
					'maxres' => esc_html__( 'Maximum Resolution', 'companion-elementor' ),
					'hq'     => esc_html__( 'High Quality', 'companion-elementor' ),
					'mq'     => esc_html__( 'Medium Quality', 'companion-elementor' ),
					'stdq'   => esc_html__( 'Standard Quality', 'companion-elementor' ),
				],
			]
		);

		$video_repeater->add_control(
			'custom_thumbnail',
			[
				'label'        => esc_html__( 'Custom Thumbnail', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'video_type' => 'self_hosted',
				],
			]
		);

		$video_repeater->add_control(
			'placeholder_image',
			[
				'label'     => esc_html__( 'Select Image', 'companion-elementor' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'custom_thumbnail' => 'yes',
				],
			]
		);

		$this->add_control(
			'videos',
			[
				'label'       => esc_html__( 'Gallery', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $video_repeater->get_controls(),
				'default'     => [
					[
						/* Translators: %s number. */
						'title' => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 1 ),
					],
					[
						/* Translators: %s number. */
						'title' => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 2 ),
					],
					[
						/* Translators: %s number. */
						'title' => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 3 ),
					],
					[
						/* Translators: %s number. */
						'title' => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 4 ),
					],
					[
						/* Translators: %s number. */
						'title' => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 5 ),
					],
					[
						/* Translators: %s number. */
						'title' => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 6 ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();
	}

	private function register_video_general_controls() {
		$this->start_controls_section(
			'section_general',
			[
				'label' => esc_html__( 'General', 'companion-elementor' ),
			]
		);

		$column = range( 1, 6 );
		$column = array_combine( $column, $column );

		$this->add_responsive_control(
			'columns',
			[
				'label'          => esc_html__( 'Columns', 'companion-elementor' ),
				'type'           => Controls_Manager::SELECT,
				'options'        => $column,
				'default'        => 3,
				'tablet_default' => 2,
				'mobile_default' => 1,
			]
		);

		$this->add_control(
			'video_ratio',
			[
				'label'              => esc_html__( 'Video Ratio', 'companion-elementor' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => '16_9',
				'options'            => [
					'16_9' => '16:9',
					'4_3'  => '4:3',
					'3_2'  => '3:2',
				],
				'prefix_class'       => 'vg-video-ratio-',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'ordering',
			[
				'label'   => esc_html__( 'Ordering', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dflt',
				'options' => [
					'dflt' => 'Default',
					'rand' => 'Random',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_general_controls() {
		$this->start_controls_section(
			'section_style_spacing',
			[
				'label' => esc_html__( 'Gallery', 'companion_elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '30',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => [
					'{{WRAPPER}} .ec-grid' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '30',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => [
					'{{WRAPPER}} .ec-grid' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_title_controls() {
		$this->start_controls_section(
			'ec_style_title_section',
			[
				'label' => esc_html__( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'        => esc_html__( 'Show Title', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .ec-videos-title' => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'     => esc_html__( 'HTML Tag', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'h3',
				'options'   => [
					'h1'   => esc_html__( 'H1', 'companion-elementor' ),
					'h2'   => esc_html__( 'H2', 'companion-elementor' ),
					'h3'   => esc_html__( 'H3', 'companion-elementor' ),
					'h4'   => esc_html__( 'H4', 'companion-elementor' ),
					'h5'   => esc_html__( 'H5', 'companion-elementor' ),
					'h6'   => esc_html__( 'H6', 'companion-elementor' ),
					'div'  => esc_html__( 'div', 'companion-elementor' ),
					'span' => esc_html__( 'span', 'companion-elementor' ),
					'p'    => esc_html__( 'p', 'companion-elementor' ),
				],
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-videos-title' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'title_typography',
				'selector'  => '{{WRAPPER}} .ec-videos-title',
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/video-gallery/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings  = $this->get_settings_for_display();
		$columns   = $settings['columns'];
		$videos    = $settings['videos'];
		$gallery   = $videos;
		$title_tag = $settings['title_tag'];
		$yt_args   = [
			'height' => absint( 146 ),
			'width'  => absint( 260 ),
		];

		$wrapper_class = 'ec-grid__' . $this->get_settings( 'columns' ) . ' ec-grid__tablet-' . $this->get_settings( 'columns_tablet' ) . ' ec-grid__mobile-' . $this->get_settings( 'columns_mobile' );

		$hosted_args['controlsList'] = 'nodownload';
		$hosted_args['controls']     = '';

		if ( isset( $videos ) && ! empty( $videos ) ) {

			if ( 'rand' === $settings['ordering'] ) {
				$keys = array_keys( $gallery );
				shuffle( $keys );

				foreach ( $keys as $key ) {
					$new_gallery[ $key ] = $gallery[ $key ];
				}
			} else {
				$new_gallery = $gallery;
			}
			?>

			<div class="ec-vg-items-wrap <?php echo esc_attr( $wrapper_class ); ?>">
				<div class="ec-grid">
					<?php foreach ( $new_gallery as $videos ) : ?>
						<?php
							$target     = $videos['video_url']['is_external'] ? ' target="_blank"' : '';
							$nofollow   = $videos['video_url']['nofollow'] ? ' rel="nofollow"' : '';
							$video_type = $videos['video_type'];

						if ( 'yes' === $videos['custom_thumbnail'] ) {
							$hosted_args['poster'] = $videos['placeholder_image']['url'];
						} else {
							$hosted_args['poster'] = '';
						}
						?>

						<div class="ec-vg-item">
							<div class="ec-vg__content-wrap">
								<div class="vg-fit-video-ratio">
									<?php
									if ( 'youtube' === $video_type ) {
										echo $videos['video_url']['url'] ? wp_oembed_get( esc_url( $videos['video_url']['url'] ), $yt_args ) : '';
									} elseif ( 'self_hosted' === $video_type ) {
										if ( $videos['self_hosted']['url'] ) {
											echo '<video class="elementor-video" src="' . esc_url( $videos['self_hosted']['url'] ) . '" ' . Utils::render_html_attributes( $hosted_args ) . '></video>';
										}
									}
									?>
								</div><!-- /.vg-fit-video-ratio -->

								<?php
								if ( ( 'yes' === $settings['show_title'] ) && ( ! empty( $videos['title'] ) ) ) {
									printf( '<%1$s class="ec-videos-title">%2$s</%1$s>', esc_attr( $title_tag ), esc_html__( $videos['title'], 'companion-elementor' ) );
								}
								?>
							</div><!-- /.ec-vg-item -->
						</div><!-- /.ec-vg-item -->
					<?php endforeach; ?>
				</div><!-- /.ec-grid -->
			</div><!-- /.ec-vg-items-wrap -->

			<?php
		}
	}
}
