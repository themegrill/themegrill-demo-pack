<?php

namespace CompanionElementor\Modules\PostSlider\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use CompanionElementor\Classes\Utils;
use WP_Query;
use Elementor\Plugin;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class Post_Slider extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-post-slider';
	}

	public function get_title() {
		return __( 'Post Slider/Carousel', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-post-slider';
	}

	public function get_keywords() {
		return array( 'companion', 'post slider', 'post', 'slider' );
	}

	/**
	 * Get style dependencies.
	 *
	 * Retrieve the list of style dependencies the widget requires.
	 *
	 * @since 3.24.0
	 * @access public
	 *
	 * @return array Widget style dependencies.
	 */
	public function get_style_depends(): array {
		return [ 'e-swiper', 'widget-image-carousel' ];
	}

	protected function register_controls() {
		$this->register_settings_controls();
		$this->register_query_controls();
		$this->register_excerpt_controls();
		$this->register_cta_controls();
		$this->register_style_title_controls();
		$this->register_style_excerpt_controls();
		$this->register_style_navigation_controls();
		$this->register_style_cta_controls();
	}

	private function register_settings_controls() {
		$this->start_controls_section(
			'ec_slider_settings_section',
			array(
				'label' => esc_html__( 'Settings', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'    => 'image',
				'default' => 'full',
			)
		);

		$this->add_control(
			'autoplay',
			array(
				'label'   => esc_html__( 'Autoplay', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'yes',
				'options' => array(
					'yes' => esc_html__( 'Yes', 'companion-elementor' ),
					'no'  => esc_html__( 'No', 'companion-elementor' ),
				),
			)
		);

		$this->add_control(
			'delay',
			array(
				'label'     => esc_html__( 'Delay', 'companion-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 9999999999,
				'step'      => 1,
				'default'   => 4000,
				'condition' => array(
					'autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'loop',
			array(
				'label'        => esc_html__( 'Loop', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$spv = range( 1, 4 );
		$spv = array_combine( $spv, $spv );

		$this->add_responsive_control(
			'spv',
			[
				'type'               => Controls_Manager::SELECT,
				'label'              => esc_html__( 'Slides Per View', 'companion-elementor' ),
				'options'            => $spv,
				'frontend_available' => true,
				'desktop_default'    => 2,
				'tablet_default'     => 2,
				'mobile_default'     => 1,
			]
		);

		$this->add_control(
			'effect',
			array(
				'label'   => esc_html__( 'Effect', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'slide',
				'options' => array(
					'slide'     => esc_html__( 'Slide', 'companion-elementor' ),
					'fade'      => esc_html__( 'Fade', 'companion-elementor' ),
					'cube'      => esc_html__( 'Cube', 'companion-elementor' ),
					'coverflow' => esc_html__( 'Coverflow', 'companion-elementor' ),
					'flip'      => esc_html__( 'Flip', 'companion-elementor' ),
				),
			)
		);

		$this->add_control(
			'speed',
			array(
				'label'   => esc_html__( 'Speed', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 9999999999,
				'step'    => 1,
				'default' => 500,
			)
		);

		$this->add_control(
			'navigation',
			array(
				'label'   => esc_html__( 'Navigation', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'both',
				'options' => array(
					'both'   => esc_html__( 'Arrows &amp; Dots', 'companion-elementor' ),
					'arrows' => esc_html__( 'Arrows', 'companion-elementor' ),
					'dots'   => esc_html__( 'Dots', 'companion-elementor' ),
					'none'   => esc_html__( 'None', 'companion-elementor' ),
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_query_controls() {
		$this->start_controls_section(
			'section_query',
			array(
				'label' => __( 'Query', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$post_types = Utils::get_post_types();

		$this->add_control(
			'post_type',
			array(
				'label'   => __( 'Post Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post',
				'options' => $post_types,
			)
		);

		/* Filters */
		foreach ( $post_types as $pt_key => $type ) {

			$taxonomies = Utils::get_taxonomies( $pt_key );

			if ( ! empty( $taxonomies ) ) {

				foreach ( $taxonomies as $tax_slug => $tax ) {

					$terms = get_terms( $tax_slug );

					$related_terms = array();

					if ( ! empty( $terms ) ) {

						foreach ( $terms as $t_index => $t_obj ) {

							$related_terms[ $t_obj->slug ] = $t_obj->name;
						}

						// Filter type.
						$this->add_control(
							$pt_key . '_' . $tax_slug . '_filter',
							array(
								/* translators: %s Label */
								'label'       => sprintf( __( '%s Filter', 'companion-elementor' ), $tax->label ),
								'type'        => Controls_Manager::SELECT,
								'default'     => 'IN',
								'label_block' => true,
								'options'     => array(
									'IN'     => __( 'Include', 'companion-elementor' ),
									'NOT IN' => __( 'Exclude', 'companion-elementor' ),
								),
								'condition'   => array(
									'post_type' => $pt_key,
								),
							)
						);

						// Choose terms.
						$this->add_control(
							'terms_' . $pt_key . '_' . $tax_slug . '_choices',
							array(
								/* translators: %s label */
								'label'       => sprintf( __( '%s', 'companion-elementor' ), $tax->label ),
								'type'        => Controls_Manager::SELECT2,
								'multiple'    => true,
								'default'     => '',
								'label_block' => true,
								'options'     => $related_terms,
								'condition'   => array(
									'post_type' => $pt_key,
								),
								'separator'   => 'after',
							)
						);

					}
				}
			}
		}

		$this->add_control(
			'author_filter',
			array(
				'label'     => esc_html__( 'Author Filter', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'author__in',
				'options'   => array(
					'author__in'     => esc_html__( 'Include', 'companion-elementor' ),
					'author__not_in' => esc_html__( 'Exclude', 'companion-elementor' ),
				),
				'separator' => 'before',
			)
		);

		$users = Utils::get_users();

		$this->add_control(
			'author',
			array(
				'label'    => esc_html__( 'Author', 'companion-elementor' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'options'  => $users,
			)
		);

		$this->add_control(
			'ignore_sticky',
			array(
				'label'        => esc_html__( 'Ignore Sticky Post', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'exclude_current_post',
			array(
				'label'        => esc_html__( 'Exclude Current Post', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();
	}

	private function register_excerpt_controls() {
		$this->start_controls_section(
			'section_excerpt',
			array(
				'label' => __( 'Excerpt', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_excerpt',
			array(
				'label'        => esc_html__( 'Excerpt', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'companion-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'excerpt_length',
			array(
				'label'   => __( 'Length', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 20,
			)
		);

		$this->add_control(
			'excerpt_more',
			array(
				'label'   => __( 'More Text', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( ' ...', 'companion-elementor' ),
			)
		);

		$this->end_controls_section();
	}

	private function register_cta_controls() {
		$this->start_controls_section(
			'section_cta',
			array(
				'label' => __( 'Call To Action', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'cta_link_to',
			array(
				'label'       => esc_html__( 'Link To', 'companion-elementor' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => array(
					'title' => esc_html__( 'Title', 'companion-elementor' ),
					'image' => esc_html__( 'Image', 'companion-elementor' ),
					'cta'   => esc_html__( 'CTA', 'companion-elementor' ),
				),
				'default'     => array( 'title', 'image' ),
			)
		);

		$this->add_control(
			'cta_type',
			array(
				'label'     => esc_html__( 'Type', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'button',
				'options'   => array(
					'text'   => esc_html__( 'Text', 'companion-elementor' ),
					'button' => esc_html__( 'Button', 'companion-elementor' ),
				),
				'condition' => [
					'cta_link_to' => 'cta',
				],
			)
		);

		$this->add_control(
			'cta_text',
			array(
				'label'       => esc_html__( 'Text', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Read More', 'companion-elementor' ),
				'label_block' => true,
				'condition'   => [
					'cta_link_to' => 'cta',
				],
			)
		);

		$this->end_controls_section();
	}

	private function register_style_title_controls() {
		$this->start_controls_section(
			'section_style_title',
			array(
				'label' => __( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-post-title a' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'title_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-post-title a:hover' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array_merge(
				array(
					'name'     => 'title_typography',
					'label'    => __( 'Typography', 'companion-elementor' ),
					'selector' => '{{WRAPPER}} .ec-post-title a',
				),
				class_exists( Typography::class ) ? [
					'scheme' => Typography::TYPOGRAPHY_1,
				] : [
					'global' => [
						'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
					],
				]
			)
		);

		$this->add_control(
			'title_spacing',
			array(
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 4,
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-post-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_excerpt_controls() {
		$this->start_controls_section(
			'section_style_excerpt',
			array(
				'label' => __( 'Excerpt', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'excerpt_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-post-excerpt, {{WRAPPER}} .ec-post-excerpt p' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'excerpt_typography',
				'selector' => '{{WRAPPER}} .ec-post-excerpt',
			)
		);

		$this->add_control(
			'excerpt_spacing',
			array(
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 16,
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-post-excerpt' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_navigation_controls() {
		$this->start_controls_section(
			'ec_slider_navigation_style_section',
			array(
				'label' => esc_html__( 'Navigation', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'arrows_heading',
			array(
				'label'     => esc_html__( 'Arrows', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'arrow_left_icon',
			array(
				'label'   => esc_html__( 'Left Icon', 'companion-elementor' ),
				'type'    => Controls_Manager::ICON,
				'default' => 'fa fa-chevron-left',
			)
		);

		$this->add_control(
			'arrow_right_icon',
			array(
				'label'   => esc_html__( 'Right Icon', 'companion-elementor' ),
				'type'    => Controls_Manager::ICON,
				'default' => 'fa fa-chevron-right',
			)
		);

		$this->add_responsive_control(
			'arrow_size',
			array(
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'rem',
					'em',
				),
				'range'      => array(
					'px'  => array(
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					),
					'rem' => array(
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					),
					'em'  => array(
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					),
				),
				'default'    => array(
					'unit' => 'em',
					'size' => 2.4,
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-nav .ec-nav-next' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'arrow_icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'rem',
					'em',
				),
				'range'      => array(
					'px'  => array(
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					),
					'rem' => array(
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					),
					'em'  => array(
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 16,
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-nav .ec-nav-next i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev i' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'arrow_border_divider_before',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'arrow_border',
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			)
		);

		$this->add_control(
			'arrow_border_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_responsive_control(
			'arrow_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-nav .ec-nav-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ec-nav .ec-nav-prev' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'arrow_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			)
		);

		$this->start_controls_tabs(
			'arrow_tabs'
		);

		$this->start_controls_tab(
			'arrow_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'arrow_normal_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-nav .ec-nav-next i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev i' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'arrow_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next, {{WRAPPER}} .ec-nav .ec-nav-prev',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'arrow_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'arrow_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-nav .ec-nav-next:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev:hover i' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'arrow_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-nav .ec-nav-next:hover, {{WRAPPER}} .ec-nav .ec-nav-prev:hover',
			)
		);

		$this->add_control(
			'arrow_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-nav .ec-nav-next:hover' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ec-nav .ec-nav-prev:hover' => 'border-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'dots_heading',
			array(
				'label'     => esc_html__( 'Dots', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'dot_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .swiper-pagination-bullet' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'dot_size',
			array(
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'rem',
					'em',
				),
				'range'      => array(
					'px'  => array(
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					),
					'rem' => array(
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.01,
					),
					'em'  => array(
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.01,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 18,
				),
				'selectors'  => array(
					'{{WRAPPER}} .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_cta_controls() {
		$this->start_controls_section(
			'section_style_cta',
			array(
				'label'     => __( 'Call To Action', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'cta_link_to' => 'cta',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'cta_typography',
				'selector' => '{{WRAPPER}} .ec-post-read-more',
			)
		);

		$this->add_responsive_control(
			'cta_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-post-read-more.ec-cta-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'cta_type' => 'button',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'      => 'cta_border',
				'selector'  => '{{WRAPPER}} .ec-post-read-more.ec-cta-btn',
				'condition' => array(
					'cta_type' => 'button',
				),
			)
		);

		$this->add_responsive_control(
			'cta_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-post-read-more.ec-cta-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'cta_type' => 'button',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'      => 'cta_box_shadow',
				'label'     => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector'  => '{{WRAPPER}} .ec-post-read-more.ec-cta-btn',
				'condition' => array(
					'cta_type' => 'button',
				),
			)
		);

		$this->start_controls_tabs(
			'cta_tabs'
		);

		$this->start_controls_tab(
			'cta_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'cta_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .ec-post-read-more' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'cta_type' => 'text',
				),
			)
		);

		$this->add_control(
			'cta_btn_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => array(
					'{{WRAPPER}} .ec-post-read-more' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'cta_type' => 'button',
				),
			)
		);

		$this->add_control(
			'cta_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#269bd1',
				'selectors' => array(
					'{{WRAPPER}} .ec-post-read-more.ec-cta-btn' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					'cta_type' => 'button',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cta_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'cta_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-post-read-more:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cta_hover_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1e7ba6',
				'selectors' => [
					'{{WRAPPER}} .ec-post-read-more.ec-cta-btn:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'cta_type' => 'button',
				],
			]
		);

		$this->add_control(
			'cta_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-post-read-more:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'cta_type' => 'button',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {
		$settings         = $this->get_settings_for_display();
		$post_type        = ( isset( $settings['post_type'] ) && '' !== $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$ppp              = ( ! isset( $settings['posts_per_page'] ) || '' === $settings['posts_per_page'] ) ? -1 : $settings['posts_per_page'];
		$author_filter    = $settings['author_filter'];
		$author           = $settings['author'];
		$ignore_sticky    = ( isset( $settings['ignore_sticky'] ) && 'yes' === $settings['ignore_sticky'] ) ? true : false;
		$image_size       = isset( $settings['image_size'] ) ? $settings['image_size'] : '';
		$show_excerpt     = $settings['show_excerpt'];
		$cta_text         = isset( $settings['cta_text'] ) ? $settings['cta_text'] : '';
		$cta_link_to      = isset( $settings['cta_link_to'] ) ? $settings['cta_link_to'] : '';
		$cta_type         = isset( $settings['cta_type'] ) ? $settings['cta_type'] : ''; // Assuming cta_type is part of settings
		$cta_text         = ( 'text' === $cta_type || 'button' === $cta_type ) ? ( isset( $settings['cta_text'] ) ? $settings['cta_text'] : '' ) : '';
		$arrow_left_icon  = ! empty( $settings['arrow_left_icon'] ) ? $settings['arrow_left_icon'] : 'fa fa-chevron-left';
		$arrow_right_icon = ! empty( $settings['arrow_right_icon'] ) ? $settings['arrow_right_icon'] : 'fa fa-chevron-right';

		// Settings.

		$options = array(
			'spv'       => $settings['spv'],
			'spvTablet' => $settings['spv_tablet'],
			'spvMobile' => $settings['spv_mobile'],
			'autoplay'  => isset( $settings['autoplay'] ) ? $settings['autoplay'] : false,
			'delay'     => isset( $settings['delay'] ) ? $settings['delay'] : 5000,
			'loop'      => isset( $settings['loop'] ) ? $settings['loop'] : false,
			'effect'    => isset( $settings['effect'] ) ? $settings['effect'] : 'slide',
			'speed'     => isset( $settings['speed'] ) ? $settings['speed'] : 300,
		);

		$options['arrows'] = in_array(
			$settings['navigation'] ?? '',
			array(
				'arrows',
				'both',
			),
			true
		);

		$options['dots'] = in_array(
			$settings['navigation'] ?? '',
			array(
				'dots',
				'both',
			),
			true
		);

		$swiper_class = \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_swiper_latest' ) ? 'swiper' : 'swiper-container';

		$query_args = array(
			'post_type' => 'post',
		);

		$query_args = [
			'post_type'           => $post_type,
			'posts_per_page'      => $ppp,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => $ignore_sticky,
		];

		$taxonomies = Utils::get_taxonomies( $post_type );
		$tax_count  = 1;

		if ( ! empty( $taxonomies ) ) {
			$query_args['tax_query'] = array();

			foreach ( $taxonomies as $tax_key => $taxonomy ) {

				if ( ! $taxonomy->public || ! $taxonomy->show_ui ) {
					continue;
				}
				$terms = isset( $settings[ 'terms_' . $post_type . '_' . $tax_key . '_choices' ] ) ? $settings[ 'terms_' . $post_type . '_' . $tax_key . '_choices' ] : '';

				if ( ! empty( $terms ) ) {

					$filter = $settings[ $post_type . '_' . $tax_key . '_filter' ];

					$query_args['tax_query'][] = array(
						'taxonomy' => $tax_key,
						'field'    => 'slug',
						'terms'    => $terms,
						'operator' => $filter,
					);
				}

				++$tax_count;
			}
		}

		if ( ! empty( $author ) ) {
			$query_args[ $author_filter ] = $author;
		}

		if ( 'yes' === $settings['exclude_current_post'] ) {
			$query_args['post__not_in'][] = get_the_ID();
		}

		$query = new \WP_Query( $query_args );

		if ( $query->have_posts() ) :
			?>
			<div class="ec-post-slider-wrapper">
				<div class="ec-post-slider swiper-container swiper <?php echo esc_attr( $swiper_class ); ?>" data-slider_options='<?php echo wp_json_encode( $options ); ?>'>

					<div class="swiper-wrapper">
						<?php
						while ( $query->have_posts() ) :
							$query->the_post();
							?>
							<article class="ec-post ec-slider-item swiper-slide">
								<div class="ec-post-thumbnail-link">
									<?php

									$image_id  = get_post_thumbnail_id();
									$image_url = $image_id ? wp_get_attachment_image_url( $image_id, $image_size ) : '';

									$link_tag = in_array( 'image', $cta_link_to, true ) ? 'a' : 'span';
									?>
									<<?php echo esc_attr( $link_tag ); ?> href="<?php the_permalink(); ?>">
									<img src="<?php echo esc_url( $image_url ); ?>" />
									</<?php echo esc_attr( $link_tag ); ?>>
								</div>

								<div class="ec-post-content-wrap">
									<?php
									if ( $cta_text ) :
										$link_tag = in_array( 'title', $cta_link_to, true ) ? 'a' : 'span';
										?>
										<h3 class="ec-post-title">
											<<?php echo esc_attr( $link_tag ); ?> href="<?php the_permalink(); ?>"><?php the_title(); ?></<?php echo esc_attr( $link_tag ); ?>>
										</h3>
									<?php endif; ?>
									<div class="ec-post-meta">
										<span class="ec-post-posted-on"><?php the_date(); ?></span>
										<span class="ec-post-comments"><?php comments_number(); ?></span>
										<span class="ec-post-category"><?php the_category(); ?></span>
									</div>

									<?php if ( $show_excerpt ) : ?>
										<div class="ec-post-excerpt">
											<?php the_excerpt(); ?>
										</div>
									<?php endif; ?>

									<a href="<?php the_permalink(); ?>" class="ec-post-read-more <?php echo ( 'button' === $cta_type ) ? esc_attr( 'ec-cta-btn' ) : ''; ?>">
										<?php echo esc_html( $cta_text ); ?>
									</a>
								</div>
							</article>
						<?php endwhile; ?>
					</div>

					<!-- Pagination -->
					<?php if ( 'both' === $settings['navigation'] || 'dots' === $settings['navigation'] ) : ?>
						<div class="ec-pagination">
						</div>

						<!-- Navigation -->
						<?php if ( 'both' === $settings['navigation'] || 'arrows' === $settings['navigation'] ) : ?>
							<div class="ec-nav">
								<span class="ec-nav-prev">
									<i class="fa <?php echo esc_attr( $arrow_left_icon ); ?>"></i>
								</span>
								<span class="ec-nav-next">
									<i class="fa <?php echo esc_attr( $arrow_right_icon ); ?>"></i>
								</span>
							</div> <!-- /.ec-nav -->
						<?php endif; ?>
					<?php endif; ?>
				</div> <!-- /.ec-post-slider -->
			</div>
			<?php
			// No posts found
		endif;

		// Restore original post data
		wp_reset_postdata();
	}
}
