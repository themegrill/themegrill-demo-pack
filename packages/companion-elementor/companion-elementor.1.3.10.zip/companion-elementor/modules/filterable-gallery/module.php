<?php

namespace CompanionElementor\Modules\FilterableGallery;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Filterable_Gallery',
		];
	}

	public function get_name() {
		return 'filterable-gallery';
	}

}
