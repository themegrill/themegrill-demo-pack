<?php

namespace CompanionElementor\Modules\FilterableGallery\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Utils;

defined( 'ABSPATH' ) || exit;

class Filterable_Gallery extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-filterable-gallery';
	}

	public function get_title() {
		return __( 'Filterable Gallery', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-gallery-grid';
	}

	public function get_keywords() {
		return [ 'companion', 'filterable gallery', 'image', 'gallery', 'portfolio' ];
	}

	public function get_script_depends() {
		return array(
			'isotope',
			'imagesloaded',
			'magnific-popup',
		);
	}

	public function get_style_depends() {
		return array(
			'magnific-popup',
		);
	}

	protected function register_controls() {
		$this->register_general_controls();
		$this->register_controls_controls();
		$this->register_settings_controls();
		$this->register_style_gallery_controls();
		$this->register_style_controls_controls();
		$this->register_style_item_controls();
		$this->register_style_caption_controls();
		$this->register_style_btn_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'ec_fg_gallery_section',
			array(
				'label' => esc_html__( 'Gallery', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater_items = new Repeater();

		$repeater_items->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Image', 'companion-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$repeater_items->add_control(
			'category',
			array(
				'label'       => esc_html__( 'Category', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Category', 'companion-elementor' ),
				'description' => esc_html__( 'Set the category as needed for filtering the gallery items. You can set the category added via Controls > Filter Category Lists. And if you want multiple category for it then, you can separate them via comma.', 'companion-elementor' ),
				'label_block' => true,
			)
		);

		$repeater_items->add_control(
			'title',
			array(
				'label'       => esc_html__( 'Title', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Title', 'companion-elementor' ),
				'label_block' => true,
			)
		);

		$repeater_items->add_control(
			'description',
			array(
				'label'   => esc_html__( 'Description', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'companion-elementor' ),
			)
		);

		$repeater_items->add_control(
			'enable_lightbox_button',
			array(
				'label'        => esc_html__( 'Lightbox Button?', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$repeater_items->add_control(
			'enable_link_button',
			array(
				'label'        => esc_html__( 'Link Button?', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$repeater_items->add_control(
			'link',
			array(
				'label'         => esc_html__( 'External Link', 'companion-elementor' ),
				'type'          => Controls_Manager::URL,
				'show_external' => true,
				'default'       => array(
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				),
				'condition'     => array(
					'enable_link_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'items',
			array(
				'label'       => esc_html__( 'Items', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater_items->get_controls(),
				'default'     => array(
					array(
						'category' => esc_html__( 'Category A', 'companion-elementor' ),
						/* Translators: %s number. */
						'title'    => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 1 ),
					),
					array(
						'category' => esc_html__( 'Category B', 'companion-elementor' ),
						/* Translators: %s number. */
						'title'    => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 2 ),
					),
					array(
						'category' => esc_html__( 'Category A', 'companion-elementor' ),
						/* Translators: %s number. */
						'title'    => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 3 ),
					),
					array(
						'category' => esc_html__( 'Category B', 'companion-elementor' ),
						/* Translators: %s number. */
						'title'    => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 4 ),
					),
					array(
						'category' => esc_html__( 'Category A', 'companion-elementor' ),
						/* Translators: %s number. */
						'title'    => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 5 ),
					),
					array(
						'category' => esc_html__( 'Category B', 'companion-elementor' ),
						/* Translators: %s number. */
						'title'    => sprintf( esc_html__( 'Title %s', 'companion-elementor' ), 6 ),
					),
				),
				'title_field' => '{{{ title }}}',
			)
		);

		$this->end_controls_section();
	}

	private function register_controls_controls() {
		$this->start_controls_section(
			'ec_fg_controls_section',
			array(
				'label' => esc_html__( 'Controls', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'enable_filter',
			array(
				'label'        => esc_html__( 'Filterable Image Gallery', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'first_tab_label',
			array(
				'label'     => esc_html__( 'First Tab Label', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'All', 'companion-elementor' ),
				'condition' => array(
					'enable_filter' => 'yes',
				),
				'separator' => 'after',
			)
		);

		$repeater_filter_category = new Repeater();

		$repeater_filter_category->add_control(
			'category_name',
			array(
				'label'   => esc_html__( 'Category Name', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Category', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'categories',
			array(
				'label'       => esc_html__( 'Categories', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater_filter_category->get_controls(),
				'default'     => array(
					array(
						'category_name' => esc_html__( 'Category A', 'companion-elementor' ),
					),
					array(
						'category_name' => esc_html__( 'Category B', 'companion-elementor' ),
					),
				),
				'title_field' => '{{{ category_name }}}',
				'condition'   => array(
					'enable_filter' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_settings_controls() {
		$this->start_controls_section(
			'ec_fg_settings_section',
			array(
				'label' => esc_html__( 'Settings', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'    => 'image',
				'default' => 'full',
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => esc_html__( 'Layout', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'fitRows',
				'options' => array(
					'fitRows' => esc_html__( 'Grid', 'companion-elementor' ),
					'masonry' => esc_html__( 'Masonry', 'companion-elementor' ),
				),
			)
		);

		$column = range( 1, 6 );
		$column = array_combine( $column, $column );

		$this->add_responsive_control(
			'columns',
			array(
				'type'               => Controls_Manager::SELECT,
				'label'              => esc_html__( 'Columns', 'companion-elementor' ),
				'options'            => $column,
				'prefix_class'       => 'ec-col-%s-',
				'render_type'        => 'template',
				'frontend_available' => true,
				'desktop_default'    => 3,
				'tablet_default'     => 2,
				'mobile_default'     => 1,
			)
		);

		$this->add_control(
			'lightbox_slider',
			array(
				'label'        => esc_html__( 'Lightbox Slider', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'link_context',
			array(
				'label'   => esc_html__( 'Link Context', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'button',
				'options' => array(
					'image'  => esc_html__( 'Image', 'companion-elementor' ),
					'button' => esc_html__( 'Button', 'companion-elementor' ),
				),
			)
		);

		$this->add_control(
			'image_link_target',
			array(
				'label'     => esc_html__( 'Link Target', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'lightbox',
				'options'   => array(
					'lightbox'    => esc_html__( 'Lightbox', 'companion-elementor' ),
					'custom_link' => esc_html__( 'Custom Link', 'companion-elementor' ),
				),
				'condition' => array(
					'link_context' => 'image',
				),
			)
		);

		$this->add_control(
			'lightbox_icon_v5',
			array(
				'label'            => esc_html__( 'Lightbox Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'lightbox_icon',
				'default'          => [
					'value'   => 'fa fa-search-plus',
					'library' => 'solid',
				],
				'condition'        => array(
					'link_context' => 'button',
				),
			)
		);

		$this->add_control(
			'link_icon_v5',
			array(
				'label'            => esc_html__( 'Link Icon', 'companion-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'link_icon',
				'default'          => [
					'value'   => 'fa fa-link',
					'library' => 'solid',
				],
				'condition'        => array(
					'link_context' => 'button',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_gallery_controls() {
		$this->start_controls_section(
			'ec_fg_style_section',
			array(
				'label' => esc_html__( 'Gallery', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'column_gap',
			array(
				'label'      => esc_html__( 'Column Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'rem',
					'em',
				),
				'range'      => array(
					'px'  => array(
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					),
					'rem' => array(
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.1,
					),
					'em'  => array(
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.1,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-fg-item'       => 'padding-left: calc( {{SIZE}}{{UNIT}}/2 ); padding-right: calc( {{SIZE}}{{UNIT}}/2 );',
					'{{WRAPPER}} .ec-fg-items-wrap' => 'margin-left: calc( -{{SIZE}}{{UNIT}}/2 ); margin-right: calc( -{{SIZE}}{{UNIT}}/2 );',
				),
			)
		);

		$this->add_responsive_control(
			'row_gap',
			array(
				'label'       => esc_html__( 'Row Gap', 'companion-elementor' ),
				'type'        => Controls_Manager::SLIDER,
				'render_type' => 'template',
				'size_units'  => array(
					'px',
					'rem',
					'em',
				),
				'range'       => array(
					'px'  => array(
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					),
					'rem' => array(
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.1,
					),
					'em'  => array(
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.1,
					),
				),
				'selectors'   => array(
					'{{WRAPPER}} .ec-fg-item .ec-item-inner' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'hover_effects',
			array(
				'label'   => esc_html__( 'Hover Effects', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style 1', 'companion-elementor' ),
					'2' => esc_html__( 'Style 2', 'companion-elementor' ),
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_controls_controls() {
		$this->start_controls_section(
			'ec_fg_controls_style_section',
			array(
				'label' => esc_html__( 'Controls', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'controls_alignment',
			array(
				'label'        => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					),
				),
				'default'      => 'left',
				'prefix_class' => 'ec-fg-controls--',
			)
		);

		$this->add_responsive_control(
			'controls_margin',
			array(
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-fg-controls' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'control_heading',
			array(
				'label'     => esc_html__( 'Control', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'controls_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-fg-controls li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'active_control_heading',
			array(
				'label'     => esc_html__( 'Active Control', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'active_control_typography',
				'selector' => '{{WRAPPER}} .ec-fg-controls li.active',
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'active_control_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-fg-controls li.active',
			)
		);

		$this->add_responsive_control(
			'active_control_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-fg-controls li.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'active_control_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-fg-controls li.active',
			)
		);

		$this->start_controls_tabs(
			'active_control_tabs'
		);

		$this->start_controls_tab(
			'active_control_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'active_control_normal_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-fg-controls li.active' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'active_control_normal_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-fg-controls li.active',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'active_control_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'active_control_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-fg-controls li.active:hover' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'active_control_hover_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-fg-controls li.active:hover',
			)
		);

		$this->add_control(
			'active_control_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-fg-controls li.active:hover' => 'border-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'normal_control_heading',
			array(
				'label'     => esc_html__( 'Normal Control', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'normal_control_typography',
				'selector' => '{{WRAPPER}} .ec-fg-controls li',
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'normal_control_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-fg-controls li',
			)
		);

		$this->add_responsive_control(
			'normal_control_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-fg-controls li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'normal_control_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-fg-controls li',
			)
		);

		$this->start_controls_tabs(
			'normal_control_tabs'
		);

		$this->start_controls_tab(
			'normal_control_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'normal_control_normal_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-fg-controls li' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'normal_control_normal_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-fg-controls li',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'normal_control_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'hover_control_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-fg-controls li:hover' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'normal_control_hover_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-fg-controls li:hover',
			)
		);

		$this->add_control(
			'normal_control_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-fg-controls li:hover' => 'border-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_item_controls() {
		$this->start_controls_section(
			'ec_fg_item_style_section',
			array(
				'label' => esc_html__( 'Item', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'overlay_color',
			array(
				'label'     => esc_html__( 'Overlay Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-fg-item .overlay' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'item_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-fg-item .ec-item-inner',
			)
		);

		$this->add_responsive_control(
			'item_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-fg-item .ec-item-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'item_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-fg-item .ec-item-inner',
			)
		);

		$this->end_controls_section();
	}

	private function register_style_caption_controls() {
		$this->start_controls_section(
			'ec_fg_caption_area_style_section',
			array(
				'label' => esc_html__( 'Caption Area', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'caption_alignment',
			array(
				'label'        => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					),
				),
				'default'      => 'left',
				'prefix_class' => 'ec-fg-caption-align--',
			)
		);

		$this->add_control(
			'caption_title_heading',
			array(
				'label'     => esc_html__( 'Title', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'caption_title_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-caption-content .ec-title' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'caption_title_typography',
				'selector' => '{{WRAPPER}} .ec-caption-content .ec-title',
			)
		);

		$this->add_responsive_control(
			'caption_title_margin',
			array(
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-caption-content .ec-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'caption_desc_heading',
			array(
				'label'     => esc_html__( 'Description', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'caption_desc_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-caption-content .ec-description' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'caption_desc_typography',
				'selector' => '{{WRAPPER}} .ec-caption-content .ec-description',
			)
		);

		$this->add_responsive_control(
			'caption_desc_margin',
			array(
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-caption-content .ec-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_btn_controls() {
		$this->start_controls_section(
			'ec_fg_btn_style_section',
			array(
				'label' => esc_html__( 'Icon Button', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'btn_margin',
			array(
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-fg-btn a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'btn_size',
			array(
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'rem',
					'em',
				),
				'range'      => array(
					'px'  => array(
						'min'  => 0,
						'max'  => 96,
						'step' => 1,
					),
					'rem' => array(
						'min'  => 0,
						'max'  => 6,
						'step' => 0.01,
					),
					'em'  => array(
						'min'  => 0,
						'max'  => 6,
						'step' => 0.01,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-fg-btn > a'   => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-fg-btn > a i' => 'line-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'btn_icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'rem',
					'em',
				),
				'range'      => array(
					'px'  => array(
						'min'  => 0,
						'max'  => 48,
						'step' => 1,
					),
					'rem' => array(
						'min'  => 0,
						'max'  => 3,
						'step' => 0.01,
					),
					'em'  => array(
						'min'  => 0,
						'max'  => 3,
						'step' => 0.01,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-fg-btn > a i' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'           => 'btn_border',
				'fields_options' => array(
					'border' => array(
						'default' => 'solid',
					),
					'width'  => array(
						'default' => array(
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						),
					),
					'color'  => array(
						'default' => '#e9ecef',
					),
				),
				'selector'       => '{{WRAPPER}} .ec-fg-btn > a',
			)
		);

		$this->add_responsive_control(
			'btn_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-fg-btn > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'btn_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-fg-btn > a',
			)
		);

		$this->start_controls_tabs(
			'btn_tabs'
		);

		$this->start_controls_tab(
			'btn_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'btn_normal_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-fg-btn > a i' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'btn_normal_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-fg-btn > a',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'btn_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'btn_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-fg-btn > a:hover .fa' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'btn_hover_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-fg-btn > a:hover',
			)
		);

		$this->add_control(
			'btn_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-fg-btn > a:hover' => 'border-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/filterable-gallery-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings        = $this->get_settings_for_display();
		$image_size      = $settings['image_size'];
		$layout          = $settings['layout'];
		$lightbox_icon   = $settings['lightbox_icon_v5'];
		$link_icon       = $settings['link_icon_v5'];
		$enable_filter   = $settings['enable_filter'];
		$first_tab_label = $settings['first_tab_label'];
		$categories      = $settings['categories'];
		$lightbox_slider = $settings['lightbox_slider'];
		$items           = $settings['items'];
		$effects         = $settings['hover_effects'];

		// Portfolio custom JS options.
		$options                  = array();
		$options['masonryLayout'] = $layout;
		$options['photoGallery']  = $lightbox_slider;
		?>

		<div class="ec-fg-wrapper">

			<div class="ec-fg ec-fg-effect__style-<?php echo esc_attr( $effects ); ?>" data-gallery_option=<?php echo wp_json_encode( $options ); ?>>

				<!-- Controls -->
				<?php if ( 'yes' === $enable_filter ) : ?>
					<ul class="ec-fg-controls">
						<?php if ( $first_tab_label ) : ?>
							<li class="active" data-filter="*">
								<?php echo esc_html( $first_tab_label ); ?>
							</li>
						<?php endif; ?>

						<?php foreach ( $categories as $settings_category_list ) : ?>
							<?php
							$category_filter_classes = $settings_category_list['category_name'];
							$category_filter_class   = strtolower( $category_filter_classes );
							$category_filter_class   = str_replace( ' ', '-', $category_filter_class );
							$category_filter_class   = str_replace( ',-', ', .', $category_filter_class );
							?>

							<li data-filter=".<?php echo esc_attr( $category_filter_class ); ?>">
								<?php echo esc_html( $settings_category_list['category_name'] ); ?>
							</li>
						<?php endforeach; ?>
					</ul> <!-- /.ec-fg-controls -->
				<?php endif; ?>

				<!-- Gallery -->
				<div class="ec-fg-items-wrap">
					<?php foreach ( $items as $item ) : ?>
						<?php
						$category_classes = $item['category'];
						$category_class   = strtolower( $category_classes );
						$category_class   = str_replace( ' ', '-', $category_class );
						$category_class   = str_replace( ',-', ' ', $category_class );
						?>

						<div class="ec-fg-item <?php echo esc_attr( $category_class ); ?>">
							<div class="ec-item-inner">
								<?php if ( $item['image']['url'] ) : ?>
									<?php
									$image_id = $item['image']['id'];

									if ( 'custom' === $image_size ) {
										$image_src = Group_Control_Image_Size::get_attachment_image_src( $image_id, 'image', (array) $settings );
									} else {
										$image_src = wp_get_attachment_image_src( $image_id, $image_size );
										$image_src = ! empty( $image_src ) ? $image_src[0] : '';
									}

									if ( ! $image_id ) {
										$image_src = $item['image']['url'];
									}
									?>

									<?php if ( ( 'yes' === $item['enable_lightbox_button'] ) && ( 'image' === $settings['link_context'] ) ) : ?>

										<?php
										$link_target = ( 'custom_link' === $settings['image_link_target'] ) ? $item['link']['url'] : $image_src;
										$link_class  = ( 'lightbox' === $settings['image_link_target'] ) ? 'lightbox lightbox--image' : '';
										?>
										<a data-effect="mfp-zoom-in" href="<?php echo esc_url( $link_target ); ?>"
											class="<?php echo esc_attr( $link_class ); ?>"
											data-elementor-open-lightbox="no"></a>
									<?php endif; ?>

									<?php if ( $image_src ) : ?>
										<div class="ec-image">
											<img src="<?php echo esc_url( $image_src ); ?>"
												alt="<?php echo esc_attr( $item['title'] ); ?>">
										</div> <!-- /.ec-image -->
									<?php endif; ?>

									<div class="ec-fg-caption">
										<div class="overlay"></div>

										<div class="ec-caption-content">
											<?php if ( $item['title'] ) : ?>
												<div class="ec-title"><?php echo esc_html( $item['title'] ); ?></div>
											<?php endif; ?>

											<?php if ( $item['description'] ) : ?>
												<div class="ec-description"><?php echo esc_html( $item['description'] ); ?></div>
											<?php endif; ?>

											<?php if ( 'button' === $settings['link_context'] && ( 'yes' === $item['enable_lightbox_button'] ) || ( 'yes' === $item['enable_link_button'] ) ) : ?>
												<div class="ec-fg-btn">
													<?php if ( 'yes' === $item['enable_lightbox_button'] ) : ?>
														<a data-effect="mfp-zoom-in"
															href="<?php echo esc_url( $image_src ); ?>" class="lightbox"
															data-elementor-open-lightbox="no">
															<?php
															$migrated = isset( $settings['__fa4_migrated']['lightbox_icon_v5'] );
															$is_new   = ! array_key_exists( 'lightbox_icon', $settings );

															if ( $is_new || $migrated ) :
																Icons_Manager::render_icon( $lightbox_icon, [ 'aria-hidden' => 'true' ] );
															else :
																?>
																<i class="<?php echo ( is_array( $settings['lightbox_icon'] ) ? $settings['lightbox_icon']['value'] : $settings['lightbox_icon'] ); ?>" aria-hidden="true"></i>
															<?php endif; ?>
														</a>
													<?php endif; ?>

													<?php if ( 'yes' === $item['enable_link_button'] && $item['link']['url'] ) : ?>
														<a class="link"
															href="<?php echo esc_url( $item['link']['url'] ); ?>"
															<?php echo( ! empty( $item['link']['is_external'] ) ? 'target="_blank"' : '' ); ?>
															<?php echo( ! empty( $item['link']['nofollow'] ) ? 'rel="nofollow"' : '' ); ?>>
															<?php
															$migrated = isset( $settings['__fa4_migrated']['link_icon_v5'] );
															$is_new   = ! array_key_exists( 'link_icon', $settings );

															if ( $is_new || $migrated ) :
																Icons_Manager::render_icon( $link_icon, [ 'aria-hidden' => 'true' ] );
															else :
																?>
																<i class="<?php echo ( is_array( $settings['link_icon'] ) ? $settings['link_icon']['value'] : $settings['link_icon'] ); ?>" aria-hidden="true"></i>
															<?php endif; ?>
														</a>
													<?php endif; ?>
												</div> <!-- /.ec-fg-btn -->
											<?php endif; ?>
										</div> <!-- /.ec-caption-content -->
									</div> <!-- /.ec-fg-caption -->
								<?php endif; ?>
							</div> <!-- /.ec-item-inner -->
						</div> <!-- /.ec-fg-item -->
					<?php endforeach; ?>
				</div>
			</div> <!-- /.ec-fg -->
		</div> <!-- /.ec-fg-wrapper -->

		<?php
	}
}
