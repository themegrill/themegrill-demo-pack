<?php

namespace CompanionElementor\Modules\Posts;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Posts',
		];
	}

	public function get_name() {
		return 'posts';
	}

}
