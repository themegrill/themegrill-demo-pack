<?php
defined( 'ABSPATH' ) || exit;

global $post;

if ( empty( $post ) ) {
	return;
}
?>
<article class="ec-post ec-grid-item">
	<?php $this->render_featured_image(); ?>

	<div class="ec-post__content-wrap">
		<?php $this->render_title(); ?>

		<?php if ( ! empty( $this->get_control_value( 'meta_select' ) ) ) : ?>
			<div class="ec-post__meta">
				<?php $this->render_date(); ?>
				<?php $this->render_comments_link(); ?>
				<?php
				if ( ! empty( get_the_terms( get_the_ID(), 'category' ) ) ) :
					$this->render_terms( 'category', true );
				endif;
				?>
				<?php
				if ( ! empty( get_the_terms( get_the_ID(), 'post_tag' ) ) ) :
					$this->render_terms( 'tag', true );
				endif;
				?>
			</div>
		<?php endif; ?>

		<?php $this->render_excerpt(); ?>

		<?php $this->render_cta(); ?>
	</div>
</article>
