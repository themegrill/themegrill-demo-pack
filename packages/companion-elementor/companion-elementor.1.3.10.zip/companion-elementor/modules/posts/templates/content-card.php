<?php
defined( 'ABSPATH' ) || exit;

global $post;

if ( empty( $post ) ) {
	return;
}
?>
<article class="ec-post ec-grid-item">
	<div class="ec-post__card">
		<?php $this->render_featured_image(); ?>

		<?php
		$user_id = get_the_author_meta( 'ID' );
		$user    = get_user_by( 'ID', $user_id );

		if ( has_post_thumbnail() ) :
			?>
			<span class="author">
				<?php echo get_avatar( $user_id, '120', '', get_the_author_meta( 'display_name' ) ); ?>
			</span>
			<?php
			$this->render_terms( 'category' );
		endif;
		?>

		<div class="ec-post__content-wrap">
			<?php $this->render_title(); ?>

			<?php $this->render_excerpt(); ?>

			<?php $this->render_cta(); ?>
		</div> <!-- /.ec-post__content-wrap -->

		<?php if ( ! empty( $this->get_control_value( 'meta_select' ) ) ) : ?>
			<div class="ec-post__meta">
				<?php $this->render_date(); ?>
				<?php $this->render_comments_link(); ?>
				<?php
				if ( ! empty( get_the_terms( get_the_ID(), 'post_tag' ) ) ) :
					$this->render_terms( 'tag', true );
				endif;
				?>
			</div>
		<?php endif; ?>

	</div> <!-- /.ec-post__card -->
</article>
