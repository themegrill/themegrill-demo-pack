<?php

namespace CompanionElementor\Modules\Posts\Widgets;

use CompanionElementor\Base\Base_Widget;
use CompanionElementor\Classes\Utils;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit;

abstract class Posts_Base extends Base_Widget {

	protected $query = null;

	protected $_has_template_content = false;

	public function get_icon() {
		return 'ce-widget-icon eicon-post-list';
	}

	public function get_script_depends() {
		return [ 'imagesloaded' ];
	}

	public function render() {
	}

	abstract public function query_posts();

	public function get_query() {
		return $this->query;
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_general',
			[
				'label' => __( 'General', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->end_controls_section();

		$this->register_query_controls();
		$this->register_helpful_information();
	}

	private function register_query_controls() {
		$this->start_controls_section(
			'section_query',
			[
				'label' => __( 'Query', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$post_types = Utils::get_post_types();

		$this->add_control(
			'post_type',
			array(
				'label'   => __( 'Post Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post',
				'options' => $post_types,
			)
		);

		/* Filters */
		foreach ( $post_types as $pt_key => $type ) {

			$taxonomies = Utils::get_taxonomies( $pt_key );

			if ( ! empty( $taxonomies ) ) {

				foreach ( $taxonomies as $tax_slug => $tax ) {

					$terms = get_terms( $tax_slug );

					$related_terms = [];

					if ( ! empty( $terms ) ) {

						foreach ( $terms as $t_index => $t_obj ) {

							$related_terms[ $t_obj->slug ] = $t_obj->name;
						}

						// Filter type.
						$this->add_control(
							$pt_key . '_' . $tax_slug . '_filter',
							[
								/* translators: %s Label */
								'label'       => sprintf( __( '%s Filter', 'companion-elementor' ), $tax->label ),
								'type'        => Controls_Manager::SELECT,
								'default'     => 'IN',
								'label_block' => true,
								'options'     => [
									'IN'     => __( 'Include', 'companion-elementor' ),
									'NOT IN' => __( 'Exclude', 'companion-elementor' ),
								],
								'condition'   => [
									'post_type' => $pt_key,
								],
							]
						);

						// Choose terms.
						$this->add_control(
							'terms_' . $pt_key . '_' . $tax_slug . '_choices',
							[
								/* translators: %s label */
								'label'       => sprintf( __( '%s', 'companion-elementor' ), $tax->label ),
								'type'        => Controls_Manager::SELECT2,
								'multiple'    => true,
								'default'     => '',
								'label_block' => true,
								'options'     => $related_terms,
								'condition'   => [
									'post_type' => $pt_key,
								],
								'separator'   => 'after',
							]
						);

					}
				}
			}
		}

		$this->add_control(
			'author_filter',
			array(
				'label'     => esc_html__( 'Author Filter', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'author__in',
				'options'   => array(
					'author__in'     => esc_html__( 'Include', 'companion-elementor' ),
					'author__not_in' => esc_html__( 'Exclude', 'companion-elementor' ),
				),
				'separator' => 'before',
			)
		);

		$users = Utils::get_users();

		$this->add_control(
			'author',
			array(
				'label'    => esc_html__( 'Author', 'companion-elementor' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'options'  => $users,
			)
		);

		$this->add_control(
			'ignore_sticky',
			array(
				'label'        => esc_html__( 'Ignore Sticky Post', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'exclude_current_post',
			array(
				'label'        => esc_html__( 'Exclude Current Post', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/posts-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}
}
