<?php

namespace CompanionElementor\Modules\Posts\Widgets;

use CompanionElementor\Modules\Posts\Skins;

defined( 'ABSPATH' ) || exit;

class Posts extends Posts_Base {

	public function get_name() {
		return 'elementor-companion-posts';
	}

	public function get_title() {
		return __( 'Posts', 'companion-elementor' );
	}

	public function get_keywords() {
		return [ 'companion', 'posts', 'cpt', 'custom post type', 'blog' ];
	}

	protected function register_skins() {
		$this->add_skin( new Skins\Skin_Classic( $this ) );
		$this->add_skin( new Skins\Skin_Card( $this ) );
	}

	protected function register_controls() {
		parent::register_controls();
	}

	public function query_posts() {
	}

}
