<?php

namespace CompanionElementor\Modules\Posts\Skins;

use CompanionElementor\Modules\Posts\TemplateBlocks\Skin_Init;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

defined( 'ABSPATH' ) || exit;

class Skin_Card extends Skin_Base {

	public function get_id() {
		return 'card';
	}

	public function get_title() {
		return __( 'Card', 'companion-elementor' );
	}

	protected function _register_controls_actions() {
		parent::_register_controls_actions();

		add_action(
			'elementor/element/elementor-companion-posts/card_section_style_box/before_section_end',
			[
				$this,
				'update_style_box_controls',
			]
		);

		add_action(
			'elementor/element/elementor-companion-posts/card_section_style_meta/before_section_end',
			[
				$this,
				'update_style_meta_controls',
			]
		);

		add_action(
			'elementor/element/elementor-companion-posts/card_section_style_image/before_section_end',
			[
				$this,
				'update_style_image_controls',
			]
		);
	}

	public function update_style_box_controls() {

		$this->update_control(
			'box_bg_color',
			[
				'selectors' => [
					'{{WRAPPER}} .ec-post__card' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->update_control(
			'box_padding',
			[
				'selectors' => [
					'{{WRAPPER}} .ec-post__content-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'box_border',
				'label'    => __( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-post__card',
			]
		);

		$this->add_responsive_control(
			'box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-post__card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'equal_height',
			[
				'label'        => __( 'Equal Height', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'prefix_class' => 'ec-post__equal-height-',
			]
		);

		$this->start_controls_tabs(
			'tabs_style_box'
		);

		$this->start_controls_tab(
			'tab_normal_box',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'box_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-post__card' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'box_shadow_enable',
			[
				'label'        => __( 'Box Shadow', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'prefix_class' => 'ec-post__shadow-',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'box_shadow',
				'selector'  => '{{WRAPPER}} .ec-post__card',
				'condition' => [
					$this->get_control_id( 'box_shadow_enable' ) => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_hover_box',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'box_hover_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-post__card:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'hover_box_shadow',
				'selector' => '{{WRAPPER}} .ec-post__card:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();
	}

	public function update_style_meta_controls() {
		$this->add_control(
			'meta_border_top_size',
			[
				'label'     => __( 'Border Top Size', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-post__meta' => 'border-top-width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'meta_border_top_color',
			[
				'label'     => esc_html__( 'Border Top Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-post__meta' => 'border-top-color: {{VALUE}}',
				],
			]
		);
	}

	public function update_style_image_controls() {
		$this->update_control(
			'image_spacing',
			[
				'selectors' => [
					'{{WRAPPER}} .ec-post__thumbnail-link + .author' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_shrink',
			[
				'label'     => __( 'Shrink Image By', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'size' => 15,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ec-post__thumbnail-link'      => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-post__terms'               => 'left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}.ec-post__align-left .author'   => 'left: {{SIZE}}{{UNIT}}; align-self: flex-start;',
					'{{WRAPPER}}.ec-post__align-center .author' => 'left: unset; align-self: center',
					'{{WRAPPER}}.ec-post__align-right .author'  => 'left: unset; right: {{SIZE}}{{UNIT}}; align-self: flex-end;',
				],
			]
		);

		$this->add_control(
			'image_vertical_distance',
			[
				'label'     => __( 'Move Up Image By', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'size' => 30,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ec-post__thumbnail-link'                 => 'margin-top: -{{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ec-post__card'                           => 'margin-top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}.ec-post__equal-height-yes .ec-post__card' => 'height: calc(100% - {{SIZE}}{{UNIT}});',
				],
			]
		);

		$this->add_control(
			'heading_style_badge',
			[
				'label'     => __( 'Badge', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'badge_padding',
			[
				'label'     => esc_html__( 'Padding', 'companion-elementor' ),
				'type'      => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} .ec-post__terms' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'badge_margin',
			[
				'label'     => esc_html__( 'Margin', 'companion-elementor' ),
				'type'      => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} .ec-post__terms' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'badge_border_radius',
			array(
				'label'     => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'      => Controls_Manager::DIMENSIONS,
				'selectors' => array(
					'{{WRAPPER}} .ec-post__terms' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'badge_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-post__terms' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_color',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-post__terms' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'heading_style_avatar',
			[
				'label'     => __( 'Avatar', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'avatar_size',
			[
				'label'     => __( 'Size', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 30,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .author' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'avatar_border_radius',
			array(
				'label'     => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'      => Controls_Manager::DIMENSIONS,
				'selectors' => array(
					'{{WRAPPER}} .author' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);


	}

	public function render() {
		$settings = $this->parent->get_settings_for_display();

		$skin = Skin_Init::get_instance( $this->get_id() );

		echo $skin->render( $this->get_id(), $settings, $this->parent->get_id() );
	}
}
