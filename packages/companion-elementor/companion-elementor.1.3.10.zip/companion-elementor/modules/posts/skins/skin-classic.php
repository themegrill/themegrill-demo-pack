<?php

namespace CompanionElementor\Modules\Posts\Skins;

use CompanionElementor\Modules\Posts\TemplateBlocks\Skin_Init;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

defined( 'ABSPATH' ) || exit;

class Skin_Classic extends Skin_Base {

	public function get_id() {
		return 'classic';
	}

	public function get_title() {
		return __( 'Classic', 'companion-elementor' );
	}

	protected function _register_controls_actions() {
		parent::_register_controls_actions();

		add_action(
			'elementor/element/elementor-companion-posts/classic_section_style_box/before_section_end',
			[
				$this,
				'update_style_box_controls',
			]
		);
		add_action(
			'elementor/element/elementor-companion-posts/classic_section_style_meta/before_section_end',
			[
				$this,
				'update_style_meta_controls',
			]
		);
		add_action(
			'elementor/element/elementor-companion-posts/classic_section_style_image/after_section_start',
			[
				$this,
				'update_style_image_control',
			]
		);
	}

	public function update_style_image_control() {

		$this->add_responsive_control(
			'image_position',
			[
				'label'              => esc_html__( 'Position', 'companion-elementor' ),
				'type'               => Controls_Manager::CHOOSE,
				'default'            => 'top',
				'options'            => [
					'left'  => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'top'   => [
						'title' => esc_html__( 'Top', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'prefix_class'       => 'ec-posts%s--',
				'frontend_available' => true,
			]
		);
	}

	public function update_style_box_controls() {

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Content Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-post__content-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'box_border',
				'label'    => __( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-post',
			]
		);

		$this->add_responsive_control(
			'box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-post' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->start_controls_tabs(
			'tabs_style_box'
		);

		$this->start_controls_tab(
			'tab_normal_box',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'box_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-post' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_shadow',
				'selector' => '{{WRAPPER}} .ec-post',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_hover_box',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'box_hover_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-post:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'hover_box_shadow',
				'selector' => '{{WRAPPER}} .ec-post:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

	}

	public function update_style_meta_controls() {
		$this->add_control(
			'meta_spacing',
			[
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 6,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-post__meta' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

	}

	public function render() {
		$settings = $this->parent->get_settings_for_display();

		$skin = Skin_Init::get_instance( $this->get_id() );

		echo $skin->render( $this->get_id(), $settings, $this->parent->get_id() );
	}
}
