<?php

namespace CompanionElementor\Modules\Posts\Skins;

use Elementor\Controls_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Skin_Base as Elementor_Skin_Base;
use Elementor\Widget_Base;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

defined( 'ABSPATH' ) || exit;

abstract class Skin_Base extends Elementor_Skin_Base {

	protected function _register_controls_actions() {
		add_action(
			'elementor/element/elementor-companion-posts/section_general/before_section_end',
			array(
				$this,
				'register_sections_before',
			)
		);
		add_action(
			'elementor/element/elementor-companion-posts/section_query/after_section_end',
			array(
				$this,
				'register_sections',
			)
		);
	}

	public function register_sections_before( Widget_Base $widget ) {
		$this->parent = $widget;

		$this->add_control(
			'posts_per_page',
			[
				'label'   => __( 'Posts Per Page', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '6',
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label'                => __( 'Columns', 'companion-elementor' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 3,
				'tablet_default'       => 2,
				'mobile_default'       => 1,
				'options'              => [
					1 => esc_html__( '1', 'companion-elementor' ),
					2 => esc_html__( '2', 'companion-elementor' ),
					3 => esc_html__( '3', 'companion-elementor' ),
					4 => esc_html__( '4', 'companion-elementor' ),
					5 => esc_html__( '5', 'companion-elementor' ),
					6 => esc_html__( '6', 'companion-elementor' ),
				],
				'selectors_dictionary' => [
					1 => 'grid-template-columns: repeat(1, 1fr);',
					2 => 'grid-template-columns: repeat(2, 1fr);',
					3 => 'grid-template-columns: repeat(3, 1fr);',
					4 => 'grid-template-columns: repeat(4, 1fr);',
					5 => 'grid-template-columns: repeat(5, 1fr);',
					6 => 'grid-template-columns: repeat(6, 1fr);',
				],
				'selectors'            => [
					'{{WRAPPER}} .ec-grid' => '{{VALUE}};',
				],
			]
		);

		$this->register_title_controls();
		$this->register_meta_controls();
	}

	private function register_title_controls() {
		$this->add_control(
			'show_title',
			[
				'label'        => esc_html__( 'Title', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'companion-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
	}

	private function register_meta_controls() {
		$this->add_control(
			'meta_select',
			[
				'label'       => esc_html__( 'Meta', 'companion-elementor' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => [
					'date'     => esc_html__( 'Date', 'companion-elementor' ),
					'comment'  => esc_html__( 'Comment', 'companion-elementor' ),
					'category' => esc_html__( 'Category', 'companion-elementor' ),
					'tag'      => esc_html__( 'Tag', 'companion-elementor' ),
				],
				'default'     => [ 'date', 'comment', 'category' ],
			]
		);
	}

	public function register_sections( Widget_Base $widget ) {
		$this->parent = $widget;

		// Content controls.
		$this->register_excerpt_controls();
		$this->register_cta_controls();

		// Style controls.
		$this->register_style_layout_controls();
		$this->register_style_box_controls();
		$this->register_style_image_controls();
		$this->register_style_title_controls();
		$this->register_style_excerpt_controls();
		$this->register_style_meta_controls();
		$this->register_style_cta_controls();
	}

	private function register_excerpt_controls() {
		$this->start_controls_section(
			'section_excerpt',
			[
				'label' => __( 'Excerpt', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_excerpt',
			[
				'label'        => esc_html__( 'Excerpt', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'companion-elementor' ),
				'label_off'    => esc_html__( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'excerpt_length',
			[
				'label'   => __( 'Length', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 20,
			]
		);

		$this->add_control(
			'excerpt_more',
			[
				'label'   => __( 'More Text', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( ' ...', 'companion-elementor' ),
			]
		);

		$this->end_controls_section();
	}

	private function register_cta_controls() {
		$this->start_controls_section(
			'section_cta',
			[
				'label' => __( 'Call To Action', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'cta_link_to',
			[
				'label'       => esc_html__( 'Link To', 'companion-elementor' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => [
					'title' => esc_html__( 'Title', 'companion-elementor' ),
					'image' => esc_html__( 'Image', 'companion-elementor' ),
					'cta'   => esc_html__( 'CTA', 'companion-elementor' ),
				],
				'default'     => [ 'title', 'image' ],
			]
		);

		$this->add_control(
			'cta_type',
			[
				'label'     => esc_html__( 'Type', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'button',
				'options'   => array(
					'text'   => esc_html__( 'Text', 'companion-elementor' ),
					'button' => esc_html__( 'Button', 'companion-elementor' ),
					'box'    => esc_html__( 'Box', 'companion-elementor' ),
				),
				'condition' => array(
					$this->get_control_id( 'cta_link_to' ) => 'cta',
				),
			]
		);

		$this->add_control(
			'cta_text',
			[
				'label'       => esc_html__( 'Text', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Read More', 'companion-elementor' ),
				'label_block' => true,
				'condition'   => [
					$this->get_control_id( 'cta_link_to' ) => 'cta',
					$this->get_control_id( 'cta_type!' )   => 'box',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_layout_controls() {
		$this->start_controls_section(
			'section_style_layout',
			[
				'label' => __( 'Layout', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'column_gap',
			[
				'label'     => __( 'Columns Gap', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-grid' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'row_gap',
			[
				'label'     => __( 'Rows Gap', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-grid' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'align',
			[
				'label'        => __( 'Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'left'   => [
						'title' => __( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'selectors'    => [
					'{{WRAPPER}} .ec-posts-wrapper' => 'text-align: {{VALUE}};',
				],
				'prefix_class' => 'ec-post__align-',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_box_controls() {
		$this->start_controls_section(
			'section_style_box',
			[
				'label' => __( 'Box', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-post' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_image_controls() {
		$this->start_controls_section(
			'section_style_image',
			[
				'label' => __( 'Image', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'image_spacing',
			[
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-post__thumbnail-link' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumbnail_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
					'%',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 600,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 37.5,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 37.5,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => '',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-post__thumbnail-link img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-post__thumbnail-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_title_controls() {
		$this->start_controls_section(
			'section_style_title',
			[
				'label' => __( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			array_merge(
				[
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ec-post__title a' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_2,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_SECONDARY,
					],
				]
			)
		);

		$this->add_control(
			'title_hover_color',
			array_merge(
				[
					'label'     => esc_html__( 'Hover Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ec-post__title a:hover' => 'color: {{VALUE}}',
					],
				],
				class_exists( Color::class ) ? [
					'scheme' => [
						'type'  => Color::get_type(),
						'value' => Color::COLOR_2,
					],
				] : [
					'global' => [
						'default' => Global_Colors::COLOR_SECONDARY,
					],
				]
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array_merge(
				[
					'name'     => 'title_typography',
					'label'    => __( 'Typography', 'companion-elementor' ),
					'selector' => '{{WRAPPER}} .ec-post__title a',
				],
				class_exists( Typography::class ) ? [
					'scheme' => Typography::TYPOGRAPHY_1,
				] : [
					'global' => [
						'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
					],
				]
			)
		);

		$this->add_control(
			'title_spacing',
			[
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 6,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-post__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_excerpt_controls() {
		$this->start_controls_section(
			'section_style_excerpt',
			[
				'label' => __( 'Excerpt', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'excerpt_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-post__excerpt, {{WRAPPER}} .ec-post__excerpt p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array_merge(
				[
					'name'     => 'excerpt_typography',
					'label'    => __( 'Typography', 'companion-elementor' ),
					'selector' => '{{WRAPPER}} .ec-post__excerpt',
				],
				class_exists( Typography::class ) ? [
					'scheme' => Typography::TYPOGRAPHY_3,
				] : [
					'global' => [
						'default' => Global_Typography::TYPOGRAPHY_TEXT,
					],
				]
			)
		);

		$this->add_control(
			'excerpt_spacing',
			array(
				'label'     => __( 'Spacing', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 16,
				),
				'selectors' => array(
					'{{WRAPPER}} .ec-post__excerpt' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_meta_controls() {
		$this->start_controls_section(
			'section_style_meta',
			[
				'label' => __( 'Meta', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'meta_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-post__meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'meta_gap',
			[
				'label'     => __( 'Gap', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 4,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-post__meta span + span:before' => 'margin: 0 {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'meta_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-post__meta' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'meta_link_color',
			[
				'label'     => esc_html__( 'Link Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-post__meta a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'meta_link_hover_color',
			[
				'label'     => esc_html__( 'Link Hover Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-post__meta a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'meta_separator_color',
			[
				'label'     => esc_html__( 'Separator Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-post__meta span:before' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array_merge(
				[
					'name'     => 'meta_typography',
					'label'    => __( 'Typography', 'companion-elementor' ),
					'selector' => '{{WRAPPER}} .ec-post__meta',
				],
				class_exists( Typography::class ) ? [
					'scheme' => Typography::TYPOGRAPHY_2,
				] : [
					'global' => [
						'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
					],
				]
			)
		);

		$this->end_controls_section();
	}

	private function register_style_cta_controls() {
		$this->start_controls_section(
			'section_style_cta',
			array(
				'label'     => __( 'Call To Action', 'companion-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					$this->get_control_id( 'cta_link_to' ) => 'cta',
					$this->get_control_id( 'cta_type!' )   => 'box',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'cta_typography',
				'selector' => '{{WRAPPER}} .ec-post__read-more',
			)
		);

		$this->add_responsive_control(
			'cta_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-post__read-more.ec-cta-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					$this->get_control_id( 'cta_type' ) => 'button',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'      => 'cta_border',
				'selector'  => '{{WRAPPER}} .ec-post__read-more.ec-cta-btn',
				'condition' => array(
					$this->get_control_id( 'cta_type' ) => 'button',
				),
			)
		);

		$this->add_responsive_control(
			'cta_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-post__read-more.ec-cta-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					$this->get_control_id( 'cta_type' ) => 'button',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'      => 'cta_box_shadow',
				'label'     => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector'  => '{{WRAPPER}} .ec-post__read-more.ec-cta-btn',
				'condition' => array(
					$this->get_control_id( 'cta_type' ) => 'button',
				),
			)
		);

		$this->start_controls_tabs(
			'cta_tabs'
		);

		$this->start_controls_tab(
			'cta_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'cta_color',
			array_merge(
				array(
					'label'     => esc_html__( 'Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .ec-post__read-more' => 'color: {{VALUE}}',
					),
					'condition' => array(
						$this->get_control_id( 'cta_type' ) => 'text',
					),
				),
				class_exists( Color::class ) ? array(
					'scheme' => array(
						'type'  => Color::get_type(),
						'value' => Color::COLOR_3,
					),
				) : array(
					'global' => array(
						'default' => Global_Colors::COLOR_TEXT,
					),
				)
			)
		);

		$this->add_control(
			'cta_btn_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => array(
					'{{WRAPPER}} .ec-post__read-more' => 'color: {{VALUE}}',
				),
				'condition' => array(
					$this->get_control_id( 'cta_type' ) => 'button',
				),
			)
		);

		$this->add_control(
			'cta_bg_color',
			array_merge(
				array(
					'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#269bd1',
					'selectors' => array(
						'{{WRAPPER}} .ec-post__read-more.ec-cta-btn' => 'background-color: {{VALUE}}',
					),
					'condition' => array(
						$this->get_control_id( 'cta_type' ) => 'button',
					),
				),
				class_exists( Color::class ) ? array(
					'scheme' => array(
						'type'  => Color::get_type(),
						'value' => Color::COLOR_4,
					),
				) : array(
					'global' => array(
						'default' => Global_Colors::COLOR_ACCENT,
					),
				)
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cta_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'cta_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-post__read-more:hover' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'cta_hover_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1e7ba6',
				'selectors' => array(
					'{{WRAPPER}} .ec-post__read-more.ec-cta-btn:hover' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					$this->get_control_id( 'cta_type' ) => 'button',
				),
			)
		);

		$this->add_control(
			'cta_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-post__read-more:hover' => 'border-color: {{VALUE}}',
				),
				'condition' => array(
					$this->get_control_id( 'cta_type' ) => 'button',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}
}
