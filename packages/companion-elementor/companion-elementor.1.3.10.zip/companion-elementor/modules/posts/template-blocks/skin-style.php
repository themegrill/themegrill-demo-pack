<?php

namespace CompanionElementor\Modules\Posts\TemplateBlocks;

use Elementor\Group_Control_Image_Size;

defined( 'ABSPATH' ) || exit;

abstract class Skin_Style {

	public static $settings;
	public static $skin;
	public static $id;
	public static $query_obj;
	public static $query;


	public function render( $style, $settings, $id ) {

		self::$settings  = $settings;
		self::$skin      = $style;
		self::$id        = $id;
		self::$query_obj = new Build_Post_Query( $style, $settings, '' );

		self::$query_obj->query_posts();
		self::$query = self::$query_obj->get_query();

		$wrapper_class =  $this->get_wrapper_class();
		?>
		<div class="ec-posts-wrapper <?php echo esc_attr( $wrapper_class ); ?>">
			<?php $this->get_content(); ?>
		</div> <!-- /.ec-posts-wrapper -->
		<?php
	}

	public function render_title() {
		if ( $this->get_control_value( 'show_title' ) ) {
			$link_tag = in_array( 'title', $this->get_control_value( 'cta_link_to' ), true ) ? 'a' : 'span';
			?>
			<h3 class="ec-post__title"><<?php echo esc_attr( $link_tag ); ?> href="<?php the_permalink(); ?>"><?php the_title(); ?></<?php echo esc_attr( $link_tag ); ?>></h3>
			<?php
		}
	}

	public function get_content() {
		$posts_query = self::$query;

		if ( $posts_query->have_posts() ) {
			?>
			<div class="ec-grid">
				<?php
				while ( $posts_query->have_posts() ) {
					$posts_query->the_post();

					include COMPANION_ELEMENTOR_ABSPATH . '/modules/posts/templates/content-' . self::$skin . '.php';
				}
				?>
			</div> <!-- /.ec-grid -->
			<?php
		} else {
			echo 'No Post Found';
		}

		wp_reset_postdata();
	}

	public function render_date() {
		if ( ! in_array( 'date', $this->get_control_value( 'meta_select' ) ) ) {
			return;
		}

		echo '<span class="ec-post__posted-on">' . get_the_date() . '</span>';
	}

	public function render_comments_link() {
		if ( in_array( 'comment', $this->get_control_value( 'meta_select' ) )
			 && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			echo '<span class="ec-post__comments">';
			comments_number();
			echo '</span>';
		}
	}

	public function render_terms( $tax, $link = false ) {
		if ( ! in_array( $tax, $this->get_control_value( 'meta_select' ) ) ) {
			return;
		}

		$tax_type = 'tag' === $tax ? 'post_tag' : $tax;

		$terms = get_the_terms( get_the_ID(), $tax_type );

		$output = '';

		$term_count = 1;

		$output .= '<span class="ec-post__' . esc_attr( $tax ) . '">';

		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				if ( $link ) {
					$output .= '<a href="' . get_term_link( $term->term_id ) . '">';
				}

				$output .= $term->name;

				if ( $link ) {
					$output .= '</a>';
				}

				if ( 1 === $term_count ) {
					break;
				}

				$term_count ++;
			}
		}

		$output .= '</span>';

		echo $output;
	}

	public function excerpt_length_filter() {
		return $this->get_control_value( 'excerpt_length' );
	}

	public function excerpt_more_filter() {
		return $this->get_control_value( 'excerpt_more' );
	}

	public function render_excerpt() {
		$excerpt_length = $this->get_control_value( 'excerpt_length' );

		if ( 0 === $excerpt_length || ! $this->get_control_value( 'show_excerpt' ) ) {
			return;
		}

		add_filter( 'excerpt_length', array( $this, 'excerpt_length_filter' ), 20 );
		add_filter( 'excerpt_more', array( $this, 'excerpt_more_filter' ), 20 );
		?>

		<div class="ec-post__excerpt">
			<?php the_excerpt(); ?>
		</div>

		<?php
		remove_filter( 'excerpt_length', 'excerpt_length_filter', 20 );
		remove_filter( 'excerpt_more', 'excerpt_more_filter', 20 );
	}

	public function render_cta() {
		$link_to  = $this->get_control_value( 'cta_link_to' );
		$cta_type = in_array( 'cta', $link_to ) ? $this->get_control_value( 'cta_type' ) : '';

		if ( empty( $cta_type ) ) {
			return;
		}

		$cta_text = ( 'text' === $cta_type || 'button' === $cta_type ) ? $this->get_control_value( 'cta_text' ) : '';
		?>
		<?php if ( 'box' === $cta_type ) : ?>
			<a class="ec-post__link" href="<?php the_permalink(); ?>"></a>
		<?php else : ?>
			<a href="<?php the_permalink(); ?>"
			   class="ec-post__read-more <?php echo ( 'button' === $cta_type ) ? esc_attr( 'ec-cta-btn' ) : ''; ?>">
				<?php echo esc_html( $cta_text ); ?>
			</a>
		<?php endif; ?>
		<?php
	}

	public function get_control_value( $control_id ) {
		if ( isset( self::$settings[ self::$skin . '_' . $control_id ] ) ) {
			return self::$settings[ self::$skin . '_' . $control_id ];
		} else {
			return null;
		}
	}

	public function render_featured_image() {

		$settings['image'] = array(
			'id' => get_post_thumbnail_id(),
		);

		$settings['image_size'] = $this->get_control_value( 'image_size' );

		$thumbnail_html = Group_Control_Image_Size::get_attachment_image_html( $settings );

		if ( ! $thumbnail_html ) {
			return;
		}

		$link_tag = in_array( 'image', $this->get_control_value( 'cta_link_to' ) ) ? 'a' : 'span';
		?>

		<<?php echo $link_tag; ?> href="<?php the_permalink(); ?>" class="ec-post__thumbnail-link">
		<?php echo $thumbnail_html; ?>
		</<?php echo $link_tag; ?>>
		<?php
	}

	public function get_wrapper_class() {
		return 'ec-post__skin-' . self::$skin;
	}

}
