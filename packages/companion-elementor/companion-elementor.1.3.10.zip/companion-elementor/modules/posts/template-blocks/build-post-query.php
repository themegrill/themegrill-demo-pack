<?php
namespace CompanionElementor\Modules\Posts\TemplateBlocks;

use CompanionElementor\Classes\Utils;

defined( 'ABSPATH' ) || exit;

class Build_Post_Query {

	public $query = '';

	public static $filter = '';

	public $settings = '';

	public $skin = '';

	public function __construct( $skin, $settings, $filter ) {

		$this->settings = $settings;
		$this->skin     = $skin;
		self::$filter   = str_replace( '.', '', $filter );
	}

	public function query_posts_args() {
		$skin_id  = $this->skin;
		$skin_id  = str_replace( '-', '_', $skin_id );
		$settings = $this->settings;

		return self::get_query_posts( $skin_id, $settings );
	}

	public static function get_query_posts( $control_id, $settings ) {
		if ( '' !== $control_id ) {
			$control_id = $control_id . '_';
		}

		$post_type     = ( isset( $settings['post_type'] ) && '' !== $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$ppp           = ( '' === $settings[ $control_id . 'posts_per_page' ] ) ? -1 : $settings[ $control_id . 'posts_per_page' ];
		$author_filter = $settings['author_filter'];
		$author        = $settings['author'];
		$ignore_sticky = ( isset( $settings['ignore_sticky'] ) && 'yes' === $settings['ignore_sticky'] ) ? true : false;

		$query_args = [
			'post_type'           => $post_type,
			'posts_per_page'      => $ppp,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => $ignore_sticky,
		];

		$taxonomies = Utils::get_taxonomies( $post_type );
		$tax_count  = 1;

		if ( ! empty( $taxonomies ) ) {
			$query_args['tax_query'] = array();

			foreach ( $taxonomies as $tax_key => $taxonomy ) {


				if ( ! $taxonomy->public || ! $taxonomy->show_ui ) {
					continue;
				}
				$terms = isset( $settings[ 'terms_' . $post_type . '_' . $tax_key . '_choices' ] ) ? $settings[ 'terms_' . $post_type . '_' . $tax_key . '_choices' ]  : '';

				if ( ! empty( $terms ) ) {

					$filter = $settings[ $post_type . '_' . $tax_key . '_filter' ];

					$query_args['tax_query'][] = array(
						'taxonomy' => $tax_key,
						'field'    => 'slug',
						'terms'    => $terms,
						'operator' => $filter,
					);
				}

				$tax_count++;
			}
		}

		if ( ! empty( $author ) ) {
			$query_args[ $author_filter ] = $author;
		}

		if ( 'yes' === $settings['exclude_current_post'] ) {
			$query_args['post__not_in'][] = get_the_ID();
		}

		return $query_args;
	}

	public function query_posts() {
		$query_args  = $this->query_posts_args();
		$this->query = new \WP_Query( $query_args );
	}

	public function get_query() {
		return $this->query;
	}
}
