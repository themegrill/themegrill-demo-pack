<?php

namespace CompanionElementor\Modules\Posts\TemplateBlocks;

defined( 'ABSPATH' ) || exit;

class Skin_Classic extends Skin_Style {
	private static $instance;

	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}
