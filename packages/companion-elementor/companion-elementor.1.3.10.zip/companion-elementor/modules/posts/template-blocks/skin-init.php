<?php

namespace CompanionElementor\Modules\Posts\TemplateBlocks;

defined( 'ABSPATH' ) || exit;

class Skin_Init {
	private static $instance;

	public static function get_instance( $style ) {
		$class = 'CompanionElementor\\Modules\\Posts\\TemplateBlocks\\Skin_' . ucfirst( $style );

		if ( class_exists( $class ) ) {
			self::$instance[ $style ] = new $class( $style );
		}

		return self::$instance[ $style ];
	}
}
