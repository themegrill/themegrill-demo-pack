<?php

namespace CompanionElementor\Modules\Switcher\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Plugin;
use CompanionElementor\Classes\Utils as CompanionElementorUtils;

defined( 'ABSPATH' ) || exit;

class Switcher extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-switch';
	}

	public function get_title() {
		return __( 'Switch', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-dual-button';
	}

	public function get_keywords() {
		return [ 'companion', 'switch', 'content toggle' ];
	}

	protected function register_controls() {
		$this->register_primary_controls();
		$this->register_secondary_controls();
		$this->register_style_switch_controls();
		$this->register_style_label_controls();
		$this->register_style_content_controls();
		$this->register_helpful_information();
	}

	private function register_primary_controls() {
		$this->start_controls_section(
			'ec_switch_primary_section',
			[
				'label' => esc_html__( 'Primary', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'primary_label',
			[
				'label'   => esc_html__( 'Label', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Monthly', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'primary_content_type',
			[
				'label'   => esc_html__( 'Content Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'content',
				'options' => [
					'content'  => esc_html__( 'Content', 'companion-elementor' ),
					'template' => esc_html__( 'Template', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'primary_content',
			[
				'label'     => esc_html__( 'Content', 'companion-elementor' ),
				'type'      => Controls_Manager::WYSIWYG,
				'default'   => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'companion-elementor' ),
				'condition' => [
					'primary_content_type' => 'content',
				],
			]
		);

		$this->add_control(
			'primary_template',
			[
				'label'     => esc_html__( 'Template', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '0',
				'options'   => CompanionElementorUtils::get_templates(),
				'condition' => [
					'primary_content_type' => 'template',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_secondary_controls() {
		$this->start_controls_section(
			'ec_switch_secondary_section',
			[
				'label' => esc_html__( 'Secondary', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'secondary_label',
			[
				'label'   => esc_html__( 'Label', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Yearly', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'secondary_content_type',
			[
				'label'   => esc_html__( 'Content Type', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'content',
				'options' => [
					'content'  => esc_html__( 'Content', 'companion-elementor' ),
					'template' => esc_html__( 'Template', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'secondary_content',
			[
				'label'     => esc_html__( 'Content', 'companion-elementor' ),
				'type'      => Controls_Manager::WYSIWYG,
				'default'   => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis non molestie massa.', 'companion-elementor' ),
				'condition' => [
					'secondary_content_type' => 'content',
				],
			]
		);

		$this->add_control(
			'secondary_template',
			[
				'label'     => esc_html__( 'Template', 'companion-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '0',
				'options'   => CompanionElementorUtils::get_templates(),
				'condition' => [
					'secondary_content_type' => 'template',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_switch_controls() {
		$this->start_controls_section(
			'ec_switch_style_section',
			[
				'label' => esc_html__( 'Switch', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'header_alignment',
			[
				'label'        => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'      => 'center',
				'prefix_class' => 'ec-switch--',
			]
		);

		$this->add_control(
			'header_bg',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-toggle-wrap' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'header_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-toggle-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'header_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-toggle-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'toggle_btn_heading',
			[
				'label'     => esc_html__( 'Toggle Button', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'toggle_btn_size',
			[
				'label'      => esc_html__( 'Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors'  => [
					'{{WRAPPER}} .toggle' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'toggle_btn_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'em',
					'rem',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors'  => [
					'{{WRAPPER}} .toggle' => 'margin: 0 {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'toggle_btn_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .toggle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'toggle_btn_tabs'
		);

		$this->start_controls_tab(
			'toggle_btn_normal',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'toggle_btn_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .toggle',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'toggle_btn_normal_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .toggle',
			]
		);

		$this->add_responsive_control(
			'toggle_btn_normal_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .toggle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'toggle_btn_active',
			[
				'label' => esc_html__( 'Active', 'companion-elementor' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'toggle_btn_active_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} input:checked + .toggle',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'toggle_btn_active_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} input:checked + .toggle',
			]
		);

		$this->add_responsive_control(
			'toggle_btn_active_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} input:checked + .toggle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'toggle_handler_heading',
			[
				'label'     => esc_html__( 'Toggle Handler', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'toggle_handler_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .toggle .toggle-handler',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'toggle_handler_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .toggle .toggle-handler',
			]
		);

		$this->add_responsive_control(
			'toggle_handler_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .toggle .toggle-handler' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_label_controls() {
		$this->start_controls_section(
			'ec_switch_label_style_section',
			[
				'label' => esc_html__( 'Label', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'label_tabs'
		);

		$this->start_controls_tab(
			'primary_btn',
			[
				'label' => esc_html__( 'Primary', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'primary_btn_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-switch-heading--primary .ec-switch-heading' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'primary_btn_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-switch-on .ec-switch-heading--primary .ec-switch-heading' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'primary_btn_typography',
				'selector' => '{{WRAPPER}} .ec-switch-heading--primary .ec-switch-heading',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'secondary_btn',
			[
				'label' => esc_html__( 'Secondary', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'secondary_btn_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-switch-heading--secondary .ec-switch-heading' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'secondary_btn_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-switch-on .ec-switch-heading--secondary .ec-switch-heading' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'secondary_btn_typography',
				'selector' => '{{WRAPPER}} .ec-switch-heading--secondary .ec-switch-heading',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_content_controls() {
		$this->start_controls_section(
			'ec_switch_content_style_section',
			[
				'label' => esc_html__( 'Content', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_alignment',
			[
				'label'   => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left'   => [
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default' => 'center',
			]
		);

		$this->start_controls_tabs(
			'content_tab'
		);

		$this->start_controls_tab(
			'content_primary',
			[
				'label' => esc_html__( 'Primary', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'content_primary_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-content--primary' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_primary_typography',
				'selector' => '{{WRAPPER}} .ec-content--primary',
			]
		);

		$this->add_control(
			'content_primary_bg',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-switch-content .ec-content--primary' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'content_primary_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-switch-content .ec-content--primary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_primary_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-switch-content .ec-content--primary' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'content_primary_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-switch-content .ec-content--primary',
			]
		);

		$this->add_responsive_control(
			'content_primary_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-switch-content .ec-content--primary' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'content_primary_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-switch-content .ec-content--primary',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'content_secondary',
			[
				'label' => esc_html__( 'Secondary', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'content_secondary_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-content--secondary' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_secondary_typography',
				'selector' => '{{WRAPPER}} .ec-content--secondary',
			]
		);

		$this->add_control(
			'content_secondary_bg',
			[
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-switch-content .ec-content--secondary' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'content_secondary_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-switch-content .ec-content--secondary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_secondary_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-switch-content .ec-content--secondary' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'content_secondary_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-switch-content .ec-content--secondary',
			]
		);

		$this->add_responsive_control(
			'content_secondary_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-switch-content .ec-content--secondary' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'content_secondary_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-switch-content .ec-content--secondary',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/switch-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings               = $this->get_settings_for_display();
		$primary_label          = $settings['primary_label'];
		$secondary_label        = $settings['secondary_label'];
		$primary_content_type   = $settings['primary_content_type'];
		$secondary_content_type = $settings['secondary_content_type'];
		$primary_content        = $settings['primary_content'];
		$secondary_content      = $settings['secondary_content'];
		$primary_template       = $settings['primary_template'];
		$secondary_template     = $settings['secondary_template'];
		$align                  = ! empty( $settings['content_alignment'] ) ? $settings['content_alignment'] : 'none';
		?>
		<div class="ec-switch-wrapper">
			<div class="ec-switch ec-content--<?php echo esc_attr( $align ); ?>">

				<div class="ec-toggle-wrap">

					<?php if ( $primary_label ) : ?>
						<div class="ec-switch-heading--primary">
							<h5 class="ec-switch-heading"><?php echo esc_html( $primary_label ); ?></h5>
						</div> <!-- /.ec-switch-heading--primary -->
					<?php endif; ?>

					<div class="toggle-btn">
						<input id="ec-switch-input-<?php echo esc_attr( $this->get_id() ); ?>" type="checkbox" />
						<label class="toggle" for="ec-switch-input-<?php echo esc_attr( $this->get_id() ); ?>">
							<span class="toggle-handler"></span>
						</label>
					</div> <!-- /.toggle-wrap -->

					<?php if ( $secondary_label ) : ?>
						<div class="ec-switch-heading--secondary">
							<h5 class="ec-switch-heading"><?php echo esc_html( $secondary_label ); ?></h5>
						</div> <!-- /.ec-switch-heading--secondary -->
					<?php endif; ?>
				</div> <!-- /.ec-toggle-wrap -->

				<div class="ec-switch-content">

					<div class="ec-content--primary">
						<?php
						if ( 'content' === $primary_content_type ) :

							echo $this->parse_text_editor( $primary_content ); // phpcs:ignore WordPress.Security.EscapeOutput

						elseif ( 'template' === $primary_content_type ) :

							if ( '0' !== $primary_template && ! empty( $primary_template ) ) {
								echo Plugin::instance()->frontend->get_builder_content_for_display( $primary_template ); // phpcs:ignore WordPress.Security.EscapeOutput
							}

						endif;
						?>
					</div> <!-- /.ec-content--primary -->

					<div class="ec-content--secondary">
						<?php
						if ( 'content' === $secondary_content_type ) :

							echo $this->parse_text_editor( $secondary_content ); // phpcs:ignore WordPress.Security.EscapeOutput

						elseif ( 'template' === $secondary_content_type ) :

							if ( '0' !== $secondary_template && ! empty( $secondary_template ) ) {
								echo Plugin::instance()->frontend->get_builder_content_for_display( $secondary_template ); // phpcs:ignore WordPress.Security.EscapeOutput
							}

						endif;
						?>
					</div> <!-- /.ec-content--secondary -->

				</div>

			</div> <!-- /.ec-switch -->
		</div> <!-- /.ec-switch-wrapper -->

		<?php
	}
}
