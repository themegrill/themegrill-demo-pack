<?php

namespace CompanionElementor\Modules\Switcher;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Switcher',
		];
	}

	public function get_name() {
		return 'switcher';
	}

}
