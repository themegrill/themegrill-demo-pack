<?php

namespace CompanionElementor\Modules\Button;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return [
			'Button',
		];
	}

	public function get_name() {
		return 'button';
	}

}
