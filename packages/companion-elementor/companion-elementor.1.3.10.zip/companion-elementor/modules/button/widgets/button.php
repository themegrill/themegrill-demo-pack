<?php
/**
 * Button class.
 */

namespace CompanionElementor\Modules\Button\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

defined( 'ABSPATH' ) || exit;

class Button extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-button';
	}

	public function get_title() {
		return __( 'Button', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-button';
	}

	public function get_keywords() {
		return array( 'companion', 'button', 'cta', 'call to action' );
	}

	protected function register_controls() {

		$this->register_general_controls();
		$this->register_icon_controls();
		$this->register_style_general_controls();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'ec_section_button',
			array(
				'label' => __( 'Button', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'   => esc_html__( 'Text', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Click Here', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'       => esc_html__( 'Link', 'companion-elementor' ),
				'type'        => Controls_Manager::URL,
				'default'     => array(
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				),
				'placeholder' => esc_html__( 'https://your-link.com', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'button_size',
			array(
				'label'   => esc_html__( 'Size', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'large',
				'options' => array(
					'small'  => esc_html__( 'small', 'companion-elementor' ),
					'medium' => esc_html__( 'medium', 'companion-elementor' ),
					'large'  => esc_html__( 'large', 'companion-elementor' ),
					'custom' => esc_html__( 'Custom', 'companion-elementor' ),
				),
			)
		);

		$this->add_responsive_control(
			'button_custom_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-button-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'button_size' => 'custom',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_icon_controls() {
		$this->start_controls_section(
			'ec_section_icon',
			array(
				'label' => __( 'Icon', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_icon',
			array(
				'label'        => esc_html__( 'Show Icon', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'icon',
			array(
				'label'       => __( 'Icon', 'companion-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => array(
					'value'   => 'fas fa-book-open',
					'library' => 'fa-solid',
				),
				'skin'        => 'inline',
				'label_block' => false,
				'condition'   => array(
					'show_icon' => 'yes',
				),
			)
		);

		$this->add_responsive_control(
			'icon_position',
			array(
				'label'     => esc_html__( 'Icon Position', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'right',
				'options'   => array(
					'left'  => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'condition' => array(
					'show_icon' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_general_controls() {
		$this->start_controls_section(
			'ec_button_style_section',
			array(
				'label' => esc_html__( 'Button', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .ec-button-link',
			)
		);

		$this->start_controls_tabs(
			'button_tabs'
		);

		$this->start_controls_tab(
			'button_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'button_normal_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-button-link' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'button_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-button-link',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'button_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'button_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-button-link:hover' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'button_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-button-link:hover',
			)
		);

		$this->end_controls_tab();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'      => 'button_border',
				'selector'  => '{{WRAPPER}} .ec-button-link',
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'button_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-button-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'button_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-button-link',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings      = $this->get_settings_for_display();
		$button_text   = $settings['button_text'];
		$button_link   = $settings['button_link'];
		$button_size   = $settings['button_size'];
		$icon_position = $settings['icon_position'];
		?>
		<div class="ec-button-wrapper">
			<a class="ec-button ec-button-link <?php echo esc_attr( 'is-' . $button_size ); ?>" href="<?php echo esc_url( $button_link['url'] ); ?>" <?php echo $button_link['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $button_link['nofollow'] ? 'rel="nofollow"' : ''; ?>">
				<span class="ec-button-text <?php echo esc_attr( 'icon-position-' . $icon_position ); ?>">
					<?php echo esc_html( $button_text ); ?>
				</span>
				<i class="<?php echo esc_attr( is_array( $settings['icon'] ) ? $settings['icon']['value'] : $settings['icon'] ); ?>" aria-hidden="true"></i>
			</a>
		</div> <!-- /.ec-button -->
		<?php
	}
}
