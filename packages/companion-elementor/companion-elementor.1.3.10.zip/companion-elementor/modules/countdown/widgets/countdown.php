<?php

namespace CompanionElementor\Modules\Countdown\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

defined( 'ABSPATH' ) || exit;

class Countdown extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-countdown';
	}

	public function get_title() {
		return __( 'Countdown', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-countdown';
	}

	public function get_keywords() {
		return [ 'companion', 'countdown', 'timer' ];
	}

	protected function register_controls() {

		$this->register_general_controls();
		$this->register_style_countdown_controls();
		$this->register_style_item_controls();
		$this->register_style_time_controls();
		$this->register_style_label_controls();
		$this->register_helpful_information();
	}

	private function register_general_controls() {
		$this->start_controls_section(
			'ec_section_countdown',
			[
				'label' => esc_html__( 'Countdown', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'due_date',
			[
				'label'   => esc_html__( 'Due Date', 'companion-elementor' ),
				'type'    => Controls_Manager::DATE_TIME,
				'default' => date( 'Y-m-d H:i', strtotime( '+15 days' ) ),
			]
		);

		$column = range( 1, 4 );
		$column = array_combine( $column, $column );

		$this->add_responsive_control(
			'columns',
			[
				'label'              => esc_html__( 'Columns', 'companion-elementor' ),
				'type'               => Controls_Manager::SELECT,
				'options'            => $column,
				'prefix_class'       => 'ec-col-%s-',
				'default'            => 4,
				'frontend_available' => true,
				'desktop_default'    => 4,
				'tablet_default'     => 4,
				'mobile_default'     => 2,
			]
		);

		$this->add_control(
			'label_position',
			[
				'label'        => esc_html__( 'Label Position', 'companion-elementor' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'below',
				'options'      => [
					'beside' => esc_html__( 'Beside', 'companion-elementor' ),
					'below'  => esc_html__( 'Below', 'companion-elementor' ),
				],
				'prefix_class' => 'label-position--',
			]
		);

		$this->add_control(
			'label_alignment',
			[
				'label'     => esc_html__( 'Label Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'center',
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Top', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					],
					'center'     => [
						'title' => esc_html__( 'Middle', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'flex-end'   => [
						'title' => esc_html__( 'Bottom', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ec-countdown-item-inner' => 'align-items: {{VALUE}}',
				],
				'condition' => [
					'label_position' => 'beside',
				],
			]
		);

		$this->add_control(
			'time_settings_heading',
			[
				'label'     => esc_html__( 'Time Settings', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'days',
			[
				'label'        => esc_html__( 'Days', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'hours',
			[
				'label'        => esc_html__( 'Hours', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'minutes',
			[
				'label'        => esc_html__( 'Minutes', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'seconds',
			[
				'label'        => esc_html__( 'Seconds', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'label_settings_heading',
			[
				'label'     => esc_html__( 'Label Settings', 'companion-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'show_label',
			[
				'label'        => esc_html__( 'Show Label', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'custom_label',
			[
				'label'        => esc_html__( 'Custom Label', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'show_label' => 'yes',
				],
			]
		);

		$this->add_control(
			'days_label',
			[
				'label'     => esc_html__( 'Days', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Days', 'companion-elementor' ),
				'condition' => [
					'show_label'   => 'yes',
					'custom_label' => 'yes',
					'days'         => 'yes',
				],
			]
		);

		$this->add_control(
			'hours_label',
			[
				'label'     => esc_html__( 'Hours', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Hours', 'companion-elementor' ),
				'condition' => [
					'show_label'   => 'yes',
					'custom_label' => 'yes',
					'hours'        => 'yes',
				],
			]
		);

		$this->add_control(
			'minutes_label',
			[
				'label'     => esc_html__( 'Minutes', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Minutes', 'companion-elementor' ),
				'condition' => [
					'show_label'   => 'yes',
					'custom_label' => 'yes',
					'minutes'      => 'yes',
				],
			]
		);

		$this->add_control(
			'seconds_label',
			[
				'label'     => esc_html__( 'Seconds', 'companion-elementor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Seconds', 'companion-elementor' ),
				'condition' => [
					'show_label'   => 'yes',
					'custom_label' => 'yes',
					'seconds'      => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_countdown_controls() {
		$this->start_controls_section(
			'ec_countdown_style_section',
			array(
				'label' => esc_html__( 'Countdown', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'container_width',
			array(
				'label'      => esc_html__( 'Container Width', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'%',
				),
				'range'      => array(
					'%' => array(
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					),
				),
				'default'    => array(
					'unit' => '%',
					'size' => 75,
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-countdown' => 'max-width: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'companion-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					),
				),
				'default'   => 'center',
				'selectors' => array(
					'{{WRAPPER}} .ec-countdown-wrapper' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_item_controls() {
		$this->start_controls_section(
			'ec_countdown_item_style_section',
			array(
				'label' => esc_html__( 'Item', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'columns_gap',
			array(
				'label'      => esc_html__( 'Columns Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'rem',
					'em',
				),
				'range'      => array(
					'px'  => array(
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					),
					'rem' => array(
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.1,
					),
					'em'  => array(
						'min'  => 0,
						'max'  => 3.125,
						'step' => 0.1,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 15,
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-countdown-item' => 'padding-left: calc( {{SIZE}}{{UNIT}}/2 ); padding-right: calc( {{SIZE}}{{UNIT}}/2 );',
					'{{WRAPPER}} .ec-countdown .ec-countdown-items-wrap' => 'margin-left: calc( -{{SIZE}}{{UNIT}}/2 ); margin-right: calc( -{{SIZE}}{{UNIT}}/2 );',
				),
			)
		);

		$this->add_responsive_control(
			'rows_gap',
			array(
				'label'      => esc_html__( 'Rows Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'rem',
					'em',
				),
				'range'      => array(
					'px'  => array(
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					),
					'rem' => array(
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.1,
					),
					'em'  => array(
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.1,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 30,
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-countdown-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'item_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-countdown-item-inner',
			)
		);

		$this->add_responsive_control(
			'item_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-countdown-item-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'item_border',
				'label'    => esc_html__( 'Border', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-countdown-item-inner',
			)
		);

		$this->add_responsive_control(
			'item_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-countdown-item-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'item_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-countdown-item',
			)
		);

		$this->end_controls_section();
	}

	private function register_style_time_controls() {
		$this->start_controls_section(
			'ec_countdown_time_style_section',
			array(
				'label' => esc_html__( 'Time', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'time_typography',
				'selector' => '{{WRAPPER}} .ec-countdown-item .ec-number',
			)
		);

		$this->add_control(
			'time_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-countdown-item .ec-number' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'time_margin',
			array(
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-countdown-item .ec-number' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_label_controls() {
		$this->start_controls_section(
			'ec_countdown_label_style_section',
			array(
				'label' => esc_html__( 'Label', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'label_typography',
				'selector' => '{{WRAPPER}} .ec-countdown-item .ec-label',
			)
		);

		$this->add_control(
			'label_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-countdown-item .ec-label' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'label_margin',
			array(
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-countdown-item .ec-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_helpful_information() {

		$link = 'https://docs.compelementor.com/docs/widget/companion-addons-for-elementor-widgets/countdown-widget/';

		$this->start_controls_section(
			'section_helpful_info',
			[
				'label' => esc_html__( 'Helpful Information', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'help_doc',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf( __( '%1$sRead article%2$s', 'companion-elementor' ), '<a href=' . $link . ' target="_blank" rel="nofollow">', ' »</a>' ),
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings      = $this->get_settings_for_display();
		$due_date      = $settings['due_date'];
		$days          = $settings['days'];
		$hours         = $settings['hours'];
		$minutes       = $settings['minutes'];
		$seconds       = $settings['seconds'];
		$show_label    = $settings['show_label'];
		$custom_label  = $settings['custom_label'];
		$days_label    = $settings['days_label'];
		$hours_label   = $settings['hours_label'];
		$minutes_label = $settings['minutes_label'];
		$seconds_label = $settings['seconds_label'];
		?>

		<div class="ec-countdown-wrapper">
			<div class="ec-countdown"
				data-date="<?php echo esc_attr( strtotime( $due_date ) ); ?>">

				<div class="ec-countdown-items-wrap">
					<?php if ( $days ) : ?>
						<div class="ec-countdown-item">
							<div class="ec-countdown-item-inner">
								<span class="ec-number ec-day"></span>

								<?php if ( $show_label ) : ?>
									<span class="ec-label">
									<?php echo ( 'yes' === $custom_label ) ? esc_html( $days_label ) : esc_html__( 'Days', 'companion-elementor' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							</span>
								<?php endif; ?>
							</div>
						</div>
					<?php endif; ?>

					<?php if ( $hours ) : ?>
						<div class="ec-countdown-item">
							<div class="ec-countdown-item-inner">
								<span class="ec-number ec-hour"></span>

								<?php if ( $show_label ) : ?>
									<span class="ec-label">
									<?php echo ( 'yes' === $custom_label ) ? esc_html( $hours_label ) : esc_html__( 'Hours', 'companion-elementor' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							</span>
								<?php endif; ?>
							</div>
						</div>
					<?php endif; ?>

					<?php if ( $minutes ) : ?>
						<div class="ec-countdown-item">
							<div class="ec-countdown-item-inner">
								<span class="ec-number ec-minute"></span>

								<?php if ( $show_label ) : ?>
									<span class="ec-label">
									<?php echo ( 'yes' === $custom_label ) ? esc_html( $minutes_label ) : esc_html__( 'Minutes', 'companion-elementor' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							</span>
								<?php endif; ?>
							</div>
						</div>
					<?php endif; ?>

					<?php if ( $seconds ) : ?>
						<div class="ec-countdown-item">
							<div class="ec-countdown-item-inner">
								<span class="ec-number ec-second"></span>

								<?php if ( $show_label ) : ?>
									<span class="ec-label">
									<?php echo ( 'yes' === $custom_label ) ? esc_html( $seconds_label ) : esc_html__( 'Seconds', 'companion-elementor' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							</span>
								<?php endif; ?>
							</div>
						</div>
					<?php endif; ?>
				</div> <!-- /.ec-countdown-items-wrap -->

			</div> <!-- /.ec-countdown -->
		</div> <!-- /.ec-countdown-wrapper -->

		<?php
	}
}
