<?php
namespace CompanionElementor\Modules\QueryControl\Classes;

class Post_Query {
	protected $widget;
	protected $query_args;
	protected $prefix;

	public function __construct( $widget, $group_query_name, $query_args = [] ) {
		$this->widget = $widget;
	}

	public function get_query() {

	}
}