<?php

namespace CompanionElementor\Modules\QueryControl;

use CompanionElementor\Base\Module_Base;
defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_name() {
		return 'query-control';
	}

	public function __construct() {
		parent::__construct();
	}

}
