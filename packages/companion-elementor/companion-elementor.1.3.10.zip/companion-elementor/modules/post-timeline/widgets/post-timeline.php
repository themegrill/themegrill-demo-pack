<?php

namespace CompanionElementor\Modules\PostTimeline\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;

class Post_Timeline extends Base_Widget {

	public function get_name() {
		return 'elementor-companion-post-timeline';
	}

	public function get_title() {
		return __( 'Post Timeline', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-time-line';
	}

	public function get_keywords() {
		return array( 'companion', 'post timeline', 'post', 'timeline' );
	}

	protected function register_controls() {
		$this->register_timeline_layout_controls();
		$this->register_timeline_items_controls();
		$this->register_timeline_content_controls();
		$this->register_style_timeline_content_controls();
		$this->register_style_timeline_title_controls();
		$this->register_style_timeline_description_controls();
		$this->register_style_timeline_date_controls();
		$this->register_style_timeline_number_box_controls();
		$this->register_style_timeline_line_controls();
	}

	private function register_timeline_layout_controls() {
		$this->start_controls_section(
			'ec_timeline_layout_control_section',
			array(
				'label' => esc_html__( 'Layout', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'timeline_content',
			array(
				'label'   => esc_html__( 'Timeline Content', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'custom',
				'options' => array(
					'dynamic' => esc_html__( 'Dynamic', 'companion-elementor' ),
					'custom'  => esc_html__( 'Custom', 'companion-elementor' ),
				),
			)
		);

		$this->add_control(
			'timeline_layout',
			array(
				'label'   => esc_html__( 'Layout', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'zigZag',
				'options' => array(
					'zigZag'    => esc_html__( 'Zig-Zag', 'companion-elementor' ),
					'lineLeft'  => esc_html__( 'Line Left', 'companion-elementor' ),
					'lineRight' => esc_html__( 'Line Right', 'companion-elementor' ),
				),
			)
		);

		$this->add_control(
			'timeline_media_position',
			array(
				'label'   => esc_html__( 'Media Position', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'top',
				'options' => array(
					'top'    => esc_html__( 'Top', 'companion-elementor' ),
					'bottom' => esc_html__( 'Bottom', 'companion-elementor' ),
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_timeline_items_controls() {
		$this->start_controls_section(
			'ec_timeline_items_control_section',
			array(
				'label' => esc_html__( 'Timeline Items', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'post_timeline_image',
			array(
				'label'   => __( 'Image', 'companion-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$repeater->add_control(
			'post_timeline_custom_styles',
			array(
				'label'        => esc_html__( 'Custom Styles', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			)
		);

		$repeater->add_control(
			'post_timeline_custom_style_title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .ec-feature-list-title a' => 'color: {{VALUE}};',
				),
				'condition' => array(
					'feature_list_custom_styles' => 'yes',
				),
			)
		);

		$repeater->add_control(
			'post_timeline_title',
			array(
				'label'       => __( 'Title', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Title', 'companion-elementor' ),
				'dynamic'     => array(
					'active' => true,
				),
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'post_timeline_list_content',
			array(
				'label'   => __( 'Content', 'companion-elementor' ),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => __( '', 'companion-elementor' ),
			)
		);

		$repeater->add_control(
			'post_timeline_label',
			array(
				'label'   => esc_html__( 'Label', 'companion-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( '', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'tabs',
			array(
				'label'       => __( 'Timeline Items', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						/* Translators: %s number. */

						'post_timeline_title'        => sprintf( esc_html__( 'Timeline Item %s', 'companion-elementor' ), 1 ),
						'post_timeline_list_content' => __( 'This Block will work with any theme and supports the block editor.', 'companion-elementor' ),
						'post_timeline_label'        => __( 'Sep 1, 2023', 'companion-elementor' ),
					),
					array(
						/* Translators: %s number. */
						'post_timeline_title'        => sprintf( esc_html__( 'Timeline Item %s', 'companion-elementor' ), 2 ),
						'post_timeline_list_content' => __( 'This Block will work with any theme and supports the block editor.', 'companion-elementor' ),
						'post_timeline_label'        => __( 'Sep 1, 2023', 'companion-elementor' ),
					),
					array(
						/* Translators: %s number. */
						'post_timeline_title'        => sprintf( esc_html__( 'Timeline Item %s', 'companion-elementor' ), 3 ),
						'post_timeline_list_content' => __( 'This Block will work with any theme and supports the block editor.', 'companion-elementor' ),
						'post_timeline_label'        => __( 'Sep 1, 2023', 'companion-elementor' ),
					),
				),
				'title_field' => '{{{ post_timeline_title }}}',
			)
		);

		$this->end_controls_section();
	}

	private function register_timeline_content_controls() {
		$this->start_controls_section(
			'ec_timeline_content_control_section',
			array(
				'label' => esc_html__( 'Content', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'timeline_show_title',
			[
				'label'        => esc_html__( 'Show Title', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'timeline_show_description',
			[
				'label'        => esc_html__( 'Show Description', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'label_off'    => esc_html__( 'No', 'companion-elementor' ),
				'label_on'     => esc_html__( 'Yes', 'companion-elementor' ),
			]
		);

		$this->end_controls_section();
	}

	private function register_style_timeline_content_controls() {
		$this->start_controls_section(
			'ec_timeline_content_style_section',
			array(
				'label' => esc_html__( 'Content', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'timeline_content_alignment',
			array(
				'label'       => esc_html__( 'Content Alignment', 'companion-elementor' ),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'fa fa-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'companion-elementor' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'fa fa-align-right',
					),
				),
				'default'     => 'center',
				'selectors'   => array(
					'{{WRAPPER}} .ec-timeline-content' => 'text-align: {{VALUE}};',
				),
				'label_block' => true,
			)
		);

		$this->add_responsive_control(
			'timeline_content_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'content_border_divider_before',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'timeline_content_border',
				'selector' => '{{WRAPPER}} .ec-timeline-content',
			)
		);

		$this->add_control(
			'content_border_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_responsive_control(
			'timeline_content_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'timeline_content_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-timeline-content',
			)
		);

		$this->end_controls_section();
	}

	private function register_style_timeline_title_controls() {
		$this->start_controls_section(
			'ec_timeline_style_title_section',
			array(
				'label' => esc_html__( 'Title', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'timeline_title_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-timeline .ec-timeline-title a' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'timeline_title_typography',
				'selector' => '{{WRAPPER}} .ec-timeline .ec-timeline-title a',
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'timeline_title_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-timeline .ec-timeline-title a',
			)
		);

		$this->add_control(
			'timeline_title_border_divider_before',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'timeline_title_border',
				'selector' => '{{WRAPPER}} .ec-timeline .ec-timeline-title a',
			)
		);

		$this->add_control(
			'timeline_title_border_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_responsive_control(
			'timeline_title_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline .ec-timeline-title a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'timeline_title_margin',
			array(
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline .ec-timeline-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_timeline_description_controls() {
		$this->start_controls_section(
			'ec_timeline_style_description_section',
			array(
				'label' => esc_html__( 'Description', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'timeline_description_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-timeline-description' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'timeline_description_typography',
				'selector' => '{{WRAPPER}} .ec-timeline-description',
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'timeline_description_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-timeline-description',
			)
		);

		$this->add_control(
			'timeline_description_border_divider_before',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'timeline_description_border',
				'selector' => '{{WRAPPER}} .ec-timeline-description',
			)
		);

		$this->add_control(
			'timeline_description_border_divider_after',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_responsive_control(
			'timeline_description_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline-description' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'timeline_description_margin',
			array(
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_section();
	}

	private function register_style_timeline_date_controls() {
		$this->start_controls_section(
			'ec_timeline_date_style_section',
			array(
				'label' => esc_html__( 'Time', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'timeline_date_background_color',
			array(
				'label'     => __( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-timeline-label' => 'background-color: {{VALUE}};',
				),

			)
		);

		$this->add_control(
			'timeline_date_color',
			array(
				'label'     => __( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-timeline-label' => 'color: {{VALUE}};',
				),

			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'timeline_date_typography',
				'label'    => __( 'Typography', 'companion-elementor' ),
				'selector' => '.ec-timeline-label',
			)
		);

		$this->add_control(
			'timeline_date_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'timeline_date_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_timeline_number_box_controls() {
		$this->start_controls_section(
			'ec_timeline_number_box_style_section',
			array(
				'label' => esc_html__( 'Number Box', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'timeline_number_box_background_color',
			array(
				'label'     => __( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-timeline-marker' => 'background-color: {{VALUE}};',
				),

			)
		);

		$this->add_control(
			'timeline_number_box_color',
			array(
				'label'     => __( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-timeline-marker' => 'color: {{VALUE}};',
				),

			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'timeline_number_box_typography',
				'label'    => __( 'Typography', 'companion-elementor' ),
				'selector' => '.ec-timeline-marker',
			)
		);

		$this->add_control(
			'timeline_number_box_padding',
			array(
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline-marker' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'timeline_number_box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'em',
					'rem',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline-marker' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_style_timeline_line_controls() {
		$this->start_controls_section(
			'ec_timeline_line_style_section',
			array(
				'label' => esc_html__( 'Line', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'ec_timeline_line_color',
			array(
				'label'     => esc_html__( 'Background Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-timeline .ec-timeline-inner::before' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'ec_timeline_line_width',
			array(
				'label'      => esc_html__( 'Width', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 4,
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-timeline .ec-timeline-inner::before' => 'width: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$type     = $settings['timeline_content'];

		'custom' === $type && $this->render_custom();
		'dynamic' === $type && $this->render_dynamic();
	}

	protected function render_custom() {
		$settings                = $this->get_settings_for_display();
		$tabs                    = $settings['tabs'];
		$timeline_media_position = $settings['timeline_media_position'];
		$timeline_layout         = $settings['timeline_layout'];

		?>
		<div class="ec-timeline ec-timeline-frontend <?php echo esc_html( $timeline_layout ); ?>">
		<?php
		foreach ( $tabs as $index => $tab ) :
			$post_timeline_image = ! empty( $tab['post_timeline_image']['url'] ) ? $tab['post_timeline_image']['url'] : '';

			?>
				<article class='ec-timeline-inner'>
					<div class='ec-timeline-control'>
						<div class='ec-timeline-content'>
							<div>
								<?php if ( 'top' === $timeline_media_position ) : ?>
									<?php if ( ! empty( $post_timeline_image ) ) : ?>
									<div class="ec-timeline-media">
										<img src="<?php echo esc_url( $post_timeline_image ); ?>" alt="<?php echo esc_attr( $tab['post_timeline_title'] ); ?>">
									</div>
									<?php endif; ?>

									<?php if ( 'yes' === $settings['timeline_show_title'] ) : ?>
										<h3 class='ec-timeline-title'>
											<a href=''><?php echo esc_html( $tab['post_timeline_title'] ); ?></a>
										</h3>
									<?php endif; ?>
									<?php if ( 'yes' === $settings['timeline_show_description'] ) : ?>
										<p class="ec-timeline-description">
											<?php echo wp_kses_post( $this->parse_text_editor( $tab['post_timeline_list_content'] ) ); ?>
										</p>
									<?php endif; ?>
								<?php endif; ?>
								<?php if ( 'bottom' === $timeline_media_position ) : ?>
									<?php if ( 'yes' === $settings['timeline_show_title'] ) : ?>
										<h3 class='ec-timeline-title'>
											<a href=''><?php echo esc_html( $tab['post_timeline_title'] ); ?></a>
										</h3>
									<?php endif; ?>
									<?php if ( 'yes' === $settings['timeline_show_description'] ) : ?>
										<p class="ec-timeline-description">
											<?php echo wp_kses_post( $this->parse_text_editor( $tab['post_timeline_list_content'] ) ); ?>
										</p>
									<?php endif; ?>
									<?php if ( ! empty( $post_timeline_image ) ) : ?>
									<div class="ec-timeline-media">
										<img src="<?php echo esc_url( $post_timeline_image ); ?>" alt="<?php echo esc_attr( $tab['post_timeline_title'] ); ?>">
									</div>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						</div>

						<div class='ec-timeline-marker'><?php echo esc_html( $index + 1 ); ?></div>
						<div class='ec-timeline-label-container'>
							<p class='ec-timeline-label'><?php echo esc_html( $tab['post_timeline_label'] ); ?></p>
						</div>
					</div>
				</article>
			<?php endforeach; ?>

		</div>
		<?php
	}

	public function render_dynamic() {
		$settings                = $this->get_settings_for_display();
		$timeline_media_position = $settings['timeline_media_position'];
		$timeline_layout         = $settings['timeline_layout'];

		$args = array(
			'post_type' => 'post',
		);

		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) :
			?>
			<div class="ec-timeline ec-timeline-frontend <?php echo esc_html( $timeline_layout ); ?>">
				<?php
				while ( $query->have_posts() ) :
					$query->the_post();
					?>
					<article class="ec-timeline-inner">
						<div class='ec-timeline-control'>
							<div class='ec-timeline-content'>
								<div>
									<?php if ( 'top' === $timeline_media_position ) : ?>
										<?php if ( has_post_thumbnail() ) : ?>
											<div class="ec-timeline-media">
												<a href="<?php the_permalink(); ?>">
													<?php the_post_thumbnail( 'medium' ); ?>
												</a>
											</div>
										<?php endif; ?>
										<?php if ( 'yes' === $settings['timeline_show_title'] ) : ?>
											<h3 class="ec-timeline-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
										<?php endif; ?>
										<div class="ec-timeline-meta">
											<span class="ec-timeline-posted-on"><?php the_date(); ?></span>
										</div>
										<?php if ( 'yes' === $settings['timeline_show_description'] ) : ?>
											<div class="ec-timeline-excerpt">
												<?php the_excerpt(); ?>
											</div>
										<?php endif; ?>
									<?php endif; ?>

									<?php if ( 'bottom' === $timeline_media_position ) : ?>
										<?php if ( 'yes' === $settings['timeline_show_title'] ) : ?>
											<h3 class="ec-timeline-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
										<?php endif; ?>
										<div class="ec-timeline-meta">
											<span class="ec-timeline-posted-on"><?php the_date(); ?></span>
										</div>
										<?php if ( 'yes' === $settings['timeline_show_description'] ) : ?>
											<div class="ec-timeline-excerpt">
												<?php the_excerpt(); ?>
											</div>
										<?php endif; ?>
										<?php if ( has_post_thumbnail() ) : ?>
											<div class="ec-timeline-media">
												<a href="<?php the_permalink(); ?>">
													<?php the_post_thumbnail( 'medium' ); ?>
												</a>
											</div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							</div>

							<div class='ec-timeline-marker'><?php echo esc_html( $query->current_post + 1 ); ?></div>
							<div class='ec-timeline-label-container'>
								<p class='ec-timeline-label'><?php echo esc_html( $settings['post_timeline_label'] ?? '' ); ?></p>
							</div>
						</div>

					</article>
				<?php endwhile; ?>
			</div>

			<?php

			wp_reset_postdata();
		endif;
	}
}
