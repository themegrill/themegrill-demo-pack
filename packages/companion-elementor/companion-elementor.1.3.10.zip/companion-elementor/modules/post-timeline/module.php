<?php

namespace CompanionElementor\Modules\PostTimeline;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return array(
			'Post_Timeline',
		);
	}

	public function get_name() {
		return 'post-timeline';
	}
}
