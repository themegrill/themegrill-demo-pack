<?php

namespace CompanionElementor\Modules\InstagramFeed;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return array(
			'Instagram_Feed',
		);
	}

	public function get_name() {
		return 'instagram-feed';
	}
}
