<?php

namespace CompanionElementor\Modules\InstagramFeed\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

defined( 'ABSPATH' ) || exit;

class Instagram_Feed extends Base_Widget {


	public function get_name() {
		return 'elementor-companion-instagram-feed';
	}

	public function get_title() {
		return __( 'Instagram Feed', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-instagram-post';
	}

	public function get_keywords() {
		return array( 'companion', 'instagram feed', 'instagram', 'feed' );
	}

	protected function register_controls() {
		$this->register_instagram_account_controls();
		$this->register_instagram_settings_controls();
		$this->register_instagram_layout_controls();
		$this->register_style_instagram_feed_controls();
		$this->register_style_instagram_username_controls();
		$this->register_style_instagram_caption_controls();
		$this->register_style_instagram_icon_controls();
		$this->register_style_follow_button_controls();
	}

	private function register_instagram_account_controls() {
		$this->start_controls_section(
			'ec_instagram_account_section',
			[
				'label' => __( 'Instagram Account', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'instagram_access_token',
			[
				'label'       => __( 'Access Token', 'companion-elementor' ),
				'description' => __( 'Modify the overarching Instagram access token', 'companion-elementor' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'ai'          => [
					'active' => false,
				],
			]
		);

		$this->add_control(
			'instagram_access_token_expires_in',
			[
				'label'       => esc_html__( 'Expiry Date', 'companion-elementor' ),
				'type'        => Controls_Manager::DATE_TIME,
				'dynamic'     => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'instagram_cache_timeout',
			[
				'label'   => esc_html__( 'Cache Timeout', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'hour',
				'options' => [
					'none'   => esc_html__( 'None', 'companion-elementor' ),
					'minute' => esc_html__( 'Minute', 'companion-elementor' ),
					'hour'   => esc_html__( 'Hour', 'companion-elementor' ),
					'day'    => esc_html__( 'Day', 'companion-elementor' ),
					'week'   => esc_html__( 'Week', 'companion-elementor' ),
				],
			]
		);

		$this->add_control(
			'instagram_number_of_posts',
			[
				'label'   => __( 'Number of Posts', 'companion-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '6',
			]
		);

		$this->end_controls_section();
	}

	private function register_instagram_settings_controls() {
		$this->start_controls_section(
			'ec_settings_section',
			[
				'label' => __( 'Settings', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'instagram_layout',
			[
				'label'   => esc_html__( 'Layout', 'companion-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'card',
				'options' => [
					'card'      => esc_html__( 'Card', 'companion-elementor' ),
					'list'      => esc_html__( 'List', 'companion-elementor' ),
					'fullWidth' => esc_html__( 'Full Width', 'companion-elementor' ),
				],
			]
		);

		$this->add_responsive_control(
			'instagram_columns',
			[
				'label'                => __( 'Columns', 'companion-elementor' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 3,
				'tablet_default'       => 2,
				'mobile_default'       => 1,
				'options'              => [
					1 => esc_html__( '1', 'companion-elementor' ),
					2 => esc_html__( '2', 'companion-elementor' ),
					3 => esc_html__( '3', 'companion-elementor' ),
				],
				'selectors_dictionary' => [
					1 => 'grid-template-columns: repeat(1, 1fr);',
					2 => 'grid-template-columns: repeat(2, 1fr);',
					3 => 'grid-template-columns: repeat(3, 1fr);',
				],
				'selectors'            => [
					'{{WRAPPER}} .ec-instagram-feed' => '{{VALUE}};',
				],
				'condition'            => [
					'instagram_layout' => [ 'card', 'list' ],
				],
			]
		);

		$this->add_control(
			'instagram_caption',
			[
				'label'        => __( 'Caption', 'companion-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => __( 'Show', 'companion-elementor' ),
				'label_off'    => __( 'Hide', 'companion-elementor' ),
				'return_value' => 'yes',
				'condition'    => [
					'instagram_layout' => [ 'card', 'list' ],
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_instagram_layout_controls() {
		$this->start_controls_section(
			'ec_instagram_style_layout',
			[
				'label' => __( 'Layout', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'instagram_column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed.ec-card, {{WRAPPER}} .ec-instagram-feed.ec-list, {{WRAPPER}} .ec-instagram-feed.ec-fullWidth' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'instagram_row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed.ec-card, {{WRAPPER}} .ec-instagram-feed.ec-list' => 'row-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'instagram_layout' => [ 'card', 'list' ],
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_instagram_feed_controls() {
		$this->start_controls_section(
			'ec_instagram_feed_style_section',
			[
				'label' => esc_html__( 'Instagram Feed', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'instagram_feed_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed-below-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'instagram_feed_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'instagram_feed_border',
				'selector' => '{{WRAPPER}} .ec-instagram-feed.ec-card .ec-instagram-feed-item',
			]
		);

		$this->add_control(
			'instagram_feed_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'instagram_feed_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed.ec-card .ec-instagram-feed-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'instagram_feed_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-instagram-feed',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_instagram_username_controls() {
		$this->start_controls_section(
			'ec_instagram_style_username_section',
			[
				'label' => esc_html__( 'Username', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'instagram_username_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-instagram-feed-username' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'instagram_username_typography',
				'selector' => '{{WRAPPER}} .ec-instagram-feed-username',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'instagram_username_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-instagram-feed-username',
			]
		);

		$this->add_control(
			'instagram_username_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'instagram_username_border',
				'selector' => '{{WRAPPER}} .ec-instagram-feed-username',
			]
		);

		$this->add_control(
			'instagram_username_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'instagram_username_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed-username' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'instagram_username_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed-username' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'instagram_username_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed-username' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_instagram_caption_controls() {
		$this->start_controls_section(
			'ec_instagram_style_caption_section',
			[
				'label' => esc_html__( 'Caption', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'instagram_caption_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-instagram-feed-caption' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'instagram_caption_typography',
				'selector' => '{{WRAPPER}} .ec-instagram-feed-caption',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'instagram_caption_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-instagram-feed-caption',
			]
		);

		$this->add_control(
			'instagram_caption_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'instagram_caption_border',
				'selector' => '{{WRAPPER}} .ec-instagram-feed-caption',
			]
		);

		$this->add_control(
			'instagram_caption_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'instagram_caption_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed-caption' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'instagram_caption_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed-caption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'instagram_caption_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_instagram_icon_controls() {
		$this->start_controls_section(
			'ec_instagram_icon_style_section',
			[
				'label' => esc_html__( 'Icon', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'instagram_icon_font_size',
			[
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
					'rem',
					'em',
				],
				'range'      => [
					'px'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 6.25,
						'step' => 0.01,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed .ec-instagram-feed-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'instagram_icon_border_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'instagram_icon_border',
				'selector' => '{{WRAPPER}} .ec-instagram-feed-icon',
			]
		);

		$this->add_control(
			'instagram_icon_border_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'instagram_icon_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'instagram_icon_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-instagram-feed-icon',
			]
		);

		$this->add_responsive_control(
			'instagram_icon_margin',
			[
				'label'      => esc_html__( 'Margin', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'instagram_icon_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-instagram-feed-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'instagram_icon_tabs',
			[
				'condition' => [
					'icon_type' => 'icon',
				],
			]
		);

		$this->start_controls_tab(
			'instagram_icon_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'icon_normal_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ec-instagram-feed .ec-instagram-feed-icon i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'instagram_icon_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-instagram-feed-icon',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'instagram_icon_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			]
		);

		$this->add_control(
			'instagram_icon_hover_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-instagram-feed .ec-instagram-feed-icon:hover i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'instagram_icon_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-instagram-feed .ec-instagram-feed-icon:hover',
			]
		);

		$this->add_control(
			'instagram_icon_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-instagram-feed-icon:hover'  => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_style_follow_button_controls() {
		$this->start_controls_section(
			'ec_follow_button_style_section',
			array(
				'label' => esc_html__( 'Follow Button', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'follow_button_typography',
				'selector' => '{{WRAPPER}} .ec-instagram-feed.ec-fullWidth .ec-instagram-follow-btn',
			)
		);

		$this->start_controls_tabs(
			'follow_button_tabs'
		);

		$this->start_controls_tab(
			'follow_button_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'follow_button_normal_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-instagram-feed.ec-fullWidth .ec-instagram-follow-btn' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'follow_button_normal_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-instagram-feed.ec-fullWidth .ec-instagram-follow-btn',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'follow_button_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'companion-elementor' ),
			)
		);

		$this->add_control(
			'follow_button_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .ec-instagram-feed.ec-fullWidth .ec-instagram-follow-btn:hover' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'follow_button_hover_bg',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => array(
					'classic',
					'gradient',
				),
				'selector' => '{{WRAPPER}} .ec-instagram-feed.ec-fullWidth .ec-instagram-follow-btn:hover',
			)
		);

		$this->end_controls_tab();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'      => 'follow_button_border',
				'selector'  => '{{WRAPPER}} .ec-instagram-feed.ec-fullWidth .ec-instagram-follow-btn',
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'follow_button_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array(
					'px',
					'%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .ec-instagram-feed.ec-fullWidth .ec-instagram-follow-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'follow_button_box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'companion-elementor' ),
				'selector' => '{{WRAPPER}} .ec-instagram-feed.ec-fullWidth .ec-instagram-follow-btn',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Get instagram feed.
	 *
	 * @param string $access_token
	 * @param integer $limit
	 * @param string $cache_timeout
	 * @return mixed
	 */
	public static function get_instagram_feed( $access_token, $limit = 6, $cache_timeout = 'hour' ) {
		$cache_key      = 'instagram_feed_' . md5( $access_token . $limit );
		$cached_feed    = get_transient( $cache_key );
		$cache_timeouts = [
			'none'   => 0,
			'minute' => MINUTE_IN_SECONDS,
			'hour'   => HOUR_IN_SECONDS,
			'day'    => DAY_IN_SECONDS,
			'week'   => WEEK_IN_SECONDS,
		];

		if ( false === $cached_feed ) {
			$api_url  = "https://graph.instagram.com/me/media?fields=id,caption,media_type,media_url,timestamp,username,permalink&access_token=$access_token&limit=$limit";
			$response = wp_remote_get( $api_url );
			if ( ! is_wp_error( $response ) && 200 === $response['response']['code'] ) {
				$body = wp_remote_retrieve_body( $response );
				$data = json_decode( $body, true );

				if ( isset( $data['data'] ) ) {
					$instagram_feed = $data['data'];
					set_transient( $cache_key, $instagram_feed, $cache_timeouts[ $cache_timeout ] ?? 0 );
					$cached_feed = $instagram_feed;
				}
			}
		}

		return $cached_feed;
	}

	protected function render() {
		$settings          = $this->get_settings_for_display();
		$instagram_layout  = $settings['instagram_layout'];
		$instagram_columns = $settings['instagram_columns'];
		$access_token      = $settings['instagram_access_token'];
		$limit             = $settings['instagram_number_of_posts'];
		$cache_timeout     = $settings['instagram_cache_timeout'];
		$instagram_caption = $settings['instagram_caption'];

		if ( empty( $access_token ) ) {
			echo '<p class="ec-instagram-feed__error"> ' . esc_html( __( 'Your Instagram Access Token is missing, please configure it.', 'companion-elementor' ) ) . '</p>';
		} else {
			$instagram_feed = self::get_instagram_feed( $access_token, $limit, $cache_timeout );

			if ( $instagram_feed ) {
				echo '<div class="ec-instagram-feed ' . esc_attr( 'ec-' . $instagram_layout ) . ' ' . esc_attr( 'ec-column-' . $instagram_columns ) . '">';
				foreach ( $instagram_feed as $feed ) {
					$image_url = $feed['media_url'] ?? '';
					$caption   = $feed['caption'] ?? '';
					$timestamp = isset( $feed['timestamp'] ) ? gmdate( 'F j, Y', strtotime( $feed['timestamp'] ) ) : '';
					$username  = $feed['username'] ?? __( 'Companion Addons', 'companion-elementor' );
					$permalink = $feed['permalink'] ?? '';

					echo '<div class="ec-instagram-feed-item" data-permalink="' . esc_url( $permalink ) . '">';
					if ( 'list' === $instagram_layout ) {
						if ( $image_url ) {
							echo '<div class="ec-instagram-feed-list-item">';
							echo '<img class="ec-instagram-feed-list-image" src="' . esc_url( $image_url ) . '" alt="' . esc_attr( $caption ) . '">';

							echo '<div class="ec-instagram-feed-item-right-content">';
							echo '<div class="ec-instagram-feed-item-info-content">';

							if ( $timestamp ) {
								echo '<p class="ec-instagram-feed-date">' . esc_html( $timestamp ) . '</p>';
							}
							echo '<a href="' . esc_url( $permalink ) . '" target="_blank">';
							echo '<span class="ec-instagram-feed-icon"><i class="fab fa-instagram" aria-hidden="true"></i></span>';
							echo '</a>';
							echo '</div>';

							if ( 'yes' === $instagram_caption && $caption ) {
								echo '<p class="ec-instagram-feed-caption">' . esc_html( $caption ) . '</p>';
							}
							echo '</div>';

							echo '</div>';
						}
					} elseif ( 'fullWidth' === $instagram_layout ) {
						if ( $image_url ) {
							echo '<img class="ec-instagram-feed-list-image" src="' . esc_url( $image_url ) . '" alt="' . esc_attr( $caption ) . '">';
							echo '<a href="' . esc_url( $permalink ) . '" target="_blank">';
							echo '<span class="ec-instagram-feed-icon"><i class="fab fa-instagram" aria-hidden="true"></i></span>';
							echo '</a>';

						}
					} elseif ( $image_url ) {
						echo '<div class="ec-instagram-feed-item-above-image">';
						if ( $username ) {
							echo '<p class="ec-instagram-feed-username">' . esc_html( $username ) . '</p>';
						}
						echo '<a href="' . esc_url( $permalink ) . '" target="_blank">';
						echo '<span class="ec-instagram-feed-icon"><i class="fab fa-instagram" aria-hidden="true"></i></span>';
						echo '</a>';
						echo '</div>';

						echo '<img class="ec-instagram-feed-list-image" src="' . esc_url( $image_url ) . '" alt="' . esc_attr( $caption ) . '">';

						echo '<div class="ec-instagram-feed-below-image">';
						if ( 'yes' === $instagram_caption && $caption ) {
							echo '<p class="ec-instagram-feed-caption">' . esc_html( $caption ) . '</p>';
						}
						if ( $timestamp ) {
							echo '<p class="ec-instagram-feed-date">' . esc_html( $timestamp ) . '</p>';
						}
						echo '</div>';
					}
					echo '</div>';
				}
				if ( 'fullWidth' === $instagram_layout ) {
					echo '<div class="ec-instagram-feed-btn">';
					echo '<a class="ec-instagram-follow-btn" href="https://www.instagram.com/" target="_blank" rel="nofollow">';
					echo '<i aria-hidden="true" class="fab fa-instagram"></i>';
					echo esc_html( __( 'Follow on Instagram', 'companion-elementor' ) );
					echo '</a>';
					echo '</div>';
				}
				echo '</div>';
			} else {
				echo '<p class="ec-instagram-feed__error">' . esc_html( __( 'Failed to retrieve Instagram feed.', 'companion-elementor' ) ) . '</p>';
			}
		}
	}
}
