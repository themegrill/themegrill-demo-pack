<?php

namespace CompanionElementor\Modules\OnepageNav;

use CompanionElementor\Base\Module_Base;

defined( 'ABSPATH' ) || exit;

class Module extends Module_Base {

	public function get_widgets() {
		return array(
			'Onepage_Nav',
		);
	}

	public function get_name() {
		return 'onepage-nav';
	}
}
