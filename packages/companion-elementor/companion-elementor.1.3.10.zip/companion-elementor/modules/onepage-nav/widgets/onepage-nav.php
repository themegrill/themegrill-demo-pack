<?php
/**
 * Onepage nav class.
 */
namespace CompanionElementor\Modules\OnepageNav\Widgets;

use CompanionElementor\Base\Base_Widget;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Repeater;

defined( 'ABSPATH' ) || exit;

class Onepage_Nav extends Base_Widget {


	public function get_name() {
		return 'elementor-companion-onepage-nav';
	}

	public function get_title() {
		return __( 'Onepage nav', 'companion-elementor' );
	}

	public function get_icon() {
		return 'ce-widget-icon eicon-navigator';
	}

	public function get_keywords() {
		return array( 'companion', 'onepage', 'nav', 'onepage nav' );
	}

	protected function register_controls() {
		$this->register_navigation_controls();
		$this->register_style_navigation_wrapper_controls();
		$this->register_style_navigation_item_controls();
	}

	private function register_navigation_controls() {
		$this->start_controls_section(
			'ec_section_navigation',
			[
				'label' => __( 'Navigation', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'onepage_nav_title',
			[
				'label'       => __( 'Title', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Title', 'companion-elementor' ),
				'dynamic'     => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'onepage_nav_id',
			[
				'label'       => esc_html__( 'Section ID', 'companion-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'section-one',
				'dynamic'     => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'onepage_nav_icon',
			[
				'label'       => __( 'Icon', 'companion-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => [
					'value'   => 'fas fa-book-open',
					'library' => 'fa-solid',
				],
				'skin'        => 'inline',
				'label_block' => false,
			]
		);

		$this->add_control(
			'onepage_nav_section',
			array(
				'label'       => __( 'Section', 'companion-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						/* Translators: %s number. */

						'onepage_nav_title' => sprintf( esc_html__( 'Section %s', 'companion-elementor' ), 1 ),
						'onepage_nav_id'    => 'section-one',
						'onepage_nav_icon'  => [
							'value'   => 'fa fa-home',
							'library' => 'solid',
						],
					],
					[
						/* Translators: %s number. */
						'onepage_nav_title' => sprintf( esc_html__( 'Section %s', 'companion-elementor' ), 2 ),
						'onepage_nav_id'    => 'section-two',
						'onepage_nav_icon'  => [
							'value'   => 'fa fa-envelope',
							'library' => 'solid',
						],
					],
					[
						/* Translators: %s number. */
						'onepage_nav_title' => sprintf( esc_html__( 'Section %s', 'companion-elementor' ), 3 ),
						'onepage_nav_id'    => 'section-three',
						'onepage_nav_icon'  => [
							'value'   => 'fa fa-info-circle',
							'library' => 'solid',
						],
					],
				],
				'title_field' => '{{{ onepage_nav_title }}}',
				'separator'   => 'after',
			)
		);

		$this->add_responsive_control(
			'onepage_nav_horizontal_position',
			[
				'label'   => esc_html__( 'Horizontal Position', 'companion-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'right',
				'options' => array(
					'left'  => array(
						'title' => esc_html__( 'Left', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-left',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'companion-elementor' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
			]
		);

		$this->add_responsive_control(
			'onepage_nav_vertical_position',
			[
				'label'   => esc_html__( 'Vertical Position', 'companion-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'middle',
				'options' => [
					'top'    => [
						'title' => esc_html__( 'Top', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'companion-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_style_navigation_wrapper_controls() {
		$this->start_controls_section(
			'ec_navigation_wrapper',
			[
				'label' => esc_html__( 'Navigation Wrapper', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'ec_navigation_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-onepage-nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'ec_navigation_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ec_navigation_border',
				'selector' => '{{WRAPPER}} .ec-onepage-nav',
			]
		);

		$this->add_control(
			'ec_navigation_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'ec_navigation_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-onepage-nav' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'ec_navigation_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-onepage-nav',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_navigation_item_controls() {
		$this->start_controls_section(
			'ec_navigation_item_section',
			[
				'label' => esc_html__( 'Navigation Item', 'companion-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'nav_item_color',
			[
				'label'     => esc_html__( 'Color', 'companion-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ec-onepage-nav i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'navigation_item_background',
				'label'    => esc_html__( 'Background', 'companion-elementor' ),
				'types'    => [
					'classic',
					'gradient',
				],
				'selector' => '{{WRAPPER}} .ec-onepage-nav i',
			]
		);

		$this->add_responsive_control(
			'navigation_item_padding',
			[
				'label'      => esc_html__( 'Padding', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'em',
					'rem',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-onepage-nav i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'navigation_item_icon_font_size',
			[
				'label'      => esc_html__( 'Icon Size', 'companion-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [
					'px',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-onepage-nav i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'navigation_item_divider_before',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'navigation_item',
				'selector' => '{{WRAPPER}} .ec-onepage-nav i',
			]
		);

		$this->add_control(
			'navigation_item_divider_after',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'navigation_item_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'companion-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [
					'px',
					'%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ec-onepage-nav i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'navigation_item_gap',
			[
				'label'     => esc_html__( 'Gap', 'companion-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .ec-onepage-nav' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings                        = $this->get_settings_for_display();
		$onepage_nav_horizontal_position = $settings['onepage_nav_horizontal_position'];
		$onepage_nav_vertical_position   = $settings['onepage_nav_vertical_position'];
		?>
	
		<div class="ec-onepage-nav-wrapper">
			<div class="ec-onepage-nav 
			<?php
			echo esc_attr( 'position-' . $onepage_nav_horizontal_position ) . ' ';
			echo esc_attr( 'position-' . $onepage_nav_vertical_position );
			?>
				">
				<?php foreach ( $settings['onepage_nav_section'] as $item ) : ?>
					<i class="<?php echo esc_attr( $item['onepage_nav_icon']['value'] ); ?>" aria-hidden="true" data-section="<?php echo esc_attr( $item['onepage_nav_id'] ); ?>"></i>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
