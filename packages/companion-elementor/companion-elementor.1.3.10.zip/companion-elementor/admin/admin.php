<?php
/**
 * Admin class.
 */
namespace CompanionElementor\Admin;

/**
 * Admin class.
 */
class Admin {

	/**
	 * Holds single instance of this class.
	 *
	 * @var null|Admin
	 */
	private static $instance = null;

	/**
	 * Get single instance of this class.
	 *
	 * @return Admin
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
	}

	/**
	 * Add admin menu.
	 *
	 * @return void
	 */
	public function add_admin_menu() {
		add_menu_page(
			__( 'CE Addons', 'companion-elementor' ),
			__( 'CE Addons', 'companion-elementor' ),
			'manage_options',
			'companion-addons',
			array( $this, 'render_setting_page' ),
			'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" width="24" height="24"><path d="M12 1C5.925 1 1 5.925 1 12s4.925 11 11 11 11-4.925 11-11S18.075 1 12 1Zm4.575 17.923A7.999 7.999 0 0 1 12.56 20a7.949 7.949 0 0 1-5.657-2.344A7.948 7.948 0 0 1 4.56 12c0-2.137.833-4.146 2.344-5.657a7.949 7.949 0 0 1 5.657-2.344 7.998 7.998 0 0 1 6.634 3.527l-1.178.796a6.578 6.578 0 0 0-5.456-2.901A6.587 6.587 0 0 0 5.982 12a6.587 6.587 0 0 0 6.58 6.58 6.616 6.616 0 0 0 5.656-3.219l1.222.728a8.047 8.047 0 0 1-2.865 2.834Zm-6.825-6.11v-1.548h5.655v1.548H9.75Zm5.655 1.264v1.548H9.75v-1.548h5.655ZM9.75 10.002V8.453h5.655v1.549H9.75Z"></path></svg>' ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		);
	}

	/**
	 * Render settings  page.
	 *
	 * @return void
	 */
	public function render_setting_page() {
		$settings_saved = false;

		if ( isset( $_POST['_ec_settings_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_ec_settings_nonce'] ) ), 'ec-settings' ) ) {
			$settings_saved = true;
			$option_keys    = [ 'ec_mailchimp_api_key', 'ec_google_map_api_key' ];

			foreach ( $option_keys as $option_key ) {
				if ( ! isset( $_POST[ $option_key ] ) ) {
					continue;
				}
				$option_value = sanitize_text_field( wp_unslash( $_POST[ $option_key ] ) );
				update_option( $option_key, $option_value );
			}
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Integrations', 'companion-elementor' ); ?></h1>
			<?php if ( $settings_saved ) : ?>
				<div class="notice notice-success settings-error is-dismissible">
					<p><strong><?php esc_html_e( 'Settings saved.', 'companion-elementor' ); ?></strong></p>
				</div>
			<?php endif; ?>
			<form method="POST" action="<?php echo esc_url( admin_url( 'admin.php?page=companion-addons' ) ); ?>">
				<?php wp_nonce_field( 'ec-settings', '_ec_settings_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row">
								<label for="ec_mailchimp_api_key"><?php esc_html_e( 'MailChimp API Key', 'companion-elementor' ); ?></label>
							</th>
							<td>
								<input type="text" name="ec_mailchimp_api_key" id="ec_mailchimp_api_key" value="<?php echo esc_attr( get_option( 'ec_mailchimp_api_key', '' ) ); ?>" class="regular-text">
								<p><a href="https://mailchimp.com/help/about-api-keys/" target="_blank"><?php esc_html_e( 'How to get MailChimp API Key?', 'companion-elementor' ); ?></a></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="ec_google_map_api_key"><?php esc_html_e( 'Google Map API Key', 'companion-elementor' ); ?></label>
							</th>
							<td>
								<input type="text" name="ec_google_map_api_key" id="ec_google_map_api_key" value="<?php echo esc_attr( get_option( 'ec_google_map_api_key', '' ) ); ?>" class="regular-text">
								<p><a href="https://www.youtube.com/watch?v=O5cUoVpVUjU" target="_blank"><?php esc_html_e( 'How to get Google Map API Key?', 'companion-elementor' ); ?></a></p>
							</td>
						</tr>
					</tbody>
				</table>
				<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes"></p>
			</form>
		</div>
		<?php
	}
}

Admin::instance();
