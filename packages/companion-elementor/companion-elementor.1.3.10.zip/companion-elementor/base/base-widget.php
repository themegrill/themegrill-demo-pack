<?php
namespace CompanionElementor\Base;

use Elementor\Widget_Base;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

abstract class Base_Widget extends Widget_Base {

	public function get_categories() {
		return array( 'elementor-companion-category' );
	}
}
