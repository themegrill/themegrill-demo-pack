/**
 * Companion Elementor front end JS file.
 *
 * @package Companion_Elementor
 * @since   1.0.0
 */

var CompanionElementorFrontend = function ($) {
	var self = this;

	this.countdown = function ($scope, $) {
		var dateElement, date, timeInterval, elements;

		dateElement = $scope.find('.ec-countdown');
		date = new Date(dateElement.data('date') * 1000);
		elements = {
			$seconds: $scope.find('.ec-second'),
			$minutes: $scope.find('.ec-minute'),
			$hours: $scope.find('.ec-hour'),
			$days: $scope.find('.ec-day')
		};

		var getRemainingTime = function () {

			var timeRemaining, $seconds, $minutes, $hours, $days;

			timeRemaining = date - new Date();
			$seconds = Math.floor((timeRemaining / 1000) % 60);
			$minutes = Math.floor((timeRemaining / 1000 / 60) % 60);
			$hours = Math.floor((timeRemaining / (1000 * 60 * 60)) % 24);
			$days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));

			if ($days < 0 || $hours < 0 || $minutes < 0) {
				seconds = $minutes = $hours = $days = 0;
			}

			return {
				'total': timeRemaining,
				'remaining': {
					seconds: $seconds,
					minutes: $minutes,
					hours: $hours,
					days: $days
				}
			};

		};

		var updateTimer = function () {

			$.each(
				getRemainingTime().remaining,
				function (timeRemaining) {
					var element, remainingTime;

					element = elements['$' + timeRemaining];
					remainingTime = this.toString();

					if (1 === remainingTime.length) {
						remainingTime = 0 + remainingTime;
					}

					if (element.length) {
						element.text(remainingTime);
					}
				}
			);

			if (getRemainingTime().total <= 0) {
				clearInterval(timeInterval);
			}

		};

		var initializeTimer = function () {
			updateTimer();

			timeInterval = setInterval(updateTimer, 1000);
		};

		initializeTimer();

	};

	this.counter = function ($scope, $) {

		var $number = $scope.find('.ec-number'),
			data = $number.data();

		var digits = data.toValue.toString().match(/\.(.*)/);

		if (digits) {
			data.rounding = digits[1].length;
		}

		$number.numerator(data);

	};

	this.chart = function ($scope, $) {
		const data = $scope.find('[data-chart-settings]').data('chartSettings');
		const showLegends = data.data.bar_chart_legends_show === 'yes';
		const showTooltip = data.data.show_chart_tooltip === 'yes';
		const legendPosition =
			data.data.bar_chart_legends_position !== undefined
				? data.data.bar_chart_legends_position
				: 'top';

		let options = {
			plugins: {
				tooltip: { enabled: showTooltip },
				legend: {
					display: showLegends,
					position: legendPosition,
					labels: {
						usePointStyle: data.data.bar_chart_legends_shape === 'point',
					},
				},
			},
			scales: {
				x: {
					grid: {
						display: data.data.bar_chart_xaxes_grid_display === 'yes',
					},
					ticks: {
						display: data.data.bar_chart_xaxes_labels_display === 'yes',
						stepSize: data.data.bar_char_axis_range,
						max: data.data.bar_char_step_size,
					},
				},
				y: {
					grid: {
						display: data.data.bar_chart_yaxes_grid_display === 'yes',
					},
					ticks: {
						display: data.data.bar_chart_yaxes_labels_display === 'yes',
						stepSize: data.data.bar_char_axis_range,
						max: data.data.bar_char_step_size,
					},
				},
			},
		};

		const chartHeight = data.data.bar_chart_height.size;
		$scope.find('.ec-chart').attr('height', chartHeight);

		data.data.datasets.forEach((dataset) => {
			dataset.stack = 'Stack 1';
			dataset.borderWidth = dataset.borderWidth || 1;
			dataset.borderColor = dataset.borderColor || '#fff';
		});

		data.options = options;

		const ctx = $scope.find('.ec-chart').get(0).getContext('2d');
		new Chart(ctx, data);
	};

	this.filterableGallery = function ($scope, $) {

		var masonry, filter, popup, gallery, settings, galleryPopup;

		masonry = $scope.find('.ec-fg-items-wrap');
		filter = $scope.find('.ec-fg-controls');
		popup = $scope.find('.lightbox');
		gallery = $scope.find('.ec-fg');
		settings = gallery.data('gallery_option');
		galleryPopup = false;

		imagesLoaded($scope, function (e) {

			// Gallery popup variable.
			if ('yes' === settings.photoGallery) {
				galleryPopup = true;
			}

			// Image popup settings.
			popup.magnificPopup({
				type: 'image',
				gallery: {
					enabled: galleryPopup
				},
				removalDelay: 100,
				callbacks: {
					beforeOpen: function () {
						this.st.mainClass = this.st.el.attr('data-effect');
					}
				},
				midClick: true
			}); // Popup effect : https://codepen.io/dimsemenov/pen/GAIkt

			// Filterable gallery settings.
			if ($('.ec-fg-item').length > 0) {
				var $grid = masonry.isotope(
					{
						itemSelector: '.ec-fg-item',
						layoutMode: settings.masonryLayout
					}
				);

				// Filter items on click.
				filter.on(
					'click',
					'li',
					function () {
						var filterCategory = $(this).attr('data-filter');

						$grid.isotope(
							{
								filter: filterCategory
							}
						);
					}
				);

				// Toggle the active class to design the filter as needed.
				filter.each(
					function (index, groupElement) {
						var $groupElement = $(groupElement);

						$groupElement.on(
							'click',
							'li',
							function () {
								$groupElement.find('.active').removeClass('active');
								$(this).addClass('active');
							}
						);
					}
				);
			}
		});

	};

	this.mediaCarousel = function ($scope, $) {
		var carouselContainer, popup, settings, galleryPopup, loop, carouselOptions;

		carouselContainer = $scope.find('.swiper-container');
		popup = $scope.find('.lightbox');
		settings = carouselContainer.data('carousel_settings');

		loop = (
			'yes' === settings.infiniteLoop
		);

		carouselOptions = {
			loop: loop,
			speed: settings.speed,
			spaceBetween: settings.spaceBetween,
			grid: {
				fill: 'row',
				rows: settings.slider_row,
			},
			breakpoints: {
				360: {
					slidesPerView: settings.spvMobile,
					spaceBetween: settings.spaceBetweenMobile
				},
				768: {
					slidesPerView: settings.spvTablet,
					spaceBetween: settings.spaceBetweenTablet
				},
				1024: {
					slidesPerView: settings.spv,
					spaceBetween: settings.spaceBetween
				}
			}
		};

		if (true === settings.arrows) {
			carouselOptions.navigation = {
				nextEl: '.ec-nav-next',
				prevEl: '.ec-nav-prev'
			};
		}

		if (true === settings.dots) {
			carouselOptions.pagination = {
				el: '.ec-pagination',
				clickable: true
			};
		}

		if ('yes' === settings.autoplay) {
			carouselOptions.autoplay = {
				delay: settings.delay,
				disableOnInteraction: false
			};
		}

		if ('undefined' === typeof Swiper) {
			var asyncSwiper = elementorFrontend.utils.swiper;
			new asyncSwiper(carouselContainer, carouselOptions).then(function (newSwiperInstance) {
				mySwiper = newSwiperInstance;
			});
		} else {
			new Swiper(carouselContainer, carouselOptions);
		}

		// Gallery popup variable.
		galleryPopup = (
			'yes' === settings.photoGallery
		);

		// Image popup settings.
		popup.magnificPopup(
			{
				type: 'image',
				gallery: {
					enabled: galleryPopup
				}
			}
		);
	};

	this.modal = function ($scope, $) {

		var src, popupBox, settings;

		src = $scope.find('.ec-modal-src');
		popupBox = $scope.find('.ec-modal-popup-box');
		settings = popupBox.data('modal_settings');

		src.magnificPopup(
			{
				type: 'inline',
				mainClass: 'ec-modal-popup-message-box ec-modal-popup-message-' + settings.modalID
			}
		);

	};

	this.mailchimp = function ($scope, $) {
		var form = $scope.find('.ec-mailchimp-form');
		form.on('submit', function (event) {
			event.preventDefault();
			var $this = $(this);
			$.ajax(
				{
					type: 'POST',
					dataType: 'json',
					beforeSend: function () {
						$this.find('.ec-mailchimp-subscribe-button').attr('disabled', 'disabled');
						$this.find('[name="ec_mailchimp_email"]').attr('disabled', 'disabled');
					},
					complete: function () {
						$this.find('.ec-mailchimp-subscribe-button').removeAttr('disabled');
						$this.find('[name="ec_mailchimp_email"]').removeAttr('disabled');
					},
					success: function () {
						$this.find('[name="ec_mailchimp_email"]').val('');
					},
					data: {
						action: 'ec_mailchimp_subscribe',
						security: $(this).find('#ec_mailchimp_form_nonce').val(),
						email: $(this).find('[name="ec_mailchimp_email"]').val(),
						audience: $(this).find('[name="ec_mailchimp_audience"]').val(),
					},
					url: companion_elementor.ajax_url,
				}
			)
		})
	};

	this.postSlider = function ($scope, $) {

		var options, container, settings, loop;

		container = $scope.find('.ec-post-slider');
		settings = container.data('slider_options');

		loop = (
			'yes' === settings.loop
		);

		options = {
			loop: loop,
			effect: settings.effect,
			speed: settings.speed,
			slidesPerView: 1,
			spaceBetween: 15,
			breakpoints: {
				360: {
					slidesPerView: settings.spvMobile,
					spaceBetween: settings.spaceBetweenMobile || 15
				},
				768: {
					slidesPerView: settings.spvTablet,
					spaceBetween: settings.spaceBetweenTablet || 15
				},
				1024: {
					spaceBetween: settings.spaceBetween || 15,
					slidesPerView: settings.spv,
				}
			},
		};

		console.log(options);

		if (true === settings.arrows) {
			options.navigation = {
				nextEl: '.ec-nav-next',
				prevEl: '.ec-nav-prev',
			};
		}

		if (true === settings.dots) {
			options.pagination = {
				el: '.ec-pagination',
				clickable: true,
			};
		}

		if ('yes' === settings.autoplay) {
			options.autoplay = {
				delay: settings.delay,
				disableOnInteraction: false
			};
		}

		if ('undefined' === typeof Swiper) {
			var asyncSwiper = elementorFrontend.utils.swiper;
			new asyncSwiper(container, options).then(function (newSwiperInstance) {
				mySwiper = newSwiperInstance;
			});
		} else {
			new Swiper(container, options);
		}
	};

	this.slider = function ($scope, $) {

		var options, container, settings, loop;

		container = $scope.find('.ec-slider');
		settings = container.data('slider_options');

		loop = (
			'yes' === settings.loop
		);

		options = {
			loop: loop,
			effect: settings.effect,
			speed: settings.speed,
		};

		if (true === settings.arrows) {
			options.navigation = {
				nextEl: '.ec-nav-next',
				prevEl: '.ec-nav-prev',
			};
		}

		if (true === settings.dots) {
			options.pagination = {
				el: '.ec-pagination',
				clickable: true,
			};
		}

		if ('yes' === settings.autoplay) {
			options.autoplay = {
				delay: settings.delay,
				disableOnInteraction: false
			};
		}

		if ('undefined' === typeof Swiper) {
			var asyncSwiper = elementorFrontend.utils.swiper;
			new asyncSwiper(container, options).then(function (newSwiperInstance) {
				mySwiper = newSwiperInstance;
			});
		} else {
			new Swiper(container, options);
		}
	};

	this.switcher = function ($scope, $) {

		var switch_content_primary, switch_content_secondary, switch_input, switchWrap;

		switch_content_primary = $scope.find('.ec-content--primary');
		switch_content_secondary = $scope.find('.ec-content--secondary');
		switch_input = $scope.find('input');
		switchWrap = $scope.find('.ec-switch');

		switch_input.on(
			'click',
			function () {
				switch_content_primary.toggle();
				switch_content_secondary.toggle();
				switchWrap.toggleClass('ec-switch-on');
			}
		);

	};

	this.table = function ($scope, $) {
		var tabsWrap = $scope.find('.ec-table__toggle'),
			trHeading = tabsWrap.find('.ec-tr-heading');

		trHeading.not(':eq(0)').nextUntil('.ec-tr-heading').hide();

		trHeading.on(
			'click',
			function (e) {
				e.preventDefault();

				var $self = jQuery(this),
					currentContent = $self.nextUntil('.ec-tr-heading'),
					siblingTabs = $self.siblings('.ec-tr-heading'),
					currentContentSiblings = siblingTabs.nextUntil('.ec-tr-heading');

				currentContentSiblings.hide();
				currentContent.show();
			}
		);
	};

	this.tabs = function ($scope, $) {
		var tabsWrap = $scope.find('.ec-tabs-wrapper');
		var tabTitle = tabsWrap.find('.ec-tab-title');

		tabTitle.on(
			'click',
			function (e) {
				var $self = jQuery(this),
					currentId = $self.attr('aria-controls'),
					contentsWrap = $self.parents('.ec-tabs-controls').siblings('.ec-tabs-content'),
					contents = contentsWrap.children('.ec-tab-content'),
					currentContent = contentsWrap.children('#' + currentId);

				$self.siblings().removeClass('ec-active');
				$self.addClass('ec-active');

				contents.removeClass('ec-active');
				currentContent.addClass('ec-active');

			}
		);
	};

	this.offcanvas = function ($scope, $) {
		var offcanvasWrap = $scope.find('.ec-offcanvas-wrapper');
		offcanvasWrap.find('.ec-offcanvas').on('click', function (event) {
			event.preventDefault();
			offcanvasWrap.toggleClass('ec-open');

			if (offcanvasWrap.hasClass('ec-open')) {
				$('body').css({ overflow: 'hidden' });
			} else {
				$('body').css({ overflow: 'auto' });
			}
		});

		offcanvasWrap.find('.ec-offcanvas-overlay, .ec-offcanvas-close').on('click', function (event) {
			offcanvasWrap.removeClass('ec-open');
			$('body').css({ overflow: 'auto' });
		});

		offcanvasWrap.find('.ec-offcanvas-content').on('click', function (event) {
			event.stopPropagation();
		});
	};

	this.onepageNavigation = function ($scope, $) {

		const $navContainer = $scope.find('.ec-onepage-nav');

		$navContainer.find('i').each(function () {
			const sectionId = $(this).attr('data-section');
			const anchor = $(`<a href="#${sectionId}" class="navigation-link"></a>`)
			anchor.append($(this).clone());
			$(this).replaceWith(anchor);
		})

		$navContainer.on('click', function (event) {
			if (event.target.tagName === 'A') {
				console.log('asdffsd');
				event.preventDefault();
				const sectionId = $(this).attr('href').substring(1);
				const section = $(sectionId);
				if (section) {
					section.scrollIntoView({ behavior: 'smooth' });
				}
			}
		});
	};

	this.progressBar = function ($scope, $) {
		var progressBar = $scope.find('.ec-progress-bar-wrapper'),
			progressBarInnerLine = progressBar.find('.ec-progress-bar-inner-bar'),
			progressCircle = progressBar.find('.ec-progress-circle '),
			progressBarOptions = progressBar.data('options'),
			progressBarCounterPercentage = progressBarOptions.percentValueCounter;

		function isInViewport($selector) {
			if ($selector.length) {
				var elementTop = $selector.offset().top,
					elementBottom = elementTop + $selector.outerHeight(),
					viewportTop = $(window).scrollTop(),
					viewportBottom = viewportTop + $(window).height();

				if (elementTop > $(window).height()) {
					elementTop += 50;
				}

				return elementBottom > viewportTop && elementTop < viewportBottom;
			}
		}

		if (isInViewport(progressCircle)) {
			progressCircle.css({
				'--progress-value': progressBarOptions.counterValue
			});
		}
		if (isInViewport(progressBarInnerLine)) {
			progressBarInnerLine.css({
				'width': progressBarCounterPercentage + '%'
			});
		}
	};

	this.lottieAnimation = function ($scope, $) {
		var lottieAnimations = $scope.find('.ec-lottie-animations');
		var lottieAnimationsWrap = $scope.find('.ec-lottie-animations-wrapper');
		var lottieJSON = JSON.parse(lottieAnimations.attr('data-settings'));

		var animationSettings = {
			container: lottieAnimations[0],
			path: lottieAnimations.attr('data-json-url'),
			renderer: lottieJSON.lottie_renderer,
			loop: lottieJSON.loop === 'yes',
			autoplay: lottieJSON.autoplay === 'yes'
		};

		var animation = lottie.loadAnimation(animationSettings);
		animation.setSpeed(lottieJSON.speed);
		if (lottieJSON.reverse) {
			animation.setDirection(-1);
		}

		animation.addEventListener('DOMLoaded', function () {
			if (lottieJSON.playOn !== 'hover' && lottieJSON.playOn !== 'none') {
				initLottie('load');
				$(window).on('scroll', initLottie);
			}

			if (lottieJSON.playOn === 'hover') {
				animation.pause();
				lottieAnimations.hover(function () {
					animation.play();
				}, function () {
					animation.pause();
				});
			}

			function initLottie(event) {
				animation.pause();

				if (typeof lottieAnimations[0].getBoundingClientRect === "function") {
					var height = document.documentElement.clientHeight;
					var scrollTop = (lottieAnimations[0].getBoundingClientRect().top) / height * 100;
					var scrollBottom = (lottieAnimations[0].getBoundingClientRect().bottom) / height * 100;
					var scrollEnd = scrollTop < lottieJSON.scroll_end;
					var scrollStart = scrollBottom > lottieJSON.scroll_start;

					if (lottieJSON.playOn === 'viewport') {
						scrollStart && scrollEnd ? animation.play() : animation.pause();
					}

					if (lottieJSON.playOn === 'scroll') {
						if (scrollStart && scrollEnd) {
							animation.pause();
							var scrollPercent = 100 * $(window).scrollTop() / ($(document).height() - $(window).height());
							var scrollPercentRounded = Math.round(scrollPercent);
							animation.goToAndStop((scrollPercentRounded / 100) * 4000);
						}
					}
				}
			}
		});
	}

	this.accordionToggle = function ($scope, $) {
		var tabsWrap = $scope.find('.ec-at-wrapper');
		var tabTitle = tabsWrap.find('.ec-tab-title');

		tabTitle.on(
			'click',
			function (e) {
				e.preventDefault();

				var $self = jQuery(this),
					currentContent = $self.siblings('.ec-tab-content'),
					currentTab = currentContent.parent('.ec-at-item'),
					siblingsTabs = currentTab.siblings('.ec-at-item'),
					siblingsTabsContent = siblingsTabs.children('.ec-tab-content')

				// Accordion.
				if (currentTab.closest('.ec-accordion').length) {
					currentContent.slideDown();
					siblingsTabsContent.slideUp();

					currentTab.addClass('ec-active');
					siblingsTabs.removeClass('ec-active');
				} else if (currentTab.closest('.ec-toggle').length) { // Toggle.
					currentContent.slideToggle();

					currentTab.toggleClass('ec-active');
				}
			}
		);
	};

	this.testimonialCarousel = function ($scope, $) {
		var carouselOptions,
			testimonial = $scope.find('.swiper-container'),
			settings = testimonial.data('carousel_options'),
			loop = ('yes' === settings.loop);

		carouselOptions = {
			loop: loop,
			speed: settings.speed,
			spaceBetween: settings.spaceBetween,
			breakpoints: {
				360: {
					slidesPerView: settings.spvMobile,
					spaceBetween: settings.spaceBetweenMobile
				},
				768: {
					slidesPerView: settings.spvTablet,
					spaceBetween: settings.spaceBetweenTablet
				},
				1024: {
					slidesPerView: settings.spv,
					spaceBetween: settings.spaceBetween
				}
			}
		};

		if (true === settings.arrows) {
			carouselOptions.navigation = {
				nextEl: '.ec-nav-next',
				prevEl: '.ec-nav-prev'
			};
		}

		if (true === settings.dots) {
			carouselOptions.pagination = {
				el: '.ec-pagination',
				clickable: true
			};
		}

		if ('yes' === settings.autoplay) {
			carouselOptions.autoplay = {
				delay: settings.delay,
				disableOnInteraction: false
			};
		}

		// if ('undefined' === typeof Swiper) {
			var asyncSwiper = elementorFrontend.utils.swiper;
			new asyncSwiper(testimonial, carouselOptions).then(function (newSwiperInstance) {
				mySwiper = newSwiperInstance;
			});
		// } else {
		// 	mySwiper = new Swiper(testimonial, carouselOptions);
		// 	console.log( mySwiper );
		// }
	};

	this.WcProductsSlider = function ($scope, $) {

		var options, container, settings, loop;

		container = $scope.find('.ec-product-slider');
		settings = container.data('slider-options');

		loop = (
			'yes' === settings.loop
		);

		options = {
			loop: loop,
			effect: settings.effect,
			speed: settings.speed,
			breakpoints: {
				360: {
					slidesPerView: settings.spvMobile,
					spaceBetween: settings.spaceBetweenMobile
				},
				768: {
					slidesPerView: settings.spvTablet,
					spaceBetween: settings.spaceBetweenTablet
				},
				1024: {
					spaceBetween: settings.spaceBetween,
					slidesPerView: settings.spv,
				}
			},
		};

		if (true === settings.arrows) {
			options.navigation = {
				nextEl: '.ec-nav-next',
				prevEl: '.ec-nav-prev',
			};
		}

		if (true === settings.dots) {
			options.pagination = {
				el: '.ec-pagination',
				clickable: true,
			};
		}

		if ('yes' === settings.autoplay) {
			options.autoplay = {
				delay: settings.delay,
				disableOnInteraction: false
			};
		}

		if ('undefined' === typeof Swiper) {
			var asyncSwiper = elementorFrontend.utils.swiper;
			new asyncSwiper(container, options).then(function (newSwiperInstance) {
				mySwiper = newSwiperInstance;
			});
		} else {
			new Swiper(container, options);
		}
	};

	this.navMenu = function ($scope, $) {
		var menuToggle = $scope.find('.ec-menu-toggle');
		var mobileMenu = $scope.find('.ec-mobile-menu');

		if (menuToggle && mobileMenu) {
			menuToggle.on('click', function () {
				var expanded = $(this).attr('aria-expanded') === 'true' || false;
				$(this).attr('aria-expanded', !expanded);
				mobileMenu.toggleClass('ec-mobile-menu-visible');
			});
		}

		$scope.find('.ec-mobile-menu .ec-submenu-toggle').on('click', function () {
			$(this).parent('li').toggleClass('ec-submenu-visible');
		});
	};

	this.googleMaps = function ($scope, $) {
		if ('object' !== typeof window.google || 'object' !== typeof window.google.maps) {
			return;
		}
		let options = $scope.find('.ec-map-canvas-wrapper').data('map-options');
		let map = new google.maps.Map($scope.find('.ec-map-canvas')[0], options.map);
		options.marker.map = map;
		if (options.markerIcon.url) {
			options.marker.icon = {
				url: options.markerIcon.url,
				scaledSize: new google.maps.Size(options.markerIcon.width, options.markerIcon.height),
				origin: new google.maps.Point(0, 0),
				anchor: new google.maps.Point(0, 0)
			};
		}
		new google.maps.Marker(options.marker);
	}

	this.instagramFeed = function ($scope, $) {
		$scope.find('.ec-instagram-feed-list-image').on('click', function () {
			const $parent = $(this).parent('.ec-instagram-feed-item');
			const permalink = $parent.data('permalink');
			!!permalink && window.open(permalink, '_blank');
		});
	}

	var initModules = function () {
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-chart.default', self.chart);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-countdown.default', self.countdown);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-counter.default', self.counter);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-filterable-gallery.default', self.filterableGallery);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-lottie-animation.default', self.lottieAnimation);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-nav-menu.default', self.navMenu);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-media-carousel.default', self.mediaCarousel);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-mailchimp.default', self.mailchimp);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-modal.default', self.modal);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-offcanvas.default', self.offcanvas);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-onepage-nav.default', self.onepageNavigation);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-progress-bar.default', self.progressBar);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-post-slider.default', self.postSlider);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-slider.default', self.slider);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-switch.default', self.switcher);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-table.default', self.table);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-tabs.default', self.tabs);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-accordion-toggle.default', self.accordionToggle);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-testimonial-carousel.default', self.testimonialCarousel);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-wc-products-slider.default', self.WcProductsSlider);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-google-maps.default', self.googleMaps);
		elementorFrontend.hooks.addAction('frontend/element_ready/elementor-companion-instagram-feed.default', self.instagramFeed);
	};

	this.init = function () {
		$(window).on('elementor/frontend/init', initModules);
	};

	this.init();
};

window.companionElementorFrontend = new CompanionElementorFrontend(jQuery);
